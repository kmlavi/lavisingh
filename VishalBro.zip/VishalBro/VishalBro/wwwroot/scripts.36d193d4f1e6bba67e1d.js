﻿if (function (t, e) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = t.document ? e(t, !0) : function (t) {
        if (!t.document)
            throw new Error("jQuery requires a window with a document");
        return e(t)
    }
        : e(t)
}("undefined" != typeof window ? window : this, (function (t, e) {
    var n = []
        , i = t.document
        , o = n.slice
        , r = n.concat
        , s = n.push
        , a = n.indexOf
        , l = {}
        , u = l.toString
        , c = l.hasOwnProperty
        , d = {}
        , p = "1.12.4"
        , f = function (t, e) {
            return new f.fn.init(t, e)
        }
        , h = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g
        , g = /^-ms-/
        , m = /-([\da-z])/gi
        , v = function (t, e) {
            return e.toUpperCase()
        };
    function y(t) {
        var e = !!t && "length" in t && t.length
            , n = f.type(t);
        return "function" !== n && !f.isWindow(t) && ("array" === n || 0 === e || "number" == typeof e && e > 0 && e - 1 in t)
    }
    f.fn = f.prototype = {
        jquery: p,
        constructor: f,
        selector: "",
        length: 0,
        toArray: function () {
            return o.call(this)
        },
        get: function (t) {
            return null != t ? 0 > t ? this[t + this.length] : this[t] : o.call(this)
        },
        pushStack: function (t) {
            var e = f.merge(this.constructor(), t);
            return e.prevObject = this,
                e.context = this.context,
                e
        },
        each: function (t) {
            return f.each(this, t)
        },
        map: function (t) {
            return this.pushStack(f.map(this, (function (e, n) {
                return t.call(e, n, e)
            }
            )))
        },
        slice: function () {
            return this.pushStack(o.apply(this, arguments))
        },
        first: function () {
            return this.eq(0)
        },
        last: function () {
            return this.eq(-1)
        },
        eq: function (t) {
            var e = this.length
                , n = +t + (0 > t ? e : 0);
            return this.pushStack(n >= 0 && e > n ? [this[n]] : [])
        },
        end: function () {
            return this.prevObject || this.constructor()
        },
        push: s,
        sort: n.sort,
        splice: n.splice
    },
        f.extend = f.fn.extend = function () {
            var t, e, n, i, o, r, s = arguments[0] || {}, a = 1, l = arguments.length, u = !1;
            for ("boolean" == typeof s && (u = s,
                s = arguments[a] || {},
                a++),
                "object" == typeof s || f.isFunction(s) || (s = {}),
                a === l && (s = this,
                    a--); l > a; a++)
                if (null != (o = arguments[a]))
                    for (i in o)
                        t = s[i],
                            s !== (n = o[i]) && (u && n && (f.isPlainObject(n) || (e = f.isArray(n))) ? (e ? (e = !1,
                                r = t && f.isArray(t) ? t : []) : r = t && f.isPlainObject(t) ? t : {},
                                s[i] = f.extend(u, r, n)) : void 0 !== n && (s[i] = n));
            return s
        }
        ,
        f.extend({
            expando: "jQuery" + (p + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function (t) {
                throw new Error(t)
            },
            noop: function () { },
            isFunction: function (t) {
                return "function" === f.type(t)
            },
            isArray: Array.isArray || function (t) {
                return "array" === f.type(t)
            }
            ,
            isWindow: function (t) {
                return null != t && t == t.window
            },
            isNumeric: function (t) {
                var e = t && t.toString();
                return !f.isArray(t) && e - parseFloat(e) + 1 >= 0
            },
            isEmptyObject: function (t) {
                var e;
                for (e in t)
                    return !1;
                return !0
            },
            isPlainObject: function (t) {
                var e;
                if (!t || "object" !== f.type(t) || t.nodeType || f.isWindow(t))
                    return !1;
                try {
                    if (t.constructor && !c.call(t, "constructor") && !c.call(t.constructor.prototype, "isPrototypeOf"))
                        return !1
                } catch (n) {
                    return !1
                }
                if (!d.ownFirst)
                    for (e in t)
                        return c.call(t, e);
                for (e in t)
                    ;
                return void 0 === e || c.call(t, e)
            },
            type: function (t) {
                return null == t ? t + "" : "object" == typeof t || "function" == typeof t ? l[u.call(t)] || "object" : typeof t
            },
            globalEval: function (e) {
                e && f.trim(e) && (t.execScript || function (e) {
                    t.eval.call(t, e)
                }
                )(e)
            },
            camelCase: function (t) {
                return t.replace(g, "ms-").replace(m, v)
            },
            nodeName: function (t, e) {
                return t.nodeName && t.nodeName.toLowerCase() === e.toLowerCase()
            },
            each: function (t, e) {
                var n, i = 0;
                if (y(t))
                    for (n = t.length; n > i && !1 !== e.call(t[i], i, t[i]); i++)
                        ;
                else
                    for (i in t)
                        if (!1 === e.call(t[i], i, t[i]))
                            break;
                return t
            },
            trim: function (t) {
                return null == t ? "" : (t + "").replace(h, "")
            },
            makeArray: function (t, e) {
                var n = e || [];
                return null != t && (y(Object(t)) ? f.merge(n, "string" == typeof t ? [t] : t) : s.call(n, t)),
                    n
            },
            inArray: function (t, e, n) {
                var i;
                if (e) {
                    if (a)
                        return a.call(e, t, n);
                    for (i = e.length,
                        n = n ? 0 > n ? Math.max(0, i + n) : n : 0; i > n; n++)
                        if (n in e && e[n] === t)
                            return n
                }
                return -1
            },
            merge: function (t, e) {
                for (var n = +e.length, i = 0, o = t.length; n > i;)
                    t[o++] = e[i++];
                if (n != n)
                    for (; void 0 !== e[i];)
                        t[o++] = e[i++];
                return t.length = o,
                    t
            },
            grep: function (t, e, n) {
                for (var i = [], o = 0, r = t.length, s = !n; r > o; o++)
                    !e(t[o], o) !== s && i.push(t[o]);
                return i
            },
            map: function (t, e, n) {
                var i, o, s = 0, a = [];
                if (y(t))
                    for (i = t.length; i > s; s++)
                        null != (o = e(t[s], s, n)) && a.push(o);
                else
                    for (s in t)
                        null != (o = e(t[s], s, n)) && a.push(o);
                return r.apply([], a)
            },
            guid: 1,
            proxy: function (t, e) {
                var n, i, r;
                return "string" == typeof e && (r = t[e],
                    e = t,
                    t = r),
                    f.isFunction(t) ? (n = o.call(arguments, 2),
                        (i = function () {
                            return t.apply(e || this, n.concat(o.call(arguments)))
                        }
                        ).guid = t.guid = t.guid || f.guid++,
                        i) : void 0
            },
            now: function () {
                return +new Date
            },
            support: d
        }),
        "function" == typeof Symbol && (f.fn[Symbol.iterator] = n[Symbol.iterator]),
        f.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), (function (t, e) {
            l["[object " + e + "]"] = e.toLowerCase()
        }
        ));
    var b = function (t) {
        var e, n, i, o, r, s, a, l, u, c, d, p, f, h, g, m, v, y, b, x = "sizzle" + 1 * new Date, w = t.document, T = 0, C = 0, E = rt(), S = rt(), k = rt(), N = function (t, e) {
            return t === e && (d = !0),
                0
        }, $ = {}.hasOwnProperty, A = [], D = A.pop, j = A.push, L = A.push, O = A.slice, I = function (t, e) {
            for (var n = 0, i = t.length; i > n; n++)
                if (t[n] === e)
                    return n;
            return -1
        }, H = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", R = "[\\x20\\t\\r\\n\\f]", q = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+", F = "\\[" + R + "*(" + q + ")(?:" + R + "*([*^$|!~]?=)" + R + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + q + "))|)" + R + "*\\]", _ = ":(" + q + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + F + ")*)|.*)\\)|)", P = new RegExp(R + "+", "g"), M = new RegExp("^" + R + "+|((?:^|[^\\\\])(?:\\\\.)*)" + R + "+$", "g"), B = new RegExp("^" + R + "*," + R + "*"), W = new RegExp("^" + R + "*([>+~]|" + R + ")" + R + "*"), z = new RegExp("=" + R + "*([^\\]'\"]*?)" + R + "*\\]", "g"), U = new RegExp(_), X = new RegExp("^" + q + "$"), V = {
            ID: new RegExp("^#(" + q + ")"),
            CLASS: new RegExp("^\\.(" + q + ")"),
            TAG: new RegExp("^(" + q + "|[*])"),
            ATTR: new RegExp("^" + F),
            PSEUDO: new RegExp("^" + _),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + R + "*(even|odd|(([+-]|)(\\d*)n|)" + R + "*(?:([+-]|)" + R + "*(\\d+)|))" + R + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + H + ")$", "i"),
            needsContext: new RegExp("^" + R + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + R + "*((?:-\\d)?\\d*)" + R + "*\\)|)(?=[^-]|$)", "i")
        }, Q = /^(?:input|select|textarea|button)$/i, J = /^h\d$/i, Y = /^[^{]+\{\s*\[native \w/, G = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, K = /[+~]/, Z = /'|\\/g, tt = new RegExp("\\\\([\\da-f]{1,6}" + R + "?|(" + R + ")|.)", "ig"), et = function (t, e, n) {
            var i = "0x" + e - 65536;
            return i != i || n ? e : 0 > i ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
        }, it = function () {
            p()
        };
        try {
            L.apply(A = O.call(w.childNodes), w.childNodes)
        } catch (nt) {
            L = {
                apply: A.length ? function (t, e) {
                    j.apply(t, O.call(e))
                }
                    : function (t, e) {
                        for (var n = t.length, i = 0; t[n++] = e[i++];)
                            ;
                        t.length = n - 1
                    }
            }
        }
        function ot(t, e, i, o) {
            var r, a, u, c, d, h, v, y, T = e && e.ownerDocument, C = e ? e.nodeType : 9;
            if (i = i || [],
                "string" != typeof t || !t || 1 !== C && 9 !== C && 11 !== C)
                return i;
            if (!o && ((e ? e.ownerDocument || e : w) !== f && p(e),
                e = e || f,
                g)) {
                if (11 !== C && (h = G.exec(t)))
                    if (r = h[1]) {
                        if (9 === C) {
                            if (!(u = e.getElementById(r)))
                                return i;
                            if (u.id === r)
                                return i.push(u),
                                    i
                        } else if (T && (u = T.getElementById(r)) && b(e, u) && u.id === r)
                            return i.push(u),
                                i
                    } else {
                        if (h[2])
                            return L.apply(i, e.getElementsByTagName(t)),
                                i;
                        if ((r = h[3]) && n.getElementsByClassName && e.getElementsByClassName)
                            return L.apply(i, e.getElementsByClassName(r)),
                                i
                    }
                if (n.qsa && !k[t + " "] && (!m || !m.test(t))) {
                    if (1 !== C)
                        T = e,
                            y = t;
                    else if ("object" !== e.nodeName.toLowerCase()) {
                        for ((c = e.getAttribute("id")) ? c = c.replace(Z, "\\$&") : e.setAttribute("id", c = x),
                            a = (v = s(t)).length,
                            d = X.test(c) ? "#" + c : "[id='" + c + "']"; a--;)
                            v[a] = d + " " + gt(v[a]);
                        y = v.join(","),
                            T = K.test(t) && ft(e.parentNode) || e
                    }
                    if (y)
                        try {
                            return L.apply(i, T.querySelectorAll(y)),
                                i
                        } catch (E) { } finally {
                            c === x && e.removeAttribute("id")
                        }
                }
            }
            return l(t.replace(M, "$1"), e, i, o)
        }
        function rt() {
            var t = [];
            return function e(n, o) {
                return t.push(n + " ") > i.cacheLength && delete e[t.shift()],
                    e[n + " "] = o
            }
        }
        function st(t) {
            return t[x] = !0,
                t
        }
        function at(t) {
            var e = f.createElement("div");
            try {
                return !!t(e)
            } catch (n) {
                return !1
            } finally {
                e.parentNode && e.parentNode.removeChild(e),
                    e = null
            }
        }
        function lt(t, e) {
            for (var n = t.split("|"), o = n.length; o--;)
                i.attrHandle[n[o]] = e
        }
        function ut(t, e) {
            var n = e && t
                , i = n && 1 === t.nodeType && 1 === e.nodeType && (~e.sourceIndex || 1 << 31) - (~t.sourceIndex || 1 << 31);
            if (i)
                return i;
            if (n)
                for (; n = n.nextSibling;)
                    if (n === e)
                        return -1;
            return t ? 1 : -1
        }
        function ct(t) {
            return function (e) {
                return "input" === e.nodeName.toLowerCase() && e.type === t
            }
        }
        function dt(t) {
            return function (e) {
                var n = e.nodeName.toLowerCase();
                return ("input" === n || "button" === n) && e.type === t
            }
        }
        function pt(t) {
            return st((function (e) {
                return e = +e,
                    st((function (n, i) {
                        for (var o, r = t([], n.length, e), s = r.length; s--;)
                            n[o = r[s]] && (n[o] = !(i[o] = n[o]))
                    }
                    ))
            }
            ))
        }
        function ft(t) {
            return t && void 0 !== t.getElementsByTagName && t
        }
        for (e in n = ot.support = {},
            r = ot.isXML = function (t) {
                var e = t && (t.ownerDocument || t).documentElement;
                return !!e && "HTML" !== e.nodeName
            }
            ,
            p = ot.setDocument = function (t) {
                var e, o, s = t ? t.ownerDocument || t : w;
                return s !== f && 9 === s.nodeType && s.documentElement ? (h = (f = s).documentElement,
                    g = !r(f),
                    (o = f.defaultView) && o.top !== o && (o.addEventListener ? o.addEventListener("unload", it, !1) : o.attachEvent && o.attachEvent("onunload", it)),
                    n.attributes = at((function (t) {
                        return t.className = "i",
                            !t.getAttribute("className")
                    }
                    )),
                    n.getElementsByTagName = at((function (t) {
                        return t.appendChild(f.createComment("")),
                            !t.getElementsByTagName("*").length
                    }
                    )),
                    n.getElementsByClassName = Y.test(f.getElementsByClassName),
                    n.getById = at((function (t) {
                        return h.appendChild(t).id = x,
                            !f.getElementsByName || !f.getElementsByName(x).length
                    }
                    )),
                    n.getById ? (i.find.ID = function (t, e) {
                        if (void 0 !== e.getElementById && g) {
                            var n = e.getElementById(t);
                            return n ? [n] : []
                        }
                    }
                        ,
                        i.filter.ID = function (t) {
                            var e = t.replace(tt, et);
                            return function (t) {
                                return t.getAttribute("id") === e
                            }
                        }
                    ) : (delete i.find.ID,
                        i.filter.ID = function (t) {
                            var e = t.replace(tt, et);
                            return function (t) {
                                var n = void 0 !== t.getAttributeNode && t.getAttributeNode("id");
                                return n && n.value === e
                            }
                        }
                    ),
                    i.find.TAG = n.getElementsByTagName ? function (t, e) {
                        return void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t) : n.qsa ? e.querySelectorAll(t) : void 0
                    }
                        : function (t, e) {
                            var n, i = [], o = 0, r = e.getElementsByTagName(t);
                            if ("*" === t) {
                                for (; n = r[o++];)
                                    1 === n.nodeType && i.push(n);
                                return i
                            }
                            return r
                        }
                    ,
                    i.find.CLASS = n.getElementsByClassName && function (t, e) {
                        return void 0 !== e.getElementsByClassName && g ? e.getElementsByClassName(t) : void 0
                    }
                    ,
                    v = [],
                    m = [],
                    (n.qsa = Y.test(f.querySelectorAll)) && (at((function (t) {
                        h.appendChild(t).innerHTML = "<a id='" + x + "'></a><select id='" + x + "-\r\\' msallowcapture=''><option selected=''></option></select>",
                            t.querySelectorAll("[msallowcapture^='']").length && m.push("[*^$]=" + R + "*(?:''|\"\")"),
                            t.querySelectorAll("[selected]").length || m.push("\\[" + R + "*(?:value|" + H + ")"),
                            t.querySelectorAll("[id~=" + x + "-]").length || m.push("~="),
                            t.querySelectorAll(":checked").length || m.push(":checked"),
                            t.querySelectorAll("a#" + x + "+*").length || m.push(".#.+[+~]")
                    }
                    )),
                        at((function (t) {
                            var e = f.createElement("input");
                            e.setAttribute("type", "hidden"),
                                t.appendChild(e).setAttribute("name", "D"),
                                t.querySelectorAll("[name=d]").length && m.push("name" + R + "*[*^$|!~]?="),
                                t.querySelectorAll(":enabled").length || m.push(":enabled", ":disabled"),
                                t.querySelectorAll("*,:x"),
                                m.push(",.*:")
                        }
                        ))),
                    (n.matchesSelector = Y.test(y = h.matches || h.webkitMatchesSelector || h.mozMatchesSelector || h.oMatchesSelector || h.msMatchesSelector)) && at((function (t) {
                        n.disconnectedMatch = y.call(t, "div"),
                            y.call(t, "[s!='']:x"),
                            v.push("!=", _)
                    }
                    )),
                    m = m.length && new RegExp(m.join("|")),
                    v = v.length && new RegExp(v.join("|")),
                    e = Y.test(h.compareDocumentPosition),
                    b = e || Y.test(h.contains) ? function (t, e) {
                        var n = 9 === t.nodeType ? t.documentElement : t
                            , i = e && e.parentNode;
                        return t === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : t.compareDocumentPosition && 16 & t.compareDocumentPosition(i)))
                    }
                        : function (t, e) {
                            if (e)
                                for (; e = e.parentNode;)
                                    if (e === t)
                                        return !0;
                            return !1
                        }
                    ,
                    N = e ? function (t, e) {
                        if (t === e)
                            return d = !0,
                                0;
                        var i = !t.compareDocumentPosition - !e.compareDocumentPosition;
                        return i || (1 & (i = (t.ownerDocument || t) === (e.ownerDocument || e) ? t.compareDocumentPosition(e) : 1) || !n.sortDetached && e.compareDocumentPosition(t) === i ? t === f || t.ownerDocument === w && b(w, t) ? -1 : e === f || e.ownerDocument === w && b(w, e) ? 1 : c ? I(c, t) - I(c, e) : 0 : 4 & i ? -1 : 1)
                    }
                        : function (t, e) {
                            if (t === e)
                                return d = !0,
                                    0;
                            var n, i = 0, o = t.parentNode, r = e.parentNode, s = [t], a = [e];
                            if (!o || !r)
                                return t === f ? -1 : e === f ? 1 : o ? -1 : r ? 1 : c ? I(c, t) - I(c, e) : 0;
                            if (o === r)
                                return ut(t, e);
                            for (n = t; n = n.parentNode;)
                                s.unshift(n);
                            for (n = e; n = n.parentNode;)
                                a.unshift(n);
                            for (; s[i] === a[i];)
                                i++;
                            return i ? ut(s[i], a[i]) : s[i] === w ? -1 : a[i] === w ? 1 : 0
                        }
                    ,
                    f) : f
            }
            ,
            ot.matches = function (t, e) {
                return ot(t, null, null, e)
            }
            ,
            ot.matchesSelector = function (t, e) {
                if ((t.ownerDocument || t) !== f && p(t),
                    e = e.replace(z, "='$1']"),
                    n.matchesSelector && g && !k[e + " "] && (!v || !v.test(e)) && (!m || !m.test(e)))
                    try {
                        var i = y.call(t, e);
                        if (i || n.disconnectedMatch || t.document && 11 !== t.document.nodeType)
                            return i
                    } catch (o) { }
                return ot(e, f, null, [t]).length > 0
            }
            ,
            ot.contains = function (t, e) {
                return (t.ownerDocument || t) !== f && p(t),
                    b(t, e)
            }
            ,
            ot.attr = function (t, e) {
                (t.ownerDocument || t) !== f && p(t);
                var o = i.attrHandle[e.toLowerCase()]
                    , r = o && $.call(i.attrHandle, e.toLowerCase()) ? o(t, e, !g) : void 0;
                return void 0 !== r ? r : n.attributes || !g ? t.getAttribute(e) : (r = t.getAttributeNode(e)) && r.specified ? r.value : null
            }
            ,
            ot.error = function (t) {
                throw new Error("Syntax error, unrecognized expression: " + t)
            }
            ,
            ot.uniqueSort = function (t) {
                var e, i = [], o = 0, r = 0;
                if (d = !n.detectDuplicates,
                    c = !n.sortStable && t.slice(0),
                    t.sort(N),
                    d) {
                    for (; e = t[r++];)
                        e === t[r] && (o = i.push(r));
                    for (; o--;)
                        t.splice(i[o], 1)
                }
                return c = null,
                    t
            }
            ,
            o = ot.getText = function (t) {
                var e, n = "", i = 0, r = t.nodeType;
                if (r) {
                    if (1 === r || 9 === r || 11 === r) {
                        if ("string" == typeof t.textContent)
                            return t.textContent;
                        for (t = t.firstChild; t; t = t.nextSibling)
                            n += o(t)
                    } else if (3 === r || 4 === r)
                        return t.nodeValue
                } else
                    for (; e = t[i++];)
                        n += o(e);
                return n
            }
            ,
            (i = ot.selectors = {
                cacheLength: 50,
                createPseudo: st,
                match: V,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function (t) {
                        return t[1] = t[1].replace(tt, et),
                            t[3] = (t[3] || t[4] || t[5] || "").replace(tt, et),
                            "~=" === t[2] && (t[3] = " " + t[3] + " "),
                            t.slice(0, 4)
                    },
                    CHILD: function (t) {
                        return t[1] = t[1].toLowerCase(),
                            "nth" === t[1].slice(0, 3) ? (t[3] || ot.error(t[0]),
                                t[4] = +(t[4] ? t[5] + (t[6] || 1) : 2 * ("even" === t[3] || "odd" === t[3])),
                                t[5] = +(t[7] + t[8] || "odd" === t[3])) : t[3] && ot.error(t[0]),
                            t
                    },
                    PSEUDO: function (t) {
                        var e, n = !t[6] && t[2];
                        return V.CHILD.test(t[0]) ? null : (t[3] ? t[2] = t[4] || t[5] || "" : n && U.test(n) && (e = s(n, !0)) && (e = n.indexOf(")", n.length - e) - n.length) && (t[0] = t[0].slice(0, e),
                            t[2] = n.slice(0, e)),
                            t.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function (t) {
                        var e = t.replace(tt, et).toLowerCase();
                        return "*" === t ? function () {
                            return !0
                        }
                            : function (t) {
                                return t.nodeName && t.nodeName.toLowerCase() === e
                            }
                    },
                    CLASS: function (t) {
                        var e = E[t + " "];
                        return e || (e = new RegExp("(^|" + R + ")" + t + "(" + R + "|$)")) && E(t, (function (t) {
                            return e.test("string" == typeof t.className && t.className || void 0 !== t.getAttribute && t.getAttribute("class") || "")
                        }
                        ))
                    },
                    ATTR: function (t, e, n) {
                        return function (i) {
                            var o = ot.attr(i, t);
                            return null == o ? "!=" === e : !e || (o += "",
                                "=" === e ? o === n : "!=" === e ? o !== n : "^=" === e ? n && 0 === o.indexOf(n) : "*=" === e ? n && o.indexOf(n) > -1 : "$=" === e ? n && o.slice(-n.length) === n : "~=" === e ? (" " + o.replace(P, " ") + " ").indexOf(n) > -1 : "|=" === e && (o === n || o.slice(0, n.length + 1) === n + "-"))
                        }
                    },
                    CHILD: function (t, e, n, i, o) {
                        var r = "nth" !== t.slice(0, 3)
                            , s = "last" !== t.slice(-4)
                            , a = "of-type" === e;
                        return 1 === i && 0 === o ? function (t) {
                            return !!t.parentNode
                        }
                            : function (e, n, l) {
                                var u, c, d, p, f, h, g = r !== s ? "nextSibling" : "previousSibling", m = e.parentNode, v = a && e.nodeName.toLowerCase(), y = !l && !a, b = !1;
                                if (m) {
                                    if (r) {
                                        for (; g;) {
                                            for (p = e; p = p[g];)
                                                if (a ? p.nodeName.toLowerCase() === v : 1 === p.nodeType)
                                                    return !1;
                                            h = g = "only" === t && !h && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (h = [s ? m.firstChild : m.lastChild],
                                        s && y) {
                                        for (b = (f = (u = (c = (d = (p = m)[x] || (p[x] = {}))[p.uniqueID] || (d[p.uniqueID] = {}))[t] || [])[0] === T && u[1]) && u[2],
                                            p = f && m.childNodes[f]; p = ++f && p && p[g] || (b = f = 0) || h.pop();)
                                            if (1 === p.nodeType && ++b && p === e) {
                                                c[t] = [T, f, b];
                                                break
                                            }
                                    } else if (y && (b = f = (u = (c = (d = (p = e)[x] || (p[x] = {}))[p.uniqueID] || (d[p.uniqueID] = {}))[t] || [])[0] === T && u[1]),
                                        !1 === b)
                                        for (; (p = ++f && p && p[g] || (b = f = 0) || h.pop()) && ((a ? p.nodeName.toLowerCase() !== v : 1 !== p.nodeType) || !++b || (y && ((c = (d = p[x] || (p[x] = {}))[p.uniqueID] || (d[p.uniqueID] = {}))[t] = [T, b]),
                                            p !== e));)
                                            ;
                                    return (b -= o) === i || b % i == 0 && b / i >= 0
                                }
                            }
                    },
                    PSEUDO: function (t, e) {
                        var n, o = i.pseudos[t] || i.setFilters[t.toLowerCase()] || ot.error("unsupported pseudo: " + t);
                        return o[x] ? o(e) : o.length > 1 ? (n = [t, t, "", e],
                            i.setFilters.hasOwnProperty(t.toLowerCase()) ? st((function (t, n) {
                                for (var i, r = o(t, e), s = r.length; s--;)
                                    t[i = I(t, r[s])] = !(n[i] = r[s])
                            }
                            )) : function (t) {
                                return o(t, 0, n)
                            }
                        ) : o
                    }
                },
                pseudos: {
                    not: st((function (t) {
                        var e = []
                            , n = []
                            , i = a(t.replace(M, "$1"));
                        return i[x] ? st((function (t, e, n, o) {
                            for (var r, s = i(t, null, o, []), a = t.length; a--;)
                                (r = s[a]) && (t[a] = !(e[a] = r))
                        }
                        )) : function (t, o, r) {
                            return e[0] = t,
                                i(e, null, r, n),
                                e[0] = null,
                                !n.pop()
                        }
                    }
                    )),
                    has: st((function (t) {
                        return function (e) {
                            return ot(t, e).length > 0
                        }
                    }
                    )),
                    contains: st((function (t) {
                        return t = t.replace(tt, et),
                            function (e) {
                                return (e.textContent || e.innerText || o(e)).indexOf(t) > -1
                            }
                    }
                    )),
                    lang: st((function (t) {
                        return X.test(t || "") || ot.error("unsupported lang: " + t),
                            t = t.replace(tt, et).toLowerCase(),
                            function (e) {
                                var n;
                                do {
                                    if (n = g ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang"))
                                        return (n = n.toLowerCase()) === t || 0 === n.indexOf(t + "-")
                                } while ((e = e.parentNode) && 1 === e.nodeType);
                                return !1
                            }
                    }
                    )),
                    target: function (e) {
                        var n = t.location && t.location.hash;
                        return n && n.slice(1) === e.id
                    },
                    root: function (t) {
                        return t === h
                    },
                    focus: function (t) {
                        return t === f.activeElement && (!f.hasFocus || f.hasFocus()) && !!(t.type || t.href || ~t.tabIndex)
                    },
                    enabled: function (t) {
                        return !1 === t.disabled
                    },
                    disabled: function (t) {
                        return !0 === t.disabled
                    },
                    checked: function (t) {
                        var e = t.nodeName.toLowerCase();
                        return "input" === e && !!t.checked || "option" === e && !!t.selected
                    },
                    selected: function (t) {
                        return !0 === t.selected
                    },
                    empty: function (t) {
                        for (t = t.firstChild; t; t = t.nextSibling)
                            if (t.nodeType < 6)
                                return !1;
                        return !0
                    },
                    parent: function (t) {
                        return !i.pseudos.empty(t)
                    },
                    header: function (t) {
                        return J.test(t.nodeName)
                    },
                    input: function (t) {
                        return Q.test(t.nodeName)
                    },
                    button: function (t) {
                        var e = t.nodeName.toLowerCase();
                        return "input" === e && "button" === t.type || "button" === e
                    },
                    text: function (t) {
                        var e;
                        return "input" === t.nodeName.toLowerCase() && "text" === t.type && (null == (e = t.getAttribute("type")) || "text" === e.toLowerCase())
                    },
                    first: pt((function () {
                        return [0]
                    }
                    )),
                    last: pt((function (t, e) {
                        return [e - 1]
                    }
                    )),
                    eq: pt((function (t, e, n) {
                        return [0 > n ? n + e : n]
                    }
                    )),
                    even: pt((function (t, e) {
                        for (var n = 0; e > n; n += 2)
                            t.push(n);
                        return t
                    }
                    )),
                    odd: pt((function (t, e) {
                        for (var n = 1; e > n; n += 2)
                            t.push(n);
                        return t
                    }
                    )),
                    lt: pt((function (t, e, n) {
                        for (var i = 0 > n ? n + e : n; --i >= 0;)
                            t.push(i);
                        return t
                    }
                    )),
                    gt: pt((function (t, e, n) {
                        for (var i = 0 > n ? n + e : n; ++i < e;)
                            t.push(i);
                        return t
                    }
                    ))
                }
            }).pseudos.nth = i.pseudos.eq,
        {
            radio: !0,
            checkbox: !0,
            file: !0,
            password: !0,
            image: !0
        })
            i.pseudos[e] = ct(e);
        for (e in {
            submit: !0,
            reset: !0
        })
            i.pseudos[e] = dt(e);
        function ht() { }
        function gt(t) {
            for (var e = 0, n = t.length, i = ""; n > e; e++)
                i += t[e].value;
            return i
        }
        function mt(t, e, n) {
            var i = e.dir
                , o = n && "parentNode" === i
                , r = C++;
            return e.first ? function (e, n, r) {
                for (; e = e[i];)
                    if (1 === e.nodeType || o)
                        return t(e, n, r)
            }
                : function (e, n, s) {
                    var a, l, u, c = [T, r];
                    if (s) {
                        for (; e = e[i];)
                            if ((1 === e.nodeType || o) && t(e, n, s))
                                return !0
                    } else
                        for (; e = e[i];)
                            if (1 === e.nodeType || o) {
                                if ((a = (l = (u = e[x] || (e[x] = {}))[e.uniqueID] || (u[e.uniqueID] = {}))[i]) && a[0] === T && a[1] === r)
                                    return c[2] = a[2];
                                if (l[i] = c,
                                    c[2] = t(e, n, s))
                                    return !0
                            }
                }
        }
        function vt(t) {
            return t.length > 1 ? function (e, n, i) {
                for (var o = t.length; o--;)
                    if (!t[o](e, n, i))
                        return !1;
                return !0
            }
                : t[0]
        }
        function yt(t, e, n, i, o) {
            for (var r, s = [], a = 0, l = t.length, u = null != e; l > a; a++)
                (r = t[a]) && (n && !n(r, i, o) || (s.push(r),
                    u && e.push(a)));
            return s
        }
        function bt(t, e, n, i, o, r) {
            return i && !i[x] && (i = bt(i)),
                o && !o[x] && (o = bt(o, r)),
                st((function (r, s, a, l) {
                    var u, c, d, p = [], f = [], h = s.length, g = r || function (t, e, n) {
                        for (var i = 0, o = e.length; o > i; i++)
                            ot(t, e[i], n);
                        return n
                    }(e || "*", a.nodeType ? [a] : a, []), m = !t || !r && e ? g : yt(g, p, t, a, l), v = n ? o || (r ? t : h || i) ? [] : s : m;
                    if (n && n(m, v, a, l),
                        i)
                        for (u = yt(v, f),
                            i(u, [], a, l),
                            c = u.length; c--;)
                            (d = u[c]) && (v[f[c]] = !(m[f[c]] = d));
                    if (r) {
                        if (o || t) {
                            if (o) {
                                for (u = [],
                                    c = v.length; c--;)
                                    (d = v[c]) && u.push(m[c] = d);
                                o(null, v = [], u, l)
                            }
                            for (c = v.length; c--;)
                                (d = v[c]) && (u = o ? I(r, d) : p[c]) > -1 && (r[u] = !(s[u] = d))
                        }
                    } else
                        v = yt(v === s ? v.splice(h, v.length) : v),
                            o ? o(null, s, v, l) : L.apply(s, v)
                }
                ))
        }
        function xt(t) {
            for (var e, n, o, r = t.length, s = i.relative[t[0].type], a = s || i.relative[" "], l = s ? 1 : 0, c = mt((function (t) {
                return t === e
            }
            ), a, !0), d = mt((function (t) {
                return I(e, t) > -1
            }
            ), a, !0), p = [function (t, n, i) {
                var o = !s && (i || n !== u) || ((e = n).nodeType ? c(t, n, i) : d(t, n, i));
                return e = null,
                    o
            }
            ]; r > l; l++)
                if (n = i.relative[t[l].type])
                    p = [mt(vt(p), n)];
                else {
                    if ((n = i.filter[t[l].type].apply(null, t[l].matches))[x]) {
                        for (o = ++l; r > o && !i.relative[t[o].type]; o++)
                            ;
                        return bt(l > 1 && vt(p), l > 1 && gt(t.slice(0, l - 1).concat({
                            value: " " === t[l - 2].type ? "*" : ""
                        })).replace(M, "$1"), n, o > l && xt(t.slice(l, o)), r > o && xt(t = t.slice(o)), r > o && gt(t))
                    }
                    p.push(n)
                }
            return vt(p)
        }
        function wt(t, e) {
            var n = e.length > 0
                , o = t.length > 0
                , r = function (r, s, a, l, c) {
                    var d, h, m, v = 0, y = "0", b = r && [], x = [], w = u, C = r || o && i.find.TAG("*", c), E = T += null == w ? 1 : Math.random() || .1, S = C.length;
                    for (c && (u = s === f || s || c); y !== S && null != (d = C[y]); y++) {
                        if (o && d) {
                            for (h = 0,
                                s || d.ownerDocument === f || (p(d),
                                    a = !g); m = t[h++];)
                                if (m(d, s || f, a)) {
                                    l.push(d);
                                    break
                                }
                            c && (T = E)
                        }
                        n && ((d = !m && d) && v--,
                            r && b.push(d))
                    }
                    if (v += y,
                        n && y !== v) {
                        for (h = 0; m = e[h++];)
                            m(b, x, s, a);
                        if (r) {
                            if (v > 0)
                                for (; y--;)
                                    b[y] || x[y] || (x[y] = D.call(l));
                            x = yt(x)
                        }
                        L.apply(l, x),
                            c && !r && x.length > 0 && v + e.length > 1 && ot.uniqueSort(l)
                    }
                    return c && (T = E,
                        u = w),
                        b
                };
            return n ? st(r) : r
        }
        return ht.prototype = i.filters = i.pseudos,
            i.setFilters = new ht,
            s = ot.tokenize = function (t, e) {
                var n, o, r, s, a, l, u, c = S[t + " "];
                if (c)
                    return e ? 0 : c.slice(0);
                for (a = t,
                    l = [],
                    u = i.preFilter; a;) {
                    for (s in n && !(o = B.exec(a)) || (o && (a = a.slice(o[0].length) || a),
                        l.push(r = [])),
                        n = !1,
                        (o = W.exec(a)) && (n = o.shift(),
                            r.push({
                                value: n,
                                type: o[0].replace(M, " ")
                            }),
                            a = a.slice(n.length)),
                        i.filter)
                        !(o = V[s].exec(a)) || u[s] && !(o = u[s](o)) || (n = o.shift(),
                            r.push({
                                value: n,
                                type: s,
                                matches: o
                            }),
                            a = a.slice(n.length));
                    if (!n)
                        break
                }
                return e ? a.length : a ? ot.error(t) : S(t, l).slice(0)
            }
            ,
            a = ot.compile = function (t, e) {
                var n, i = [], o = [], r = k[t + " "];
                if (!r) {
                    for (e || (e = s(t)),
                        n = e.length; n--;)
                        (r = xt(e[n]))[x] ? i.push(r) : o.push(r);
                    (r = k(t, wt(o, i))).selector = t
                }
                return r
            }
            ,
            l = ot.select = function (t, e, o, r) {
                var l, u, c, d, p, f = "function" == typeof t && t, h = !r && s(t = f.selector || t);
                if (o = o || [],
                    1 === h.length) {
                    if ((u = h[0] = h[0].slice(0)).length > 2 && "ID" === (c = u[0]).type && n.getById && 9 === e.nodeType && g && i.relative[u[1].type]) {
                        if (!(e = (i.find.ID(c.matches[0].replace(tt, et), e) || [])[0]))
                            return o;
                        f && (e = e.parentNode),
                            t = t.slice(u.shift().value.length)
                    }
                    for (l = V.needsContext.test(t) ? 0 : u.length; l-- && !i.relative[d = (c = u[l]).type];)
                        if ((p = i.find[d]) && (r = p(c.matches[0].replace(tt, et), K.test(u[0].type) && ft(e.parentNode) || e))) {
                            if (u.splice(l, 1),
                                !(t = r.length && gt(u)))
                                return L.apply(o, r),
                                    o;
                            break
                        }
                }
                return (f || a(t, h))(r, e, !g, o, !e || K.test(t) && ft(e.parentNode) || e),
                    o
            }
            ,
            n.sortStable = x.split("").sort(N).join("") === x,
            n.detectDuplicates = !!d,
            p(),
            n.sortDetached = at((function (t) {
                return 1 & t.compareDocumentPosition(f.createElement("div"))
            }
            )),
            at((function (t) {
                return t.innerHTML = "<a href='#'></a>",
                    "#" === t.firstChild.getAttribute("href")
            }
            )) || lt("type|href|height|width", (function (t, e, n) {
                return n ? void 0 : t.getAttribute(e, "type" === e.toLowerCase() ? 1 : 2)
            }
            )),
            n.attributes && at((function (t) {
                return t.innerHTML = "<input/>",
                    t.firstChild.setAttribute("value", ""),
                    "" === t.firstChild.getAttribute("value")
            }
            )) || lt("value", (function (t, e, n) {
                return n || "input" !== t.nodeName.toLowerCase() ? void 0 : t.defaultValue
            }
            )),
            at((function (t) {
                return null == t.getAttribute("disabled")
            }
            )) || lt(H, (function (t, e, n) {
                var i;
                return n ? void 0 : !0 === t[e] ? e.toLowerCase() : (i = t.getAttributeNode(e)) && i.specified ? i.value : null
            }
            )),
            ot
    }(t);
    f.find = b,
        f.expr = b.selectors,
        f.expr[":"] = f.expr.pseudos,
        f.uniqueSort = f.unique = b.uniqueSort,
        f.text = b.getText,
        f.isXMLDoc = b.isXML,
        f.contains = b.contains;
    var x = function (t, e, n) {
        for (var i = [], o = void 0 !== n; (t = t[e]) && 9 !== t.nodeType;)
            if (1 === t.nodeType) {
                if (o && f(t).is(n))
                    break;
                i.push(t)
            }
        return i
    }
        , w = function (t, e) {
            for (var n = []; t; t = t.nextSibling)
                1 === t.nodeType && t !== e && n.push(t);
            return n
        }
        , T = f.expr.match.needsContext
        , C = /^<([\w-]+)\s*\/?>(?:<\/\1>|)$/
        , E = /^.[^:#\[\.,]*$/;
    function S(t, e, n) {
        if (f.isFunction(e))
            return f.grep(t, (function (t, i) {
                return !!e.call(t, i, t) !== n
            }
            ));
        if (e.nodeType)
            return f.grep(t, (function (t) {
                return t === e !== n
            }
            ));
        if ("string" == typeof e) {
            if (E.test(e))
                return f.filter(e, t, n);
            e = f.filter(e, t)
        }
        return f.grep(t, (function (t) {
            return f.inArray(t, e) > -1 !== n
        }
        ))
    }
    f.filter = function (t, e, n) {
        var i = e[0];
        return n && (t = ":not(" + t + ")"),
            1 === e.length && 1 === i.nodeType ? f.find.matchesSelector(i, t) ? [i] : [] : f.find.matches(t, f.grep(e, (function (t) {
                return 1 === t.nodeType
            }
            )))
    }
        ,
        f.fn.extend({
            find: function (t) {
                var e, n = [], i = this, o = i.length;
                if ("string" != typeof t)
                    return this.pushStack(f(t).filter((function () {
                        for (e = 0; o > e; e++)
                            if (f.contains(i[e], this))
                                return !0
                    }
                    )));
                for (e = 0; o > e; e++)
                    f.find(t, i[e], n);
                return (n = this.pushStack(o > 1 ? f.unique(n) : n)).selector = this.selector ? this.selector + " " + t : t,
                    n
            },
            filter: function (t) {
                return this.pushStack(S(this, t || [], !1))
            },
            not: function (t) {
                return this.pushStack(S(this, t || [], !0))
            },
            is: function (t) {
                return !!S(this, "string" == typeof t && T.test(t) ? f(t) : t || [], !1).length
            }
        });
    var k, N = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/;
    (f.fn.init = function (t, e, n) {
        var o, r;
        if (!t)
            return this;
        if (n = n || k,
            "string" == typeof t) {
            if (!(o = "<" === t.charAt(0) && ">" === t.charAt(t.length - 1) && t.length >= 3 ? [null, t, null] : N.exec(t)) || !o[1] && e)
                return !e || e.jquery ? (e || n).find(t) : this.constructor(e).find(t);
            if (o[1]) {
                if (f.merge(this, f.parseHTML(o[1], (e = e instanceof f ? e[0] : e) && e.nodeType ? e.ownerDocument || e : i, !0)),
                    C.test(o[1]) && f.isPlainObject(e))
                    for (o in e)
                        f.isFunction(this[o]) ? this[o](e[o]) : this.attr(o, e[o]);
                return this
            }
            if ((r = i.getElementById(o[2])) && r.parentNode) {
                if (r.id !== o[2])
                    return k.find(t);
                this.length = 1,
                    this[0] = r
            }
            return this.context = i,
                this.selector = t,
                this
        }
        return t.nodeType ? (this.context = this[0] = t,
            this.length = 1,
            this) : f.isFunction(t) ? void 0 !== n.ready ? n.ready(t) : t(f) : (void 0 !== t.selector && (this.selector = t.selector,
                this.context = t.context),
                f.makeArray(t, this))
    }
    ).prototype = f.fn,
        k = f(i);
    var $ = /^(?:parents|prev(?:Until|All))/
        , A = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    function D(t, e) {
        do {
            t = t[e]
        } while (t && 1 !== t.nodeType);
        return t
    }
    f.fn.extend({
        has: function (t) {
            var e, n = f(t, this), i = n.length;
            return this.filter((function () {
                for (e = 0; i > e; e++)
                    if (f.contains(this, n[e]))
                        return !0
            }
            ))
        },
        closest: function (t, e) {
            for (var n, i = 0, o = this.length, r = [], s = T.test(t) || "string" != typeof t ? f(t, e || this.context) : 0; o > i; i++)
                for (n = this[i]; n && n !== e; n = n.parentNode)
                    if (n.nodeType < 11 && (s ? s.index(n) > -1 : 1 === n.nodeType && f.find.matchesSelector(n, t))) {
                        r.push(n);
                        break
                    }
            return this.pushStack(r.length > 1 ? f.uniqueSort(r) : r)
        },
        index: function (t) {
            return t ? "string" == typeof t ? f.inArray(this[0], f(t)) : f.inArray(t.jquery ? t[0] : t, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function (t, e) {
            return this.pushStack(f.uniqueSort(f.merge(this.get(), f(t, e))))
        },
        addBack: function (t) {
            return this.add(null == t ? this.prevObject : this.prevObject.filter(t))
        }
    }),
        f.each({
            parent: function (t) {
                var e = t.parentNode;
                return e && 11 !== e.nodeType ? e : null
            },
            parents: function (t) {
                return x(t, "parentNode")
            },
            parentsUntil: function (t, e, n) {
                return x(t, "parentNode", n)
            },
            next: function (t) {
                return D(t, "nextSibling")
            },
            prev: function (t) {
                return D(t, "previousSibling")
            },
            nextAll: function (t) {
                return x(t, "nextSibling")
            },
            prevAll: function (t) {
                return x(t, "previousSibling")
            },
            nextUntil: function (t, e, n) {
                return x(t, "nextSibling", n)
            },
            prevUntil: function (t, e, n) {
                return x(t, "previousSibling", n)
            },
            siblings: function (t) {
                return w((t.parentNode || {}).firstChild, t)
            },
            children: function (t) {
                return w(t.firstChild)
            },
            contents: function (t) {
                return f.nodeName(t, "iframe") ? t.contentDocument || t.contentWindow.document : f.merge([], t.childNodes)
            }
        }, (function (t, e) {
            f.fn[t] = function (n, i) {
                var o = f.map(this, e, n);
                return "Until" !== t.slice(-5) && (i = n),
                    i && "string" == typeof i && (o = f.filter(i, o)),
                    this.length > 1 && (A[t] || (o = f.uniqueSort(o)),
                        $.test(t) && (o = o.reverse())),
                    this.pushStack(o)
            }
        }
        ));
    var j, L, O = /\S+/g;
    function I() {
        i.addEventListener ? (i.removeEventListener("DOMContentLoaded", H),
            t.removeEventListener("load", H)) : (i.detachEvent("onreadystatechange", H),
                t.detachEvent("onload", H))
    }
    function H() {
        (i.addEventListener || "load" === t.event.type || "complete" === i.readyState) && (I(),
            f.ready())
    }
    for (L in f.Callbacks = function (t) {
        t = "string" == typeof t ? function (t) {
            var e = {};
            return f.each(t.match(O) || [], (function (t, n) {
                e[n] = !0
            }
            )),
                e
        }(t) : f.extend({}, t);
        var e, n, i, o, r = [], s = [], a = -1, l = function () {
            for (o = t.once,
                i = e = !0; s.length; a = -1)
                for (n = s.shift(); ++a < r.length;)
                    !1 === r[a].apply(n[0], n[1]) && t.stopOnFalse && (a = r.length,
                        n = !1);
            t.memory || (n = !1),
                e = !1,
                o && (r = n ? [] : "")
        }, u = {
            add: function () {
                return r && (n && !e && (a = r.length - 1,
                    s.push(n)),
                    function e(n) {
                        f.each(n, (function (n, i) {
                            f.isFunction(i) ? t.unique && u.has(i) || r.push(i) : i && i.length && "string" !== f.type(i) && e(i)
                        }
                        ))
                    }(arguments),
                    n && !e && l()),
                    this
            },
            remove: function () {
                return f.each(arguments, (function (t, e) {
                    for (var n; (n = f.inArray(e, r, n)) > -1;)
                        r.splice(n, 1),
                            a >= n && a--
                }
                )),
                    this
            },
            has: function (t) {
                return t ? f.inArray(t, r) > -1 : r.length > 0
            },
            empty: function () {
                return r && (r = []),
                    this
            },
            disable: function () {
                return o = s = [],
                    r = n = "",
                    this
            },
            disabled: function () {
                return !r
            },
            lock: function () {
                return o = !0,
                    n || u.disable(),
                    this
            },
            locked: function () {
                return !!o
            },
            fireWith: function (t, n) {
                return o || (n = [t, (n = n || []).slice ? n.slice() : n],
                    s.push(n),
                    e || l()),
                    this
            },
            fire: function () {
                return u.fireWith(this, arguments),
                    this
            },
            fired: function () {
                return !!i
            }
        };
        return u
    }
        ,
        f.extend({
            Deferred: function (t) {
                var e = [["resolve", "done", f.Callbacks("once memory"), "resolved"], ["reject", "fail", f.Callbacks("once memory"), "rejected"], ["notify", "progress", f.Callbacks("memory")]]
                    , n = "pending"
                    , i = {
                        state: function () {
                            return n
                        },
                        always: function () {
                            return o.done(arguments).fail(arguments),
                                this
                        },
                        then: function () {
                            var t = arguments;
                            return f.Deferred((function (n) {
                                f.each(e, (function (e, r) {
                                    var s = f.isFunction(t[e]) && t[e];
                                    o[r[1]]((function () {
                                        var t = s && s.apply(this, arguments);
                                        t && f.isFunction(t.promise) ? t.promise().progress(n.notify).done(n.resolve).fail(n.reject) : n[r[0] + "With"](this === i ? n.promise() : this, s ? [t] : arguments)
                                    }
                                    ))
                                }
                                )),
                                    t = null
                            }
                            )).promise()
                        },
                        promise: function (t) {
                            return null != t ? f.extend(t, i) : i
                        }
                    }
                    , o = {};
                return i.pipe = i.then,
                    f.each(e, (function (t, r) {
                        var s = r[2]
                            , a = r[3];
                        i[r[1]] = s.add,
                            a && s.add((function () {
                                n = a
                            }
                            ), e[1 ^ t][2].disable, e[2][2].lock),
                            o[r[0]] = function () {
                                return o[r[0] + "With"](this === o ? i : this, arguments),
                                    this
                            }
                            ,
                            o[r[0] + "With"] = s.fireWith
                    }
                    )),
                    i.promise(o),
                    t && t.call(o, o),
                    o
            },
            when: function (t) {
                var e, n, i, r = 0, s = o.call(arguments), a = s.length, l = 1 !== a || t && f.isFunction(t.promise) ? a : 0, u = 1 === l ? t : f.Deferred(), c = function (t, n, i) {
                    return function (r) {
                        n[t] = this,
                            i[t] = arguments.length > 1 ? o.call(arguments) : r,
                            i === e ? u.notifyWith(n, i) : --l || u.resolveWith(n, i)
                    }
                };
                if (a > 1)
                    for (e = new Array(a),
                        n = new Array(a),
                        i = new Array(a); a > r; r++)
                        s[r] && f.isFunction(s[r].promise) ? s[r].promise().progress(c(r, n, e)).done(c(r, i, s)).fail(u.reject) : --l;
                return l || u.resolveWith(i, s),
                    u.promise()
            }
        }),
        f.fn.ready = function (t) {
            return f.ready.promise().done(t),
                this
        }
        ,
        f.extend({
            isReady: !1,
            readyWait: 1,
            holdReady: function (t) {
                t ? f.readyWait++ : f.ready(!0)
            },
            ready: function (t) {
                (!0 === t ? --f.readyWait : f.isReady) || (f.isReady = !0,
                    !0 !== t && --f.readyWait > 0 || (j.resolveWith(i, [f]),
                        f.fn.triggerHandler && (f(i).triggerHandler("ready"),
                            f(i).off("ready"))))
            }
        }),
        f.ready.promise = function (e) {
            if (!j)
                if (j = f.Deferred(),
                    "complete" === i.readyState || "loading" !== i.readyState && !i.documentElement.doScroll)
                    t.setTimeout(f.ready);
                else if (i.addEventListener)
                    i.addEventListener("DOMContentLoaded", H),
                        t.addEventListener("load", H);
                else {
                    i.attachEvent("onreadystatechange", H),
                        t.attachEvent("onload", H);
                    var n = !1;
                    try {
                        n = null == t.frameElement && i.documentElement
                    } catch (o) { }
                    n && n.doScroll && function i() {
                        if (!f.isReady) {
                            try {
                                n.doScroll("left")
                            } catch (e) {
                                return t.setTimeout(i, 50)
                            }
                            I(),
                                f.ready()
                        }
                    }()
                }
            return j.promise(e)
        }
        ,
        f.ready.promise(),
        f(d))
        break;
    d.ownFirst = "0" === L,
        d.inlineBlockNeedsLayout = !1,
        f((function () {
            var t, e, n, o;
            (n = i.getElementsByTagName("body")[0]) && n.style && (e = i.createElement("div"),
                (o = i.createElement("div")).style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px",
                n.appendChild(o).appendChild(e),
                void 0 !== e.style.zoom && (e.style.cssText = "display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1",
                    d.inlineBlockNeedsLayout = t = 3 === e.offsetWidth,
                    t && (n.style.zoom = 1)),
                n.removeChild(o))
        }
        )),
        function () {
            var t = i.createElement("div");
            d.deleteExpando = !0;
            try {
                delete t.test
            } catch (e) {
                d.deleteExpando = !1
            }
            t = null
        }();
    var R = function (t) {
        var e = f.noData[(t.nodeName + " ").toLowerCase()]
            , n = +t.nodeType || 1;
        return (1 === n || 9 === n) && (!e || !0 !== e && t.getAttribute("classid") === e)
    }
        , q = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/
        , F = /([A-Z])/g;
    function _(t, e, n) {
        if (void 0 === n && 1 === t.nodeType) {
            var i = "data-" + e.replace(F, "-$1").toLowerCase();
            if ("string" == typeof (n = t.getAttribute(i))) {
                try {
                    n = "true" === n || "false" !== n && ("null" === n ? null : +n + "" === n ? +n : q.test(n) ? f.parseJSON(n) : n)
                } catch (o) { }
                f.data(t, e, n)
            } else
                n = void 0
        }
        return n
    }
    function P(t) {
        var e;
        for (e in t)
            if (("data" !== e || !f.isEmptyObject(t[e])) && "toJSON" !== e)
                return !1;
        return !0
    }
    function M(t, e, i, o) {
        if (R(t)) {
            var r, s, a = f.expando, l = t.nodeType, u = l ? f.cache : t, c = l ? t[a] : t[a] && a;
            if (c && u[c] && (o || u[c].data) || void 0 !== i || "string" != typeof e)
                return c || (c = l ? t[a] = n.pop() || f.guid++ : a),
                    u[c] || (u[c] = l ? {} : {
                        toJSON: f.noop
                    }),
                    "object" != typeof e && "function" != typeof e || (o ? u[c] = f.extend(u[c], e) : u[c].data = f.extend(u[c].data, e)),
                    s = u[c],
                    o || (s.data || (s.data = {}),
                        s = s.data),
                    void 0 !== i && (s[f.camelCase(e)] = i),
                    "string" == typeof e ? null == (r = s[e]) && (r = s[f.camelCase(e)]) : r = s,
                    r
        }
    }
    function B(t, e, n) {
        if (R(t)) {
            var i, o, r = t.nodeType, s = r ? f.cache : t, a = r ? t[f.expando] : f.expando;
            if (s[a]) {
                if (e && (i = n ? s[a] : s[a].data)) {
                    o = (e = f.isArray(e) ? e.concat(f.map(e, f.camelCase)) : e in i ? [e] : (e = f.camelCase(e)) in i ? [e] : e.split(" ")).length;
                    for (; o--;)
                        delete i[e[o]];
                    if (n ? !P(i) : !f.isEmptyObject(i))
                        return
                }
                (n || (delete s[a].data,
                    P(s[a]))) && (r ? f.cleanData([t], !0) : d.deleteExpando || s != s.window ? delete s[a] : s[a] = void 0)
            }
        }
    }
    f.extend({
        cache: {},
        noData: {
            "applet ": !0,
            "embed ": !0,
            "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
        },
        hasData: function (t) {
            return !!(t = t.nodeType ? f.cache[t[f.expando]] : t[f.expando]) && !P(t)
        },
        data: function (t, e, n) {
            return M(t, e, n)
        },
        removeData: function (t, e) {
            return B(t, e)
        },
        _data: function (t, e, n) {
            return M(t, e, n, !0)
        },
        _removeData: function (t, e) {
            return B(t, e, !0)
        }
    }),
        f.fn.extend({
            data: function (t, e) {
                var n, i, o, r = this[0], s = r && r.attributes;
                if (void 0 === t) {
                    if (this.length && (o = f.data(r),
                        1 === r.nodeType && !f._data(r, "parsedAttrs"))) {
                        for (n = s.length; n--;)
                            s[n] && 0 === (i = s[n].name).indexOf("data-") && _(r, i = f.camelCase(i.slice(5)), o[i]);
                        f._data(r, "parsedAttrs", !0)
                    }
                    return o
                }
                return "object" == typeof t ? this.each((function () {
                    f.data(this, t)
                }
                )) : arguments.length > 1 ? this.each((function () {
                    f.data(this, t, e)
                }
                )) : r ? _(r, t, f.data(r, t)) : void 0
            },
            removeData: function (t) {
                return this.each((function () {
                    f.removeData(this, t)
                }
                ))
            }
        }),
        f.extend({
            queue: function (t, e, n) {
                var i;
                return t ? (i = f._data(t, e = (e || "fx") + "queue"),
                    n && (!i || f.isArray(n) ? i = f._data(t, e, f.makeArray(n)) : i.push(n)),
                    i || []) : void 0
            },
            dequeue: function (t, e) {
                var n = f.queue(t, e = e || "fx")
                    , i = n.length
                    , o = n.shift()
                    , r = f._queueHooks(t, e);
                "inprogress" === o && (o = n.shift(),
                    i--),
                    o && ("fx" === e && n.unshift("inprogress"),
                        delete r.stop,
                        o.call(t, (function () {
                            f.dequeue(t, e)
                        }
                        ), r)),
                    !i && r && r.empty.fire()
            },
            _queueHooks: function (t, e) {
                var n = e + "queueHooks";
                return f._data(t, n) || f._data(t, n, {
                    empty: f.Callbacks("once memory").add((function () {
                        f._removeData(t, e + "queue"),
                            f._removeData(t, n)
                    }
                    ))
                })
            }
        }),
        f.fn.extend({
            queue: function (t, e) {
                var n = 2;
                return "string" != typeof t && (e = t,
                    t = "fx",
                    n--),
                    arguments.length < n ? f.queue(this[0], t) : void 0 === e ? this : this.each((function () {
                        var n = f.queue(this, t, e);
                        f._queueHooks(this, t),
                            "fx" === t && "inprogress" !== n[0] && f.dequeue(this, t)
                    }
                    ))
            },
            dequeue: function (t) {
                return this.each((function () {
                    f.dequeue(this, t)
                }
                ))
            },
            clearQueue: function (t) {
                return this.queue(t || "fx", [])
            },
            promise: function (t, e) {
                var n, i = 1, o = f.Deferred(), r = this, s = this.length, a = function () {
                    --i || o.resolveWith(r, [r])
                };
                for ("string" != typeof t && (e = t,
                    t = void 0),
                    t = t || "fx"; s--;)
                    (n = f._data(r[s], t + "queueHooks")) && n.empty && (i++,
                        n.empty.add(a));
                return a(),
                    o.promise(e)
            }
        }),
        function () {
            var t;
            d.shrinkWrapBlocks = function () {
                return null != t ? t : (t = !1,
                    (n = i.getElementsByTagName("body")[0]) && n.style ? (e = i.createElement("div"),
                        (o = i.createElement("div")).style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px",
                        n.appendChild(o).appendChild(e),
                        void 0 !== e.style.zoom && (e.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1",
                            e.appendChild(i.createElement("div")).style.width = "5px",
                            t = 3 !== e.offsetWidth),
                        n.removeChild(o),
                        t) : void 0);
                var e, n, o
            }
        }();
    var W = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source
        , z = new RegExp("^(?:([+-])=|)(" + W + ")([a-z%]*)$", "i")
        , U = ["Top", "Right", "Bottom", "Left"]
        , X = function (t, e) {
            return "none" === f.css(t = e || t, "display") || !f.contains(t.ownerDocument, t)
        };
    function V(t, e, n, i) {
        var o, r = 1, s = 20, a = i ? function () {
            return i.cur()
        }
            : function () {
                return f.css(t, e, "")
            }
            , l = a(), u = n && n[3] || (f.cssNumber[e] ? "" : "px"), c = (f.cssNumber[e] || "px" !== u && +l) && z.exec(f.css(t, e));
        if (c && c[3] !== u) {
            u = u || c[3],
                n = n || [],
                c = +l || 1;
            do {
                f.style(t, e, (c /= r = r || ".5") + u)
            } while (r !== (r = a() / l) && 1 !== r && --s)
        }
        return n && (c = +c || +l || 0,
            o = n[1] ? c + (n[1] + 1) * n[2] : +n[2],
            i && (i.unit = u,
                i.start = c,
                i.end = o)),
            o
    }
    var Q = function (t, e, n, i, o, r, s) {
        var a = 0
            , l = t.length
            , u = null == n;
        if ("object" === f.type(n))
            for (a in o = !0,
                n)
                Q(t, e, a, n[a], !0, r, s);
        else if (void 0 !== i && (o = !0,
            f.isFunction(i) || (s = !0),
            u && (s ? (e.call(t, i),
                e = null) : (u = e,
                    e = function (t, e, n) {
                        return u.call(f(t), n)
                    }
            )),
            e))
            for (; l > a; a++)
                e(t[a], n, s ? i : i.call(t[a], a, e(t[a], n)));
        return o ? t : u ? e.call(t) : l ? e(t[0], n) : r
    }
        , J = /^(?:checkbox|radio)$/i
        , Y = /<([\w:-]+)/
        , G = /^$|\/(?:java|ecma)script/i
        , K = /^\s+/
        , Z = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|dialog|figcaption|figure|footer|header|hgroup|main|mark|meter|nav|output|picture|progress|section|summary|template|time|video";
    function tt(t) {
        var e = Z.split("|")
            , n = t.createDocumentFragment();
        if (n.createElement)
            for (; e.length;)
                n.createElement(e.pop());
        return n
    }
    !function () {
        var t = i.createElement("div")
            , e = i.createDocumentFragment()
            , n = i.createElement("input");
        t.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
            d.leadingWhitespace = 3 === t.firstChild.nodeType,
            d.tbody = !t.getElementsByTagName("tbody").length,
            d.htmlSerialize = !!t.getElementsByTagName("link").length,
            d.html5Clone = "<:nav></:nav>" !== i.createElement("nav").cloneNode(!0).outerHTML,
            n.type = "checkbox",
            n.checked = !0,
            e.appendChild(n),
            d.appendChecked = n.checked,
            t.innerHTML = "<textarea>x</textarea>",
            d.noCloneChecked = !!t.cloneNode(!0).lastChild.defaultValue,
            e.appendChild(t),
            (n = i.createElement("input")).setAttribute("type", "radio"),
            n.setAttribute("checked", "checked"),
            n.setAttribute("name", "t"),
            t.appendChild(n),
            d.checkClone = t.cloneNode(!0).cloneNode(!0).lastChild.checked,
            d.noCloneEvent = !!t.addEventListener,
            t[f.expando] = 1,
            d.attributes = !t.getAttribute(f.expando)
    }();
    var et = {
        option: [1, "<select multiple='multiple'>", "</select>"],
        legend: [1, "<fieldset>", "</fieldset>"],
        area: [1, "<map>", "</map>"],
        param: [1, "<object>", "</object>"],
        thead: [1, "<table>", "</table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: d.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
    };
    function nt(t, e) {
        var n, i, o = 0, r = void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e || "*") : void 0 !== t.querySelectorAll ? t.querySelectorAll(e || "*") : void 0;
        if (!r)
            for (r = [],
                n = t.childNodes || t; null != (i = n[o]); o++)
                !e || f.nodeName(i, e) ? r.push(i) : f.merge(r, nt(i, e));
        return void 0 === e || e && f.nodeName(t, e) ? f.merge([t], r) : r
    }
    function it(t, e) {
        for (var n, i = 0; null != (n = t[i]); i++)
            f._data(n, "globalEval", !e || f._data(e[i], "globalEval"))
    }
    et.optgroup = et.option,
        et.tbody = et.tfoot = et.colgroup = et.caption = et.thead,
        et.th = et.td;
    var ot = /<|&#?\w+;/
        , rt = /<tbody/i;
    function st(t) {
        J.test(t.type) && (t.defaultChecked = t.checked)
    }
    function at(t, e, n, i, o) {
        for (var r, s, a, l, u, c, p, h = t.length, g = tt(e), m = [], v = 0; h > v; v++)
            if ((s = t[v]) || 0 === s)
                if ("object" === f.type(s))
                    f.merge(m, s.nodeType ? [s] : s);
                else if (ot.test(s)) {
                    for (l = l || g.appendChild(e.createElement("div")),
                        u = (Y.exec(s) || ["", ""])[1].toLowerCase(),
                        l.innerHTML = (p = et[u] || et._default)[1] + f.htmlPrefilter(s) + p[2],
                        r = p[0]; r--;)
                        l = l.lastChild;
                    if (!d.leadingWhitespace && K.test(s) && m.push(e.createTextNode(K.exec(s)[0])),
                        !d.tbody)
                        for (r = (s = "table" !== u || rt.test(s) ? "<table>" !== p[1] || rt.test(s) ? 0 : l : l.firstChild) && s.childNodes.length; r--;)
                            f.nodeName(c = s.childNodes[r], "tbody") && !c.childNodes.length && s.removeChild(c);
                    for (f.merge(m, l.childNodes),
                        l.textContent = ""; l.firstChild;)
                        l.removeChild(l.firstChild);
                    l = g.lastChild
                } else
                    m.push(e.createTextNode(s));
        for (l && g.removeChild(l),
            d.appendChecked || f.grep(nt(m, "input"), st),
            v = 0; s = m[v++];)
            if (i && f.inArray(s, i) > -1)
                o && o.push(s);
            else if (a = f.contains(s.ownerDocument, s),
                l = nt(g.appendChild(s), "script"),
                a && it(l),
                n)
                for (r = 0; s = l[r++];)
                    G.test(s.type || "") && n.push(s);
        return l = null,
            g
    }
    !function () {
        var e, n, o = i.createElement("div");
        for (e in {
            submit: !0,
            change: !0,
            focusin: !0
        })
            (d[e] = (n = "on" + e) in t) || (o.setAttribute(n, "t"),
                d[e] = !1 === o.attributes[n].expando);
        o = null
    }();
    var lt = /^(?:input|select|textarea)$/i
        , ut = /^key/
        , ct = /^(?:mouse|pointer|contextmenu|drag|drop)|click/
        , dt = /^(?:focusinfocus|focusoutblur)$/
        , pt = /^([^.]*)(?:\.(.+)|)/;
    function ft() {
        return !0
    }
    function ht() {
        return !1
    }
    function gt() {
        try {
            return i.activeElement
        } catch (t) { }
    }
    function mt(t, e, n, i, o, r) {
        var s, a;
        if ("object" == typeof e) {
            for (a in "string" != typeof n && (i = i || n,
                n = void 0),
                e)
                mt(t, a, n, i, e[a], r);
            return t
        }
        if (null == i && null == o ? (o = n,
            i = n = void 0) : null == o && ("string" == typeof n ? (o = i,
                i = void 0) : (o = i,
                    i = n,
                    n = void 0)),
            !1 === o)
            o = ht;
        else if (!o)
            return t;
        return 1 === r && (s = o,
            (o = function (t) {
                return f().off(t),
                    s.apply(this, arguments)
            }
            ).guid = s.guid || (s.guid = f.guid++)),
            t.each((function () {
                f.event.add(this, e, o, i, n)
            }
            ))
    }
    f.event = {
        global: {},
        add: function (t, e, n, i, o) {
            var r, s, a, l, u, c, d, p, h, g, m, v = f._data(t);
            if (v) {
                for (n.handler && (n = (l = n).handler,
                    o = l.selector),
                    n.guid || (n.guid = f.guid++),
                    (s = v.events) || (s = v.events = {}),
                    (c = v.handle) || ((c = v.handle = function (t) {
                        return void 0 === f || t && f.event.triggered === t.type ? void 0 : f.event.dispatch.apply(c.elem, arguments)
                    }
                    ).elem = t),
                    a = (e = (e || "").match(O) || [""]).length; a--;)
                    h = m = (r = pt.exec(e[a]) || [])[1],
                        g = (r[2] || "").split(".").sort(),
                        h && (u = f.event.special[h] || {},
                            u = f.event.special[h = (o ? u.delegateType : u.bindType) || h] || {},
                            d = f.extend({
                                type: h,
                                origType: m,
                                data: i,
                                handler: n,
                                guid: n.guid,
                                selector: o,
                                needsContext: o && f.expr.match.needsContext.test(o),
                                namespace: g.join(".")
                            }, l),
                            (p = s[h]) || ((p = s[h] = []).delegateCount = 0,
                                u.setup && !1 !== u.setup.call(t, i, g, c) || (t.addEventListener ? t.addEventListener(h, c, !1) : t.attachEvent && t.attachEvent("on" + h, c))),
                            u.add && (u.add.call(t, d),
                                d.handler.guid || (d.handler.guid = n.guid)),
                            o ? p.splice(p.delegateCount++, 0, d) : p.push(d),
                            f.event.global[h] = !0);
                t = null
            }
        },
        remove: function (t, e, n, i, o) {
            var r, s, a, l, u, c, d, p, h, g, m, v = f.hasData(t) && f._data(t);
            if (v && (c = v.events)) {
                for (u = (e = (e || "").match(O) || [""]).length; u--;)
                    if (h = m = (a = pt.exec(e[u]) || [])[1],
                        g = (a[2] || "").split(".").sort(),
                        h) {
                        for (d = f.event.special[h] || {},
                            p = c[h = (i ? d.delegateType : d.bindType) || h] || [],
                            a = a[2] && new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)"),
                            l = r = p.length; r--;)
                            s = p[r],
                                !o && m !== s.origType || n && n.guid !== s.guid || a && !a.test(s.namespace) || i && i !== s.selector && ("**" !== i || !s.selector) || (p.splice(r, 1),
                                    s.selector && p.delegateCount--,
                                    d.remove && d.remove.call(t, s));
                        l && !p.length && (d.teardown && !1 !== d.teardown.call(t, g, v.handle) || f.removeEvent(t, h, v.handle),
                            delete c[h])
                    } else
                        for (h in c)
                            f.event.remove(t, h + e[u], n, i, !0);
                f.isEmptyObject(c) && (delete v.handle,
                    f._removeData(t, "events"))
            }
        },
        trigger: function (e, n, o, r) {
            var s, a, l, u, d, p, h, g = [o || i], m = c.call(e, "type") ? e.type : e, v = c.call(e, "namespace") ? e.namespace.split(".") : [];
            if (l = p = o = o || i,
                3 !== o.nodeType && 8 !== o.nodeType && !dt.test(m + f.event.triggered) && (m.indexOf(".") > -1 && (v = m.split("."),
                    m = v.shift(),
                    v.sort()),
                    a = m.indexOf(":") < 0 && "on" + m,
                    (e = e[f.expando] ? e : new f.Event(m, "object" == typeof e && e)).isTrigger = r ? 2 : 3,
                    e.namespace = v.join("."),
                    e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + v.join("\\.(?:.*\\.|)") + "(\\.|$)") : null,
                    e.result = void 0,
                    e.target || (e.target = o),
                    n = null == n ? [e] : f.makeArray(n, [e]),
                    d = f.event.special[m] || {},
                    r || !d.trigger || !1 !== d.trigger.apply(o, n))) {
                if (!r && !d.noBubble && !f.isWindow(o)) {
                    for (dt.test((u = d.delegateType || m) + m) || (l = l.parentNode); l; l = l.parentNode)
                        g.push(l),
                            p = l;
                    p === (o.ownerDocument || i) && g.push(p.defaultView || p.parentWindow || t)
                }
                for (h = 0; (l = g[h++]) && !e.isPropagationStopped();)
                    e.type = h > 1 ? u : d.bindType || m,
                        (s = (f._data(l, "events") || {})[e.type] && f._data(l, "handle")) && s.apply(l, n),
                        (s = a && l[a]) && s.apply && R(l) && (e.result = s.apply(l, n),
                            !1 === e.result && e.preventDefault());
                if (e.type = m,
                    !r && !e.isDefaultPrevented() && (!d._default || !1 === d._default.apply(g.pop(), n)) && R(o) && a && o[m] && !f.isWindow(o)) {
                    (p = o[a]) && (o[a] = null),
                        f.event.triggered = m;
                    try {
                        o[m]()
                    } catch (y) { }
                    f.event.triggered = void 0,
                        p && (o[a] = p)
                }
                return e.result
            }
        },
        dispatch: function (t) {
            t = f.event.fix(t);
            var e, n, i, r, s, a = [], l = o.call(arguments), u = (f._data(this, "events") || {})[t.type] || [], c = f.event.special[t.type] || {};
            if (l[0] = t,
                t.delegateTarget = this,
                !c.preDispatch || !1 !== c.preDispatch.call(this, t)) {
                for (a = f.event.handlers.call(this, t, u),
                    e = 0; (r = a[e++]) && !t.isPropagationStopped();)
                    for (t.currentTarget = r.elem,
                        n = 0; (s = r.handlers[n++]) && !t.isImmediatePropagationStopped();)
                        t.rnamespace && !t.rnamespace.test(s.namespace) || (t.handleObj = s,
                            t.data = s.data,
                            void 0 !== (i = ((f.event.special[s.origType] || {}).handle || s.handler).apply(r.elem, l)) && !1 === (t.result = i) && (t.preventDefault(),
                                t.stopPropagation()));
                return c.postDispatch && c.postDispatch.call(this, t),
                    t.result
            }
        },
        handlers: function (t, e) {
            var n, i, o, r, s = [], a = e.delegateCount, l = t.target;
            if (a && l.nodeType && ("click" !== t.type || isNaN(t.button) || t.button < 1))
                for (; l != this; l = l.parentNode || this)
                    if (1 === l.nodeType && (!0 !== l.disabled || "click" !== t.type)) {
                        for (i = [],
                            n = 0; a > n; n++)
                            void 0 === i[o = (r = e[n]).selector + " "] && (i[o] = r.needsContext ? f(o, this).index(l) > -1 : f.find(o, this, null, [l]).length),
                                i[o] && i.push(r);
                        i.length && s.push({
                            elem: l,
                            handlers: i
                        })
                    }
            return a < e.length && s.push({
                elem: this,
                handlers: e.slice(a)
            }),
                s
        },
        fix: function (t) {
            if (t[f.expando])
                return t;
            var e, n, o, r = t.type, s = t, a = this.fixHooks[r];
            for (a || (this.fixHooks[r] = a = ct.test(r) ? this.mouseHooks : ut.test(r) ? this.keyHooks : {}),
                o = a.props ? this.props.concat(a.props) : this.props,
                t = new f.Event(s),
                e = o.length; e--;)
                t[n = o[e]] = s[n];
            return t.target || (t.target = s.srcElement || i),
                3 === t.target.nodeType && (t.target = t.target.parentNode),
                t.metaKey = !!t.metaKey,
                a.filter ? a.filter(t, s) : t
        },
        props: "altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function (t, e) {
                return null == t.which && (t.which = null != e.charCode ? e.charCode : e.keyCode),
                    t
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (t, e) {
                var n, o, r, s = e.button, a = e.fromElement;
                return null == t.pageX && null != e.clientX && (n = (o = t.target.ownerDocument || i).body,
                    t.pageX = e.clientX + ((r = o.documentElement) && r.scrollLeft || n && n.scrollLeft || 0) - (r && r.clientLeft || n && n.clientLeft || 0),
                    t.pageY = e.clientY + (r && r.scrollTop || n && n.scrollTop || 0) - (r && r.clientTop || n && n.clientTop || 0)),
                    !t.relatedTarget && a && (t.relatedTarget = a === t.target ? e.toElement : a),
                    t.which || void 0 === s || (t.which = 1 & s ? 1 : 2 & s ? 3 : 4 & s ? 2 : 0),
                    t
            }
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function () {
                    if (this !== gt() && this.focus)
                        try {
                            return this.focus(),
                                !1
                        } catch (t) { }
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function () {
                    return this === gt() && this.blur ? (this.blur(),
                        !1) : void 0
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function () {
                    return f.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(),
                        !1) : void 0
                },
                _default: function (t) {
                    return f.nodeName(t.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function (t) {
                    void 0 !== t.result && t.originalEvent && (t.originalEvent.returnValue = t.result)
                }
            }
        },
        simulate: function (t, e, n) {
            var i = f.extend(new f.Event, n, {
                type: t,
                isSimulated: !0
            });
            f.event.trigger(i, null, e),
                i.isDefaultPrevented() && n.preventDefault()
        }
    },
        f.removeEvent = i.removeEventListener ? function (t, e, n) {
            t.removeEventListener && t.removeEventListener(e, n)
        }
            : function (t, e, n) {
                var i = "on" + e;
                t.detachEvent && (void 0 === t[i] && (t[i] = null),
                    t.detachEvent(i, n))
            }
        ,
        f.Event = function (t, e) {
            return this instanceof f.Event ? (t && t.type ? (this.originalEvent = t,
                this.type = t.type,
                this.isDefaultPrevented = t.defaultPrevented || void 0 === t.defaultPrevented && !1 === t.returnValue ? ft : ht) : this.type = t,
                e && f.extend(this, e),
                this.timeStamp = t && t.timeStamp || f.now(),
                void (this[f.expando] = !0)) : new f.Event(t, e)
        }
        ,
        f.Event.prototype = {
            constructor: f.Event,
            isDefaultPrevented: ht,
            isPropagationStopped: ht,
            isImmediatePropagationStopped: ht,
            preventDefault: function () {
                var t = this.originalEvent;
                this.isDefaultPrevented = ft,
                    t && (t.preventDefault ? t.preventDefault() : t.returnValue = !1)
            },
            stopPropagation: function () {
                var t = this.originalEvent;
                this.isPropagationStopped = ft,
                    t && !this.isSimulated && (t.stopPropagation && t.stopPropagation(),
                        t.cancelBubble = !0)
            },
            stopImmediatePropagation: function () {
                var t = this.originalEvent;
                this.isImmediatePropagationStopped = ft,
                    t && t.stopImmediatePropagation && t.stopImmediatePropagation(),
                    this.stopPropagation()
            }
        },
        f.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout",
            pointerenter: "pointerover",
            pointerleave: "pointerout"
        }, (function (t, e) {
            f.event.special[t] = {
                delegateType: e,
                bindType: e,
                handle: function (t) {
                    var n, i = this, o = t.relatedTarget, r = t.handleObj;
                    return o && (o === i || f.contains(i, o)) || (t.type = r.origType,
                        n = r.handler.apply(this, arguments),
                        t.type = e),
                        n
                }
            }
        }
        )),
        d.submit || (f.event.special.submit = {
            setup: function () {
                return !f.nodeName(this, "form") && void f.event.add(this, "click._submit keypress._submit", (function (t) {
                    var e = t.target
                        , n = f.nodeName(e, "input") || f.nodeName(e, "button") ? f.prop(e, "form") : void 0;
                    n && !f._data(n, "submit") && (f.event.add(n, "submit._submit", (function (t) {
                        t._submitBubble = !0
                    }
                    )),
                        f._data(n, "submit", !0))
                }
                ))
            },
            postDispatch: function (t) {
                t._submitBubble && (delete t._submitBubble,
                    this.parentNode && !t.isTrigger && f.event.simulate("submit", this.parentNode, t))
            },
            teardown: function () {
                return !f.nodeName(this, "form") && void f.event.remove(this, "._submit")
            }
        }),
        d.change || (f.event.special.change = {
            setup: function () {
                return lt.test(this.nodeName) ? ("checkbox" !== this.type && "radio" !== this.type || (f.event.add(this, "propertychange._change", (function (t) {
                    "checked" === t.originalEvent.propertyName && (this._justChanged = !0)
                }
                )),
                    f.event.add(this, "click._change", (function (t) {
                        this._justChanged && !t.isTrigger && (this._justChanged = !1),
                            f.event.simulate("change", this, t)
                    }
                    ))),
                    !1) : void f.event.add(this, "beforeactivate._change", (function (t) {
                        var e = t.target;
                        lt.test(e.nodeName) && !f._data(e, "change") && (f.event.add(e, "change._change", (function (t) {
                            !this.parentNode || t.isSimulated || t.isTrigger || f.event.simulate("change", this.parentNode, t)
                        }
                        )),
                            f._data(e, "change", !0))
                    }
                    ))
            },
            handle: function (t) {
                var e = t.target;
                return this !== e || t.isSimulated || t.isTrigger || "radio" !== e.type && "checkbox" !== e.type ? t.handleObj.handler.apply(this, arguments) : void 0
            },
            teardown: function () {
                return f.event.remove(this, "._change"),
                    !lt.test(this.nodeName)
            }
        }),
        d.focusin || f.each({
            focus: "focusin",
            blur: "focusout"
        }, (function (t, e) {
            var n = function (t) {
                f.event.simulate(e, t.target, f.event.fix(t))
            };
            f.event.special[e] = {
                setup: function () {
                    var i = this.ownerDocument || this
                        , o = f._data(i, e);
                    o || i.addEventListener(t, n, !0),
                        f._data(i, e, (o || 0) + 1)
                },
                teardown: function () {
                    var i = this.ownerDocument || this
                        , o = f._data(i, e) - 1;
                    o ? f._data(i, e, o) : (i.removeEventListener(t, n, !0),
                        f._removeData(i, e))
                }
            }
        }
        )),
        f.fn.extend({
            on: function (t, e, n, i) {
                return mt(this, t, e, n, i)
            },
            one: function (t, e, n, i) {
                return mt(this, t, e, n, i, 1)
            },
            off: function (t, e, n) {
                var i, o;
                if (t && t.preventDefault && t.handleObj)
                    return i = t.handleObj,
                        f(t.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler),
                        this;
                if ("object" == typeof t) {
                    for (o in t)
                        this.off(o, e, t[o]);
                    return this
                }
                return !1 !== e && "function" != typeof e || (n = e,
                    e = void 0),
                    !1 === n && (n = ht),
                    this.each((function () {
                        f.event.remove(this, t, n, e)
                    }
                    ))
            },
            trigger: function (t, e) {
                return this.each((function () {
                    f.event.trigger(t, e, this)
                }
                ))
            },
            triggerHandler: function (t, e) {
                var n = this[0];
                return n ? f.event.trigger(t, e, n, !0) : void 0
            }
        });
    var vt = / jQuery\d+="(?:null|\d+)"/g
        , yt = new RegExp("<(?:" + Z + ")[\\s/>]", "i")
        , bt = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi
        , xt = /<script|<style|<link/i
        , wt = /checked\s*(?:[^=]|=\s*.checked.)/i
        , Tt = /^true\/(.*)/
        , Ct = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g
        , Et = tt(i).appendChild(i.createElement("div"));
    function St(t, e) {
        return f.nodeName(t, "table") && f.nodeName(11 !== e.nodeType ? e : e.firstChild, "tr") ? t.getElementsByTagName("tbody")[0] || t.appendChild(t.ownerDocument.createElement("tbody")) : t
    }
    function kt(t) {
        return t.type = (null !== f.find.attr(t, "type")) + "/" + t.type,
            t
    }
    function Nt(t) {
        var e = Tt.exec(t.type);
        return e ? t.type = e[1] : t.removeAttribute("type"),
            t
    }
    function $t(t, e) {
        if (1 === e.nodeType && f.hasData(t)) {
            var n, i, o, r = f._data(t), s = f._data(e, r), a = r.events;
            if (a)
                for (n in delete s.handle,
                    s.events = {},
                    a)
                    for (i = 0,
                        o = a[n].length; o > i; i++)
                        f.event.add(e, n, a[n][i]);
            s.data && (s.data = f.extend({}, s.data))
        }
    }
    function At(t, e) {
        var n, i, o;
        if (1 === e.nodeType) {
            if (n = e.nodeName.toLowerCase(),
                !d.noCloneEvent && e[f.expando]) {
                for (i in (o = f._data(e)).events)
                    f.removeEvent(e, i, o.handle);
                e.removeAttribute(f.expando)
            }
            "script" === n && e.text !== t.text ? (kt(e).text = t.text,
                Nt(e)) : "object" === n ? (e.parentNode && (e.outerHTML = t.outerHTML),
                    d.html5Clone && t.innerHTML && !f.trim(e.innerHTML) && (e.innerHTML = t.innerHTML)) : "input" === n && J.test(t.type) ? (e.defaultChecked = e.checked = t.checked,
                        e.value !== t.value && (e.value = t.value)) : "option" === n ? e.defaultSelected = e.selected = t.defaultSelected : "input" !== n && "textarea" !== n || (e.defaultValue = t.defaultValue)
        }
    }
    function Dt(t, e, n, i) {
        e = r.apply([], e);
        var o, s, a, l, u, c, p = 0, h = t.length, g = h - 1, m = e[0], v = f.isFunction(m);
        if (v || h > 1 && "string" == typeof m && !d.checkClone && wt.test(m))
            return t.each((function (o) {
                var r = t.eq(o);
                v && (e[0] = m.call(this, o, r.html())),
                    Dt(r, e, n, i)
            }
            ));
        if (h && (o = (c = at(e, t[0].ownerDocument, !1, t, i)).firstChild,
            1 === c.childNodes.length && (c = o),
            o || i)) {
            for (a = (l = f.map(nt(c, "script"), kt)).length; h > p; p++)
                s = c,
                    p !== g && (s = f.clone(s, !0, !0),
                        a && f.merge(l, nt(s, "script"))),
                    n.call(t[p], s, p);
            if (a)
                for (u = l[l.length - 1].ownerDocument,
                    f.map(l, Nt),
                    p = 0; a > p; p++)
                    G.test((s = l[p]).type || "") && !f._data(s, "globalEval") && f.contains(u, s) && (s.src ? f._evalUrl && f._evalUrl(s.src) : f.globalEval((s.text || s.textContent || s.innerHTML || "").replace(Ct, "")));
            c = o = null
        }
        return t
    }
    function jt(t, e, n) {
        for (var i, o = e ? f.filter(e, t) : t, r = 0; null != (i = o[r]); r++)
            n || 1 !== i.nodeType || f.cleanData(nt(i)),
                i.parentNode && (n && f.contains(i.ownerDocument, i) && it(nt(i, "script")),
                    i.parentNode.removeChild(i));
        return t
    }
    f.extend({
        htmlPrefilter: function (t) {
            return t.replace(bt, "<$1></$2>")
        },
        clone: function (t, e, n) {
            var i, o, r, s, a, l = f.contains(t.ownerDocument, t);
            if (d.html5Clone || f.isXMLDoc(t) || !yt.test("<" + t.nodeName + ">") ? r = t.cloneNode(!0) : (Et.innerHTML = t.outerHTML,
                Et.removeChild(r = Et.firstChild)),
                !(d.noCloneEvent && d.noCloneChecked || 1 !== t.nodeType && 11 !== t.nodeType || f.isXMLDoc(t)))
                for (i = nt(r),
                    a = nt(t),
                    s = 0; null != (o = a[s]); ++s)
                    i[s] && At(o, i[s]);
            if (e)
                if (n)
                    for (a = a || nt(t),
                        i = i || nt(r),
                        s = 0; null != (o = a[s]); s++)
                        $t(o, i[s]);
                else
                    $t(t, r);
            return (i = nt(r, "script")).length > 0 && it(i, !l && nt(t, "script")),
                i = a = o = null,
                r
        },
        cleanData: function (t, e) {
            for (var i, o, r, s, a = 0, l = f.expando, u = f.cache, c = d.attributes, p = f.event.special; null != (i = t[a]); a++)
                if ((e || R(i)) && (s = (r = i[l]) && u[r])) {
                    if (s.events)
                        for (o in s.events)
                            p[o] ? f.event.remove(i, o) : f.removeEvent(i, o, s.handle);
                    u[r] && (delete u[r],
                        c || void 0 === i.removeAttribute ? i[l] = void 0 : i.removeAttribute(l),
                        n.push(r))
                }
        }
    }),
        f.fn.extend({
            domManip: Dt,
            detach: function (t) {
                return jt(this, t, !0)
            },
            remove: function (t) {
                return jt(this, t)
            },
            text: function (t) {
                return Q(this, (function (t) {
                    return void 0 === t ? f.text(this) : this.empty().append((this[0] && this[0].ownerDocument || i).createTextNode(t))
                }
                ), null, t, arguments.length)
            },
            append: function () {
                return Dt(this, arguments, (function (t) {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || St(this, t).appendChild(t)
                }
                ))
            },
            prepend: function () {
                return Dt(this, arguments, (function (t) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var e = St(this, t);
                        e.insertBefore(t, e.firstChild)
                    }
                }
                ))
            },
            before: function () {
                return Dt(this, arguments, (function (t) {
                    this.parentNode && this.parentNode.insertBefore(t, this)
                }
                ))
            },
            after: function () {
                return Dt(this, arguments, (function (t) {
                    this.parentNode && this.parentNode.insertBefore(t, this.nextSibling)
                }
                ))
            },
            empty: function () {
                for (var t, e = 0; null != (t = this[e]); e++) {
                    for (1 === t.nodeType && f.cleanData(nt(t, !1)); t.firstChild;)
                        t.removeChild(t.firstChild);
                    t.options && f.nodeName(t, "select") && (t.options.length = 0)
                }
                return this
            },
            clone: function (t, e) {
                return t = null != t && t,
                    e = null == e ? t : e,
                    this.map((function () {
                        return f.clone(this, t, e)
                    }
                    ))
            },
            html: function (t) {
                return Q(this, (function (t) {
                    var e = this[0] || {}
                        , n = 0
                        , i = this.length;
                    if (void 0 === t)
                        return 1 === e.nodeType ? e.innerHTML.replace(vt, "") : void 0;
                    if ("string" == typeof t && !xt.test(t) && (d.htmlSerialize || !yt.test(t)) && (d.leadingWhitespace || !K.test(t)) && !et[(Y.exec(t) || ["", ""])[1].toLowerCase()]) {
                        t = f.htmlPrefilter(t);
                        try {
                            for (; i > n; n++)
                                1 === (e = this[n] || {}).nodeType && (f.cleanData(nt(e, !1)),
                                    e.innerHTML = t);
                            e = 0
                        } catch (o) { }
                    }
                    e && this.empty().append(t)
                }
                ), null, t, arguments.length)
            },
            replaceWith: function () {
                var t = [];
                return Dt(this, arguments, (function (e) {
                    var n = this.parentNode;
                    f.inArray(this, t) < 0 && (f.cleanData(nt(this)),
                        n && n.replaceChild(e, this))
                }
                ), t)
            }
        }),
        f.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        }, (function (t, e) {
            f.fn[t] = function (t) {
                for (var n, i = 0, o = [], r = f(t), a = r.length - 1; a >= i; i++)
                    n = i === a ? this : this.clone(!0),
                        f(r[i])[e](n),
                        s.apply(o, n.get());
                return this.pushStack(o)
            }
        }
        ));
    var Lt, Ot = {
        HTML: "block",
        BODY: "block"
    };
    function It(t, e) {
        var n = f(e.createElement(t)).appendTo(e.body)
            , i = f.css(n[0], "display");
        return n.detach(),
            i
    }
    function Ht(t) {
        var e = i
            , n = Ot[t];
        return n || ("none" !== (n = It(t, e)) && n || ((e = ((Lt = (Lt || f("<iframe frameborder='0' width='0' height='0'/>")).appendTo(e.documentElement))[0].contentWindow || Lt[0].contentDocument).document).write(),
            e.close(),
            n = It(t, e),
            Lt.detach()),
            Ot[t] = n),
            n
    }
    var Rt = /^margin/
        , qt = new RegExp("^(" + W + ")(?!px)[a-z%]+$", "i")
        , Ft = function (t, e, n, i) {
            var o, r, s = {};
            for (r in e)
                s[r] = t.style[r],
                    t.style[r] = e[r];
            for (r in o = n.apply(t, i || []),
                e)
                t.style[r] = s[r];
            return o
        }
        , _t = i.documentElement;
    !function () {
        var e, n, o, r, s, a, l = i.createElement("div"), u = i.createElement("div");
        if (u.style) {
            function c() {
                var c, d, p = i.documentElement;
                p.appendChild(l),
                    u.style.cssText = "-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%",
                    e = o = a = !1,
                    n = s = !0,
                    t.getComputedStyle && (d = t.getComputedStyle(u),
                        e = "1%" !== (d || {}).top,
                        a = "2px" === (d || {}).marginLeft,
                        o = "4px" === (d || {
                            width: "4px"
                        }).width,
                        u.style.marginRight = "50%",
                        n = "4px" === (d || {
                            marginRight: "4px"
                        }).marginRight,
                        (c = u.appendChild(i.createElement("div"))).style.cssText = u.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",
                        c.style.marginRight = c.style.width = "0",
                        u.style.width = "1px",
                        s = !parseFloat((t.getComputedStyle(c) || {}).marginRight),
                        u.removeChild(c)),
                    u.style.display = "none",
                    (r = 0 === u.getClientRects().length) && (u.style.display = "",
                        u.innerHTML = "<table><tr><td></td><td>t</td></tr></table>",
                        u.childNodes[0].style.borderCollapse = "separate",
                        (c = u.getElementsByTagName("td"))[0].style.cssText = "margin:0;border:0;padding:0;display:none",
                        (r = 0 === c[0].offsetHeight) && (c[0].style.display = "",
                            c[1].style.display = "none",
                            r = 0 === c[0].offsetHeight)),
                    p.removeChild(l)
            }
            u.style.cssText = "float:left;opacity:.5",
                d.opacity = "0.5" === u.style.opacity,
                d.cssFloat = !!u.style.cssFloat,
                u.style.backgroundClip = "content-box",
                u.cloneNode(!0).style.backgroundClip = "",
                d.clearCloneStyle = "content-box" === u.style.backgroundClip,
                (l = i.createElement("div")).style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute",
                u.innerHTML = "",
                l.appendChild(u),
                d.boxSizing = "" === u.style.boxSizing || "" === u.style.MozBoxSizing || "" === u.style.WebkitBoxSizing,
                f.extend(d, {
                    reliableHiddenOffsets: function () {
                        return null == e && c(),
                            r
                    },
                    boxSizingReliable: function () {
                        return null == e && c(),
                            o
                    },
                    pixelMarginRight: function () {
                        return null == e && c(),
                            n
                    },
                    pixelPosition: function () {
                        return null == e && c(),
                            e
                    },
                    reliableMarginRight: function () {
                        return null == e && c(),
                            s
                    },
                    reliableMarginLeft: function () {
                        return null == e && c(),
                            a
                    }
                })
        }
    }();
    var Pt, Mt, Bt = /^(top|right|bottom|left)$/;
    function Wt(t, e) {
        return {
            get: function () {
                return t() ? void delete this.get : (this.get = e).apply(this, arguments)
            }
        }
    }
    t.getComputedStyle ? (Pt = function (e) {
        var n = e.ownerDocument.defaultView;
        return n && n.opener || (n = t),
            n.getComputedStyle(e)
    }
        ,
        Mt = function (t, e, n) {
            var i, o, r, s, a = t.style;
            return "" !== (s = (n = n || Pt(t)) ? n.getPropertyValue(e) || n[e] : void 0) && void 0 !== s || f.contains(t.ownerDocument, t) || (s = f.style(t, e)),
                n && !d.pixelMarginRight() && qt.test(s) && Rt.test(e) && (i = a.width,
                    o = a.minWidth,
                    r = a.maxWidth,
                    a.minWidth = a.maxWidth = a.width = s,
                    s = n.width,
                    a.width = i,
                    a.minWidth = o,
                    a.maxWidth = r),
                void 0 === s ? s : s + ""
        }
    ) : _t.currentStyle && (Pt = function (t) {
        return t.currentStyle
    }
        ,
        Mt = function (t, e, n) {
            var i, o, r, s, a = t.style;
            return null == (s = (n = n || Pt(t)) ? n[e] : void 0) && a && a[e] && (s = a[e]),
                qt.test(s) && !Bt.test(e) && (i = a.left,
                    (r = (o = t.runtimeStyle) && o.left) && (o.left = t.currentStyle.left),
                    a.left = "fontSize" === e ? "1em" : s,
                    s = a.pixelLeft + "px",
                    a.left = i,
                    r && (o.left = r)),
                void 0 === s ? s : s + "" || "auto"
        }
    );
    var zt = /alpha\([^)]*\)/i
        , Ut = /opacity\s*=\s*([^)]*)/i
        , Xt = /^(none|table(?!-c[ea]).+)/
        , Vt = new RegExp("^(" + W + ")(.*)$", "i")
        , Qt = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        }
        , Jt = {
            letterSpacing: "0",
            fontWeight: "400"
        }
        , Yt = ["Webkit", "O", "Moz", "ms"]
        , Gt = i.createElement("div").style;
    function Kt(t) {
        if (t in Gt)
            return t;
        for (var e = t.charAt(0).toUpperCase() + t.slice(1), n = Yt.length; n--;)
            if ((t = Yt[n] + e) in Gt)
                return t
    }
    function Zt(t, e) {
        for (var n, i, o, r = [], s = 0, a = t.length; a > s; s++)
            (i = t[s]).style && (r[s] = f._data(i, "olddisplay"),
                n = i.style.display,
                e ? (r[s] || "none" !== n || (i.style.display = ""),
                    "" === i.style.display && X(i) && (r[s] = f._data(i, "olddisplay", Ht(i.nodeName)))) : (o = X(i),
                        (n && "none" !== n || !o) && f._data(i, "olddisplay", o ? n : f.css(i, "display"))));
        for (s = 0; a > s; s++)
            (i = t[s]).style && (e && "none" !== i.style.display && "" !== i.style.display || (i.style.display = e ? r[s] || "" : "none"));
        return t
    }
    function te(t, e, n) {
        var i = Vt.exec(e);
        return i ? Math.max(0, i[1] - (n || 0)) + (i[2] || "px") : e
    }
    function ee(t, e, n, i, o) {
        for (var r = n === (i ? "border" : "content") ? 4 : "width" === e ? 1 : 0, s = 0; 4 > r; r += 2)
            "margin" === n && (s += f.css(t, n + U[r], !0, o)),
                i ? ("content" === n && (s -= f.css(t, "padding" + U[r], !0, o)),
                    "margin" !== n && (s -= f.css(t, "border" + U[r] + "Width", !0, o))) : (s += f.css(t, "padding" + U[r], !0, o),
                        "padding" !== n && (s += f.css(t, "border" + U[r] + "Width", !0, o)));
        return s
    }
    function ne(t, e, n) {
        var i = !0
            , o = "width" === e ? t.offsetWidth : t.offsetHeight
            , r = Pt(t)
            , s = d.boxSizing && "border-box" === f.css(t, "boxSizing", !1, r);
        if (0 >= o || null == o) {
            if ((0 > (o = Mt(t, e, r)) || null == o) && (o = t.style[e]),
                qt.test(o))
                return o;
            i = s && (d.boxSizingReliable() || o === t.style[e]),
                o = parseFloat(o) || 0
        }
        return o + ee(t, e, n || (s ? "border" : "content"), i, r) + "px"
    }
    function ie(t, e, n, i, o) {
        return new ie.prototype.init(t, e, n, i, o)
    }
    f.extend({
        cssHooks: {
            opacity: {
                get: function (t, e) {
                    if (e) {
                        var n = Mt(t, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            float: d.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function (t, e, n, i) {
            if (t && 3 !== t.nodeType && 8 !== t.nodeType && t.style) {
                var o, r, s, a = f.camelCase(e), l = t.style;
                if (e = f.cssProps[a] || (f.cssProps[a] = Kt(a) || a),
                    s = f.cssHooks[e] || f.cssHooks[a],
                    void 0 === n)
                    return s && "get" in s && void 0 !== (o = s.get(t, !1, i)) ? o : l[e];
                if ("string" == (r = typeof n) && (o = z.exec(n)) && o[1] && (n = V(t, e, o),
                    r = "number"),
                    null != n && n == n && ("number" === r && (n += o && o[3] || (f.cssNumber[a] ? "" : "px")),
                        d.clearCloneStyle || "" !== n || 0 !== e.indexOf("background") || (l[e] = "inherit"),
                        !(s && "set" in s && void 0 === (n = s.set(t, n, i)))))
                    try {
                        l[e] = n
                    } catch (u) { }
            }
        },
        css: function (t, e, n, i) {
            var o, r, s, a = f.camelCase(e);
            return e = f.cssProps[a] || (f.cssProps[a] = Kt(a) || a),
                (s = f.cssHooks[e] || f.cssHooks[a]) && "get" in s && (r = s.get(t, !0, n)),
                void 0 === r && (r = Mt(t, e, i)),
                "normal" === r && e in Jt && (r = Jt[e]),
                "" === n || n ? (o = parseFloat(r),
                    !0 === n || isFinite(o) ? o || 0 : r) : r
        }
    }),
        f.each(["height", "width"], (function (t, e) {
            f.cssHooks[e] = {
                get: function (t, n, i) {
                    return n ? Xt.test(f.css(t, "display")) && 0 === t.offsetWidth ? Ft(t, Qt, (function () {
                        return ne(t, e, i)
                    }
                    )) : ne(t, e, i) : void 0
                },
                set: function (t, n, i) {
                    var o = i && Pt(t);
                    return te(0, n, i ? ee(t, e, i, d.boxSizing && "border-box" === f.css(t, "boxSizing", !1, o), o) : 0)
                }
            }
        }
        )),
        d.opacity || (f.cssHooks.opacity = {
            get: function (t, e) {
                return Ut.test((e && t.currentStyle ? t.currentStyle.filter : t.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : e ? "1" : ""
            },
            set: function (t, e) {
                var n = t.style
                    , i = t.currentStyle
                    , o = f.isNumeric(e) ? "alpha(opacity=" + 100 * e + ")" : ""
                    , r = i && i.filter || n.filter || "";
                n.zoom = 1,
                    (e >= 1 || "" === e) && "" === f.trim(r.replace(zt, "")) && n.removeAttribute && (n.removeAttribute("filter"),
                        "" === e || i && !i.filter) || (n.filter = zt.test(r) ? r.replace(zt, o) : r + " " + o)
            }
        }),
        f.cssHooks.marginRight = Wt(d.reliableMarginRight, (function (t, e) {
            return e ? Ft(t, {
                display: "inline-block"
            }, Mt, [t, "marginRight"]) : void 0
        }
        )),
        f.cssHooks.marginLeft = Wt(d.reliableMarginLeft, (function (t, e) {
            return e ? (parseFloat(Mt(t, "marginLeft")) || (f.contains(t.ownerDocument, t) ? t.getBoundingClientRect().left - Ft(t, {
                marginLeft: 0
            }, (function () {
                return t.getBoundingClientRect().left
            }
            )) : 0)) + "px" : void 0
        }
        )),
        f.each({
            margin: "",
            padding: "",
            border: "Width"
        }, (function (t, e) {
            f.cssHooks[t + e] = {
                expand: function (n) {
                    for (var i = 0, o = {}, r = "string" == typeof n ? n.split(" ") : [n]; 4 > i; i++)
                        o[t + U[i] + e] = r[i] || r[i - 2] || r[0];
                    return o
                }
            },
                Rt.test(t) || (f.cssHooks[t + e].set = te)
        }
        )),
        f.fn.extend({
            css: function (t, e) {
                return Q(this, (function (t, e, n) {
                    var i, o, r = {}, s = 0;
                    if (f.isArray(e)) {
                        for (i = Pt(t),
                            o = e.length; o > s; s++)
                            r[e[s]] = f.css(t, e[s], !1, i);
                        return r
                    }
                    return void 0 !== n ? f.style(t, e, n) : f.css(t, e)
                }
                ), t, e, arguments.length > 1)
            },
            show: function () {
                return Zt(this, !0)
            },
            hide: function () {
                return Zt(this)
            },
            toggle: function (t) {
                return "boolean" == typeof t ? t ? this.show() : this.hide() : this.each((function () {
                    X(this) ? f(this).show() : f(this).hide()
                }
                ))
            }
        }),
        f.Tween = ie,
        (ie.prototype = {
            constructor: ie,
            init: function (t, e, n, i, o, r) {
                this.elem = t,
                    this.prop = n,
                    this.easing = o || f.easing._default,
                    this.options = e,
                    this.start = this.now = this.cur(),
                    this.end = i,
                    this.unit = r || (f.cssNumber[n] ? "" : "px")
            },
            cur: function () {
                var t = ie.propHooks[this.prop];
                return t && t.get ? t.get(this) : ie.propHooks._default.get(this)
            },
            run: function (t) {
                var e, n = ie.propHooks[this.prop];
                return this.pos = e = this.options.duration ? f.easing[this.easing](t, this.options.duration * t, 0, 1, this.options.duration) : t,
                    this.now = (this.end - this.start) * e + this.start,
                    this.options.step && this.options.step.call(this.elem, this.now, this),
                    n && n.set ? n.set(this) : ie.propHooks._default.set(this),
                    this
            }
        }).init.prototype = ie.prototype,
        (ie.propHooks = {
            _default: {
                get: function (t) {
                    var e;
                    return 1 !== t.elem.nodeType || null != t.elem[t.prop] && null == t.elem.style[t.prop] ? t.elem[t.prop] : (e = f.css(t.elem, t.prop, "")) && "auto" !== e ? e : 0
                },
                set: function (t) {
                    f.fx.step[t.prop] ? f.fx.step[t.prop](t) : 1 !== t.elem.nodeType || null == t.elem.style[f.cssProps[t.prop]] && !f.cssHooks[t.prop] ? t.elem[t.prop] = t.now : f.style(t.elem, t.prop, t.now + t.unit)
                }
            }
        }).scrollTop = ie.propHooks.scrollLeft = {
            set: function (t) {
                t.elem.nodeType && t.elem.parentNode && (t.elem[t.prop] = t.now)
            }
        },
        f.easing = {
            linear: function (t) {
                return t
            },
            swing: function (t) {
                return .5 - Math.cos(t * Math.PI) / 2
            },
            _default: "swing"
        },
        f.fx = ie.prototype.init,
        f.fx.step = {};
    var oe, re, se = /^(?:toggle|show|hide)$/, ae = /queueHooks$/;
    function le() {
        return t.setTimeout((function () {
            oe = void 0
        }
        )),
            oe = f.now()
    }
    function ue(t, e) {
        var n, i = {
            height: t
        }, o = 0;
        for (e = e ? 1 : 0; 4 > o; o += 2 - e)
            i["margin" + (n = U[o])] = i["padding" + n] = t;
        return e && (i.opacity = i.width = t),
            i
    }
    function ce(t, e, n) {
        for (var i, o = (de.tweeners[e] || []).concat(de.tweeners["*"]), r = 0, s = o.length; s > r; r++)
            if (i = o[r].call(n, e, t))
                return i
    }
    function de(t, e, n) {
        var i, o, r = 0, s = de.prefilters.length, a = f.Deferred().always((function () {
            delete l.elem
        }
        )), l = function () {
            if (o)
                return !1;
            for (var e = oe || le(), n = Math.max(0, u.startTime + u.duration - e), i = 1 - (n / u.duration || 0), r = 0, s = u.tweens.length; s > r; r++)
                u.tweens[r].run(i);
            return a.notifyWith(t, [u, i, n]),
                1 > i && s ? n : (a.resolveWith(t, [u]),
                    !1)
        }, u = a.promise({
            elem: t,
            props: f.extend({}, e),
            opts: f.extend(!0, {
                specialEasing: {},
                easing: f.easing._default
            }, n),
            originalProperties: e,
            originalOptions: n,
            startTime: oe || le(),
            duration: n.duration,
            tweens: [],
            createTween: function (e, n) {
                var i = f.Tween(t, u.opts, e, n, u.opts.specialEasing[e] || u.opts.easing);
                return u.tweens.push(i),
                    i
            },
            stop: function (e) {
                var n = 0
                    , i = e ? u.tweens.length : 0;
                if (o)
                    return this;
                for (o = !0; i > n; n++)
                    u.tweens[n].run(1);
                return e ? (a.notifyWith(t, [u, 1, 0]),
                    a.resolveWith(t, [u, e])) : a.rejectWith(t, [u, e]),
                    this
            }
        }), c = u.props;
        for (function (t, e) {
            var n, i, o, r, s;
            for (n in t)
                if (o = e[i = f.camelCase(n)],
                    f.isArray(r = t[n]) && (o = r[1],
                        r = t[n] = r[0]),
                    n !== i && (t[i] = r,
                        delete t[n]),
                    (s = f.cssHooks[i]) && "expand" in s)
                    for (n in r = s.expand(r),
                        delete t[i],
                        r)
                        n in t || (t[n] = r[n],
                            e[n] = o);
                else
                    e[i] = o
        }(c, u.opts.specialEasing); s > r; r++)
            if (i = de.prefilters[r].call(u, t, c, u.opts))
                return f.isFunction(i.stop) && (f._queueHooks(u.elem, u.opts.queue).stop = f.proxy(i.stop, i)),
                    i;
        return f.map(c, ce, u),
            f.isFunction(u.opts.start) && u.opts.start.call(t, u),
            f.fx.timer(f.extend(l, {
                elem: t,
                anim: u,
                queue: u.opts.queue
            })),
            u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
    }
    f.Animation = f.extend(de, {
        tweeners: {
            "*": [function (t, e) {
                var n = this.createTween(t, e);
                return V(n.elem, t, z.exec(e), n),
                    n
            }
            ]
        },
        tweener: function (t, e) {
            f.isFunction(t) ? (e = t,
                t = ["*"]) : t = t.match(O);
            for (var n, i = 0, o = t.length; o > i; i++)
                (de.tweeners[n = t[i]] = de.tweeners[n] || []).unshift(e)
        },
        prefilters: [function (t, e, n) {
            var i, o, r, s, a, l, u, c = this, p = {}, h = t.style, g = t.nodeType && X(t), m = f._data(t, "fxshow");
            for (i in n.queue || (null == (a = f._queueHooks(t, "fx")).unqueued && (a.unqueued = 0,
                l = a.empty.fire,
                a.empty.fire = function () {
                    a.unqueued || l()
                }
            ),
                a.unqueued++,
                c.always((function () {
                    c.always((function () {
                        a.unqueued--,
                            f.queue(t, "fx").length || a.empty.fire()
                    }
                    ))
                }
                ))),
                1 === t.nodeType && ("height" in e || "width" in e) && (n.overflow = [h.overflow, h.overflowX, h.overflowY],
                    "inline" === ("none" === (u = f.css(t, "display")) ? f._data(t, "olddisplay") || Ht(t.nodeName) : u) && "none" === f.css(t, "float") && (d.inlineBlockNeedsLayout && "inline" !== Ht(t.nodeName) ? h.zoom = 1 : h.display = "inline-block")),
                n.overflow && (h.overflow = "hidden",
                    d.shrinkWrapBlocks() || c.always((function () {
                        h.overflow = n.overflow[0],
                            h.overflowX = n.overflow[1],
                            h.overflowY = n.overflow[2]
                    }
                    ))),
                e)
                if (se.exec(o = e[i])) {
                    if (delete e[i],
                        r = r || "toggle" === o,
                        o === (g ? "hide" : "show")) {
                        if ("show" !== o || !m || void 0 === m[i])
                            continue;
                        g = !0
                    }
                    p[i] = m && m[i] || f.style(t, i)
                } else
                    u = void 0;
            if (f.isEmptyObject(p))
                "inline" === ("none" === u ? Ht(t.nodeName) : u) && (h.display = u);
            else
                for (i in m ? "hidden" in m && (g = m.hidden) : m = f._data(t, "fxshow", {}),
                    r && (m.hidden = !g),
                    g ? f(t).show() : c.done((function () {
                        f(t).hide()
                    }
                    )),
                    c.done((function () {
                        var e;
                        for (e in f._removeData(t, "fxshow"),
                            p)
                            f.style(t, e, p[e])
                    }
                    )),
                    p)
                    s = ce(g ? m[i] : 0, i, c),
                        i in m || (m[i] = s.start,
                            g && (s.end = s.start,
                                s.start = "width" === i || "height" === i ? 1 : 0))
        }
        ],
        prefilter: function (t, e) {
            e ? de.prefilters.unshift(t) : de.prefilters.push(t)
        }
    }),
        f.speed = function (t, e, n) {
            var i = t && "object" == typeof t ? f.extend({}, t) : {
                complete: n || !n && e || f.isFunction(t) && t,
                duration: t,
                easing: n && e || e && !f.isFunction(e) && e
            };
            return i.duration = f.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in f.fx.speeds ? f.fx.speeds[i.duration] : f.fx.speeds._default,
                null != i.queue && !0 !== i.queue || (i.queue = "fx"),
                i.old = i.complete,
                i.complete = function () {
                    f.isFunction(i.old) && i.old.call(this),
                        i.queue && f.dequeue(this, i.queue)
                }
                ,
                i
        }
        ,
        f.fn.extend({
            fadeTo: function (t, e, n, i) {
                return this.filter(X).css("opacity", 0).show().end().animate({
                    opacity: e
                }, t, n, i)
            },
            animate: function (t, e, n, i) {
                var o = f.isEmptyObject(t)
                    , r = f.speed(e, n, i)
                    , s = function () {
                        var e = de(this, f.extend({}, t), r);
                        (o || f._data(this, "finish")) && e.stop(!0)
                    };
                return s.finish = s,
                    o || !1 === r.queue ? this.each(s) : this.queue(r.queue, s)
            },
            stop: function (t, e, n) {
                var i = function (t) {
                    var e = t.stop;
                    delete t.stop,
                        e(n)
                };
                return "string" != typeof t && (n = e,
                    e = t,
                    t = void 0),
                    e && !1 !== t && this.queue(t || "fx", []),
                    this.each((function () {
                        var e = !0
                            , o = null != t && t + "queueHooks"
                            , r = f.timers
                            , s = f._data(this);
                        if (o)
                            s[o] && s[o].stop && i(s[o]);
                        else
                            for (o in s)
                                s[o] && s[o].stop && ae.test(o) && i(s[o]);
                        for (o = r.length; o--;)
                            r[o].elem !== this || null != t && r[o].queue !== t || (r[o].anim.stop(n),
                                e = !1,
                                r.splice(o, 1));
                        !e && n || f.dequeue(this, t)
                    }
                    ))
            },
            finish: function (t) {
                return !1 !== t && (t = t || "fx"),
                    this.each((function () {
                        var e, n = f._data(this), i = n[t + "queue"], o = n[t + "queueHooks"], r = f.timers, s = i ? i.length : 0;
                        for (n.finish = !0,
                            f.queue(this, t, []),
                            o && o.stop && o.stop.call(this, !0),
                            e = r.length; e--;)
                            r[e].elem === this && r[e].queue === t && (r[e].anim.stop(!0),
                                r.splice(e, 1));
                        for (e = 0; s > e; e++)
                            i[e] && i[e].finish && i[e].finish.call(this);
                        delete n.finish
                    }
                    ))
            }
        }),
        f.each(["toggle", "show", "hide"], (function (t, e) {
            var n = f.fn[e];
            f.fn[e] = function (t, i, o) {
                return null == t || "boolean" == typeof t ? n.apply(this, arguments) : this.animate(ue(e, !0), t, i, o)
            }
        }
        )),
        f.each({
            slideDown: ue("show"),
            slideUp: ue("hide"),
            slideToggle: ue("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, (function (t, e) {
            f.fn[t] = function (t, n, i) {
                return this.animate(e, t, n, i)
            }
        }
        )),
        f.timers = [],
        f.fx.tick = function () {
            var t, e = f.timers, n = 0;
            for (oe = f.now(); n < e.length; n++)
                (t = e[n])() || e[n] !== t || e.splice(n--, 1);
            e.length || f.fx.stop(),
                oe = void 0
        }
        ,
        f.fx.timer = function (t) {
            f.timers.push(t),
                t() ? f.fx.start() : f.timers.pop()
        }
        ,
        f.fx.interval = 13,
        f.fx.start = function () {
            re || (re = t.setInterval(f.fx.tick, f.fx.interval))
        }
        ,
        f.fx.stop = function () {
            t.clearInterval(re),
                re = null
        }
        ,
        f.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        },
        f.fn.delay = function (e, n) {
            return e = f.fx && f.fx.speeds[e] || e,
                this.queue(n = n || "fx", (function (n, i) {
                    var o = t.setTimeout(n, e);
                    i.stop = function () {
                        t.clearTimeout(o)
                    }
                }
                ))
        }
        ,
        function () {
            var t, e = i.createElement("input"), n = i.createElement("div"), o = i.createElement("select"), r = o.appendChild(i.createElement("option"));
            (n = i.createElement("div")).setAttribute("className", "t"),
                n.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
                t = n.getElementsByTagName("a")[0],
                e.setAttribute("type", "checkbox"),
                n.appendChild(e),
                (t = n.getElementsByTagName("a")[0]).style.cssText = "top:1px",
                d.getSetAttribute = "t" !== n.className,
                d.style = /top/.test(t.getAttribute("style")),
                d.hrefNormalized = "/a" === t.getAttribute("href"),
                d.checkOn = !!e.value,
                d.optSelected = r.selected,
                d.enctype = !!i.createElement("form").enctype,
                o.disabled = !0,
                d.optDisabled = !r.disabled,
                (e = i.createElement("input")).setAttribute("value", ""),
                d.input = "" === e.getAttribute("value"),
                e.value = "t",
                e.setAttribute("type", "radio"),
                d.radioValue = "t" === e.value
        }();
    var pe = /\r/g
        , fe = /[\x20\t\r\n\f]+/g;
    f.fn.extend({
        val: function (t) {
            var e, n, i, o = this[0];
            return arguments.length ? (i = f.isFunction(t),
                this.each((function (n) {
                    var o;
                    1 === this.nodeType && (null == (o = i ? t.call(this, n, f(this).val()) : t) ? o = "" : "number" == typeof o ? o += "" : f.isArray(o) && (o = f.map(o, (function (t) {
                        return null == t ? "" : t + ""
                    }
                    ))),
                        (e = f.valHooks[this.type] || f.valHooks[this.nodeName.toLowerCase()]) && "set" in e && void 0 !== e.set(this, o, "value") || (this.value = o))
                }
                ))) : o ? (e = f.valHooks[o.type] || f.valHooks[o.nodeName.toLowerCase()]) && "get" in e && void 0 !== (n = e.get(o, "value")) ? n : "string" == typeof (n = o.value) ? n.replace(pe, "") : null == n ? "" : n : void 0
        }
    }),
        f.extend({
            valHooks: {
                option: {
                    get: function (t) {
                        var e = f.find.attr(t, "value");
                        return null != e ? e : f.trim(f.text(t)).replace(fe, " ")
                    }
                },
                select: {
                    get: function (t) {
                        for (var e, n, i = t.options, o = t.selectedIndex, r = "select-one" === t.type || 0 > o, s = r ? null : [], a = r ? o + 1 : i.length, l = 0 > o ? a : r ? o : 0; a > l; l++)
                            if (((n = i[l]).selected || l === o) && (d.optDisabled ? !n.disabled : null === n.getAttribute("disabled")) && (!n.parentNode.disabled || !f.nodeName(n.parentNode, "optgroup"))) {
                                if (e = f(n).val(),
                                    r)
                                    return e;
                                s.push(e)
                            }
                        return s
                    },
                    set: function (t, e) {
                        for (var n, i, o = t.options, r = f.makeArray(e), s = o.length; s--;)
                            if (f.inArray(f.valHooks.option.get(i = o[s]), r) > -1)
                                try {
                                    i.selected = n = !0
                                } catch (a) { }
                            else
                                i.selected = !1;
                        return n || (t.selectedIndex = -1),
                            o
                    }
                }
            }
        }),
        f.each(["radio", "checkbox"], (function () {
            f.valHooks[this] = {
                set: function (t, e) {
                    return f.isArray(e) ? t.checked = f.inArray(f(t).val(), e) > -1 : void 0
                }
            },
                d.checkOn || (f.valHooks[this].get = function (t) {
                    return null === t.getAttribute("value") ? "on" : t.value
                }
                )
        }
        ));
    var he, ge, me = f.expr.attrHandle, ve = /^(?:checked|selected)$/i, ye = d.getSetAttribute, be = d.input;
    f.fn.extend({
        attr: function (t, e) {
            return Q(this, f.attr, t, e, arguments.length > 1)
        },
        removeAttr: function (t) {
            return this.each((function () {
                f.removeAttr(this, t)
            }
            ))
        }
    }),
        f.extend({
            attr: function (t, e, n) {
                var i, o, r = t.nodeType;
                if (3 !== r && 8 !== r && 2 !== r)
                    return void 0 === t.getAttribute ? f.prop(t, e, n) : (1 === r && f.isXMLDoc(t) || (e = e.toLowerCase(),
                        o = f.attrHooks[e] || (f.expr.match.bool.test(e) ? ge : he)),
                        void 0 !== n ? null === n ? void f.removeAttr(t, e) : o && "set" in o && void 0 !== (i = o.set(t, n, e)) ? i : (t.setAttribute(e, n + ""),
                            n) : o && "get" in o && null !== (i = o.get(t, e)) ? i : null == (i = f.find.attr(t, e)) ? void 0 : i)
            },
            attrHooks: {
                type: {
                    set: function (t, e) {
                        if (!d.radioValue && "radio" === e && f.nodeName(t, "input")) {
                            var n = t.value;
                            return t.setAttribute("type", e),
                                n && (t.value = n),
                                e
                        }
                    }
                }
            },
            removeAttr: function (t, e) {
                var n, i, o = 0, r = e && e.match(O);
                if (r && 1 === t.nodeType)
                    for (; n = r[o++];)
                        i = f.propFix[n] || n,
                            f.expr.match.bool.test(n) ? be && ye || !ve.test(n) ? t[i] = !1 : t[f.camelCase("default-" + n)] = t[i] = !1 : f.attr(t, n, ""),
                            t.removeAttribute(ye ? n : i)
            }
        }),
        ge = {
            set: function (t, e, n) {
                return !1 === e ? f.removeAttr(t, n) : be && ye || !ve.test(n) ? t.setAttribute(!ye && f.propFix[n] || n, n) : t[f.camelCase("default-" + n)] = t[n] = !0,
                    n
            }
        },
        f.each(f.expr.match.bool.source.match(/\w+/g), (function (t, e) {
            var n = me[e] || f.find.attr;
            me[e] = be && ye || !ve.test(e) ? function (t, e, i) {
                var o, r;
                return i || (r = me[e],
                    me[e] = o,
                    o = null != n(t, e, i) ? e.toLowerCase() : null,
                    me[e] = r),
                    o
            }
                : function (t, e, n) {
                    return n ? void 0 : t[f.camelCase("default-" + e)] ? e.toLowerCase() : null
                }
        }
        )),
        be && ye || (f.attrHooks.value = {
            set: function (t, e, n) {
                return f.nodeName(t, "input") ? void (t.defaultValue = e) : he && he.set(t, e, n)
            }
        }),
        ye || (he = {
            set: function (t, e, n) {
                var i = t.getAttributeNode(n);
                return i || t.setAttributeNode(i = t.ownerDocument.createAttribute(n)),
                    i.value = e += "",
                    "value" === n || e === t.getAttribute(n) ? e : void 0
            }
        },
            me.id = me.name = me.coords = function (t, e, n) {
                var i;
                return n ? void 0 : (i = t.getAttributeNode(e)) && "" !== i.value ? i.value : null
            }
            ,
            f.valHooks.button = {
                get: function (t, e) {
                    var n = t.getAttributeNode(e);
                    return n && n.specified ? n.value : void 0
                },
                set: he.set
            },
            f.attrHooks.contenteditable = {
                set: function (t, e, n) {
                    he.set(t, "" !== e && e, n)
                }
            },
            f.each(["width", "height"], (function (t, e) {
                f.attrHooks[e] = {
                    set: function (t, n) {
                        return "" === n ? (t.setAttribute(e, "auto"),
                            n) : void 0
                    }
                }
            }
            ))),
        d.style || (f.attrHooks.style = {
            get: function (t) {
                return t.style.cssText || void 0
            },
            set: function (t, e) {
                return t.style.cssText = e + ""
            }
        });
    var xe = /^(?:input|select|textarea|button|object)$/i
        , we = /^(?:a|area)$/i;
    f.fn.extend({
        prop: function (t, e) {
            return Q(this, f.prop, t, e, arguments.length > 1)
        },
        removeProp: function (t) {
            return t = f.propFix[t] || t,
                this.each((function () {
                    try {
                        this[t] = void 0,
                            delete this[t]
                    } catch (e) { }
                }
                ))
        }
    }),
        f.extend({
            prop: function (t, e, n) {
                var i, o, r = t.nodeType;
                if (3 !== r && 8 !== r && 2 !== r)
                    return 1 === r && f.isXMLDoc(t) || (o = f.propHooks[e = f.propFix[e] || e]),
                        void 0 !== n ? o && "set" in o && void 0 !== (i = o.set(t, n, e)) ? i : t[e] = n : o && "get" in o && null !== (i = o.get(t, e)) ? i : t[e]
            },
            propHooks: {
                tabIndex: {
                    get: function (t) {
                        var e = f.find.attr(t, "tabindex");
                        return e ? parseInt(e, 10) : xe.test(t.nodeName) || we.test(t.nodeName) && t.href ? 0 : -1
                    }
                }
            },
            propFix: {
                for: "htmlFor",
                class: "className"
            }
        }),
        d.hrefNormalized || f.each(["href", "src"], (function (t, e) {
            f.propHooks[e] = {
                get: function (t) {
                    return t.getAttribute(e, 4)
                }
            }
        }
        )),
        d.optSelected || (f.propHooks.selected = {
            get: function (t) {
                return null
            },
            set: function (t) { }
        }),
        f.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], (function () {
            f.propFix[this.toLowerCase()] = this
        }
        )),
        d.enctype || (f.propFix.enctype = "encoding");
    var Te = /[\t\r\n\f]/g;
    function Ce(t) {
        return f.attr(t, "class") || ""
    }
    f.fn.extend({
        addClass: function (t) {
            var e, n, i, o, r, s, a, l = 0;
            if (f.isFunction(t))
                return this.each((function (e) {
                    f(this).addClass(t.call(this, e, Ce(this)))
                }
                ));
            if ("string" == typeof t && t)
                for (e = t.match(O) || []; n = this[l++];)
                    if (o = Ce(n),
                        i = 1 === n.nodeType && (" " + o + " ").replace(Te, " ")) {
                        for (s = 0; r = e[s++];)
                            i.indexOf(" " + r + " ") < 0 && (i += r + " ");
                        o !== (a = f.trim(i)) && f.attr(n, "class", a)
                    }
            return this
        },
        removeClass: function (t) {
            var e, n, i, o, r, s, a, l = 0;
            if (f.isFunction(t))
                return this.each((function (e) {
                    f(this).removeClass(t.call(this, e, Ce(this)))
                }
                ));
            if (!arguments.length)
                return this.attr("class", "");
            if ("string" == typeof t && t)
                for (e = t.match(O) || []; n = this[l++];)
                    if (o = Ce(n),
                        i = 1 === n.nodeType && (" " + o + " ").replace(Te, " ")) {
                        for (s = 0; r = e[s++];)
                            for (; i.indexOf(" " + r + " ") > -1;)
                                i = i.replace(" " + r + " ", " ");
                        o !== (a = f.trim(i)) && f.attr(n, "class", a)
                    }
            return this
        },
        toggleClass: function (t, e) {
            var n = typeof t;
            return "boolean" == typeof e && "string" === n ? e ? this.addClass(t) : this.removeClass(t) : f.isFunction(t) ? this.each((function (n) {
                f(this).toggleClass(t.call(this, n, Ce(this), e), e)
            }
            )) : this.each((function () {
                var e, i, o, r;
                if ("string" === n)
                    for (i = 0,
                        o = f(this),
                        r = t.match(O) || []; e = r[i++];)
                        o.hasClass(e) ? o.removeClass(e) : o.addClass(e);
                else
                    void 0 !== t && "boolean" !== n || ((e = Ce(this)) && f._data(this, "__className__", e),
                        f.attr(this, "class", e || !1 === t ? "" : f._data(this, "__className__") || ""))
            }
            ))
        },
        hasClass: function (t) {
            var e, n, i = 0;
            for (e = " " + t + " "; n = this[i++];)
                if (1 === n.nodeType && (" " + Ce(n) + " ").replace(Te, " ").indexOf(e) > -1)
                    return !0;
            return !1
        }
    }),
        f.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), (function (t, e) {
            f.fn[e] = function (t, n) {
                return arguments.length > 0 ? this.on(e, null, t, n) : this.trigger(e)
            }
        }
        )),
        f.fn.extend({
            hover: function (t, e) {
                return this.mouseenter(t).mouseleave(e || t)
            }
        });
    var Ee = t.location
        , Se = f.now()
        , ke = /\?/
        , Ne = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
    f.parseJSON = function (e) {
        if (t.JSON && t.JSON.parse)
            return t.JSON.parse(e + "");
        var n, i = null, o = f.trim(e + "");
        return o && !f.trim(o.replace(Ne, (function (t, e, o, r) {
            return n && e && (i = 0),
                0 === i ? t : (n = o || e,
                    i += !r - !o,
                    "")
        }
        ))) ? Function("return " + o)() : f.error("Invalid JSON: " + e)
    }
        ,
        f.parseXML = function (e) {
            var n;
            if (!e || "string" != typeof e)
                return null;
            try {
                t.DOMParser ? n = (new t.DOMParser).parseFromString(e, "text/xml") : ((n = new t.ActiveXObject("Microsoft.XMLDOM")).async = "false",
                    n.loadXML(e))
            } catch (o) {
                n = void 0
            }
            return n && n.documentElement && !n.getElementsByTagName("parsererror").length || f.error("Invalid XML: " + e),
                n
        }
        ;
    var $e = /#.*$/
        , Ae = /([?&])_=[^&]*/
        , De = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm
        , je = /^(?:GET|HEAD)$/
        , Le = /^\/\//
        , Oe = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/
        , Ie = {}
        , He = {}
        , Re = "*/".concat("*")
        , qe = Ee.href
        , Fe = Oe.exec(qe.toLowerCase()) || [];
    function _e(t) {
        return function (e, n) {
            "string" != typeof e && (n = e,
                e = "*");
            var i, o = 0, r = e.toLowerCase().match(O) || [];
            if (f.isFunction(n))
                for (; i = r[o++];)
                    "+" === i.charAt(0) ? (i = i.slice(1) || "*",
                        (t[i] = t[i] || []).unshift(n)) : (t[i] = t[i] || []).push(n)
        }
    }
    function Pe(t, e, n, i) {
        var o = {}
            , r = t === He;
        function s(a) {
            var l;
            return o[a] = !0,
                f.each(t[a] || [], (function (t, a) {
                    var u = a(e, n, i);
                    return "string" != typeof u || r || o[u] ? r ? !(l = u) : void 0 : (e.dataTypes.unshift(u),
                        s(u),
                        !1)
                }
                )),
                l
        }
        return s(e.dataTypes[0]) || !o["*"] && s("*")
    }
    function Me(t, e) {
        var n, i, o = f.ajaxSettings.flatOptions || {};
        for (i in e)
            void 0 !== e[i] && ((o[i] ? t : n || (n = {}))[i] = e[i]);
        return n && f.extend(!0, t, n),
            t
    }
    function Be(t) {
        return t.style && t.style.display || f.css(t, "display")
    }
    f.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: qe,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Fe[1]),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Re,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": f.parseJSON,
                "text xml": f.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function (t, e) {
            return e ? Me(Me(t, f.ajaxSettings), e) : Me(f.ajaxSettings, t)
        },
        ajaxPrefilter: _e(Ie),
        ajaxTransport: _e(He),
        ajax: function (e, n) {
            "object" == typeof e && (n = e,
                e = void 0);
            var i, o, r, s, a, l, u, c, d = f.ajaxSetup({}, n = n || {}), p = d.context || d, h = d.context && (p.nodeType || p.jquery) ? f(p) : f.event, g = f.Deferred(), m = f.Callbacks("once memory"), v = d.statusCode || {}, y = {}, b = {}, x = 0, w = "canceled", T = {
                readyState: 0,
                getResponseHeader: function (t) {
                    var e;
                    if (2 === x) {
                        if (!c)
                            for (c = {}; e = De.exec(s);)
                                c[e[1].toLowerCase()] = e[2];
                        e = c[t.toLowerCase()]
                    }
                    return null == e ? null : e
                },
                getAllResponseHeaders: function () {
                    return 2 === x ? s : null
                },
                setRequestHeader: function (t, e) {
                    var n = t.toLowerCase();
                    return x || (t = b[n] = b[n] || t,
                        y[t] = e),
                        this
                },
                overrideMimeType: function (t) {
                    return x || (d.mimeType = t),
                        this
                },
                statusCode: function (t) {
                    var e;
                    if (t)
                        if (2 > x)
                            for (e in t)
                                v[e] = [v[e], t[e]];
                        else
                            T.always(t[T.status]);
                    return this
                },
                abort: function (t) {
                    var e = t || w;
                    return u && u.abort(e),
                        E(0, e),
                        this
                }
            };
            if (g.promise(T).complete = m.add,
                T.success = T.done,
                T.error = T.fail,
                d.url = ((e || d.url || qe) + "").replace($e, "").replace(Le, Fe[1] + "//"),
                d.type = n.method || n.type || d.method || d.type,
                d.dataTypes = f.trim(d.dataType || "*").toLowerCase().match(O) || [""],
                null == d.crossDomain && (i = Oe.exec(d.url.toLowerCase()),
                    d.crossDomain = !(!i || i[1] === Fe[1] && i[2] === Fe[2] && (i[3] || ("http:" === i[1] ? "80" : "443")) === (Fe[3] || ("http:" === Fe[1] ? "80" : "443")))),
                d.data && d.processData && "string" != typeof d.data && (d.data = f.param(d.data, d.traditional)),
                Pe(Ie, d, n, T),
                2 === x)
                return T;
            for (o in (l = f.event && d.global) && 0 == f.active++ && f.event.trigger("ajaxStart"),
                d.type = d.type.toUpperCase(),
                d.hasContent = !je.test(d.type),
                r = d.url,
                d.hasContent || (d.data && (r = d.url += (ke.test(r) ? "&" : "?") + d.data,
                    delete d.data),
                    !1 === d.cache && (d.url = Ae.test(r) ? r.replace(Ae, "$1_=" + Se++) : r + (ke.test(r) ? "&" : "?") + "_=" + Se++)),
                d.ifModified && (f.lastModified[r] && T.setRequestHeader("If-Modified-Since", f.lastModified[r]),
                    f.etag[r] && T.setRequestHeader("If-None-Match", f.etag[r])),
                (d.data && d.hasContent && !1 !== d.contentType || n.contentType) && T.setRequestHeader("Content-Type", d.contentType),
                T.setRequestHeader("Accept", d.dataTypes[0] && d.accepts[d.dataTypes[0]] ? d.accepts[d.dataTypes[0]] + ("*" !== d.dataTypes[0] ? ", " + Re + "; q=0.01" : "") : d.accepts["*"]),
                d.headers)
                T.setRequestHeader(o, d.headers[o]);
            if (d.beforeSend && (!1 === d.beforeSend.call(p, T, d) || 2 === x))
                return T.abort();
            for (o in w = "abort",
            {
                success: 1,
                error: 1,
                complete: 1
            })
                T[o](d[o]);
            if (u = Pe(He, d, n, T)) {
                if (T.readyState = 1,
                    l && h.trigger("ajaxSend", [T, d]),
                    2 === x)
                    return T;
                d.async && d.timeout > 0 && (a = t.setTimeout((function () {
                    T.abort("timeout")
                }
                ), d.timeout));
                try {
                    x = 1,
                        u.send(y, E)
                } catch (C) {
                    if (!(2 > x))
                        throw C;
                    E(-1, C)
                }
            } else
                E(-1, "No Transport");
            function E(e, n, i, o) {
                var c, y, b, w, C, E = n;
                2 !== x && (x = 2,
                    a && t.clearTimeout(a),
                    u = void 0,
                    s = o || "",
                    T.readyState = e > 0 ? 4 : 0,
                    c = e >= 200 && 300 > e || 304 === e,
                    i && (w = function (t, e, n) {
                        for (var i, o, r, s, a = t.contents, l = t.dataTypes; "*" === l[0];)
                            l.shift(),
                                void 0 === o && (o = t.mimeType || e.getResponseHeader("Content-Type"));
                        if (o)
                            for (s in a)
                                if (a[s] && a[s].test(o)) {
                                    l.unshift(s);
                                    break
                                }
                        if (l[0] in n)
                            r = l[0];
                        else {
                            for (s in n) {
                                if (!l[0] || t.converters[s + " " + l[0]]) {
                                    r = s;
                                    break
                                }
                                i || (i = s)
                            }
                            r = r || i
                        }
                        return r ? (r !== l[0] && l.unshift(r),
                            n[r]) : void 0
                    }(d, T, i)),
                    w = function (t, e, n, i) {
                        var o, r, s, a, l, u = {}, c = t.dataTypes.slice();
                        if (c[1])
                            for (s in t.converters)
                                u[s.toLowerCase()] = t.converters[s];
                        for (r = c.shift(); r;)
                            if (t.responseFields[r] && (n[t.responseFields[r]] = e),
                                !l && i && t.dataFilter && (e = t.dataFilter(e, t.dataType)),
                                l = r,
                                r = c.shift())
                                if ("*" === r)
                                    r = l;
                                else if ("*" !== l && l !== r) {
                                    if (!(s = u[l + " " + r] || u["* " + r]))
                                        for (o in u)
                                            if ((a = o.split(" "))[1] === r && (s = u[l + " " + a[0]] || u["* " + a[0]])) {
                                                !0 === s ? s = u[o] : !0 !== u[o] && (r = a[0],
                                                    c.unshift(a[1]));
                                                break
                                            }
                                    if (!0 !== s)
                                        if (s && t.throws)
                                            e = s(e);
                                        else
                                            try {
                                                e = s(e)
                                            } catch (d) {
                                                return {
                                                    state: "parsererror",
                                                    error: s ? d : "No conversion from " + l + " to " + r
                                                }
                                            }
                                }
                        return {
                            state: "success",
                            data: e
                        }
                    }(d, w, T, c),
                    c ? (d.ifModified && ((C = T.getResponseHeader("Last-Modified")) && (f.lastModified[r] = C),
                        (C = T.getResponseHeader("etag")) && (f.etag[r] = C)),
                        204 === e || "HEAD" === d.type ? E = "nocontent" : 304 === e ? E = "notmodified" : (E = w.state,
                            y = w.data,
                            c = !(b = w.error))) : (b = E,
                                !e && E || (E = "error",
                                    0 > e && (e = 0))),
                    T.status = e,
                    T.statusText = (n || E) + "",
                    c ? g.resolveWith(p, [y, E, T]) : g.rejectWith(p, [T, E, b]),
                    T.statusCode(v),
                    v = void 0,
                    l && h.trigger(c ? "ajaxSuccess" : "ajaxError", [T, d, c ? y : b]),
                    m.fireWith(p, [T, E]),
                    l && (h.trigger("ajaxComplete", [T, d]),
                        --f.active || f.event.trigger("ajaxStop")))
            }
            return T
        },
        getJSON: function (t, e, n) {
            return f.get(t, e, n, "json")
        },
        getScript: function (t, e) {
            return f.get(t, void 0, e, "script")
        }
    }),
        f.each(["get", "post"], (function (t, e) {
            f[e] = function (t, n, i, o) {
                return f.isFunction(n) && (o = o || i,
                    i = n,
                    n = void 0),
                    f.ajax(f.extend({
                        url: t,
                        type: e,
                        dataType: o,
                        data: n,
                        success: i
                    }, f.isPlainObject(t) && t))
            }
        }
        )),
        f._evalUrl = function (t) {
            return f.ajax({
                url: t,
                type: "GET",
                dataType: "script",
                cache: !0,
                async: !1,
                global: !1,
                throws: !0
            })
        }
        ,
        f.fn.extend({
            wrapAll: function (t) {
                if (f.isFunction(t))
                    return this.each((function (e) {
                        f(this).wrapAll(t.call(this, e))
                    }
                    ));
                if (this[0]) {
                    var e = f(t, this[0].ownerDocument).eq(0).clone(!0);
                    this[0].parentNode && e.insertBefore(this[0]),
                        e.map((function () {
                            for (var t = this; t.firstChild && 1 === t.firstChild.nodeType;)
                                t = t.firstChild;
                            return t
                        }
                        )).append(this)
                }
                return this
            },
            wrapInner: function (t) {
                return f.isFunction(t) ? this.each((function (e) {
                    f(this).wrapInner(t.call(this, e))
                }
                )) : this.each((function () {
                    var e = f(this)
                        , n = e.contents();
                    n.length ? n.wrapAll(t) : e.append(t)
                }
                ))
            },
            wrap: function (t) {
                var e = f.isFunction(t);
                return this.each((function (n) {
                    f(this).wrapAll(e ? t.call(this, n) : t)
                }
                ))
            },
            unwrap: function () {
                return this.parent().each((function () {
                    f.nodeName(this, "body") || f(this).replaceWith(this.childNodes)
                }
                )).end()
            }
        }),
        f.expr.filters.hidden = function (t) {
            return d.reliableHiddenOffsets() ? t.offsetWidth <= 0 && t.offsetHeight <= 0 && !t.getClientRects().length : function (t) {
                if (!f.contains(t.ownerDocument || i, t))
                    return !0;
                for (; t && 1 === t.nodeType;) {
                    if ("none" === Be(t) || "hidden" === t.type)
                        return !0;
                    t = t.parentNode
                }
                return !1
            }(t)
        }
        ,
        f.expr.filters.visible = function (t) {
            return !f.expr.filters.hidden(t)
        }
        ;
    var We = /%20/g
        , ze = /\[\]$/
        , Ue = /\r?\n/g
        , Xe = /^(?:submit|button|image|reset|file)$/i
        , Ve = /^(?:input|select|textarea|keygen)/i;
    function Qe(t, e, n, i) {
        var o;
        if (f.isArray(e))
            f.each(e, (function (e, o) {
                n || ze.test(t) ? i(t, o) : Qe(t + "[" + ("object" == typeof o && null != o ? e : "") + "]", o, n, i)
            }
            ));
        else if (n || "object" !== f.type(e))
            i(t, e);
        else
            for (o in e)
                Qe(t + "[" + o + "]", e[o], n, i)
    }
    f.param = function (t, e) {
        var n, i = [], o = function (t, e) {
            e = f.isFunction(e) ? e() : null == e ? "" : e,
                i[i.length] = encodeURIComponent(t) + "=" + encodeURIComponent(e)
        };
        if (void 0 === e && (e = f.ajaxSettings && f.ajaxSettings.traditional),
            f.isArray(t) || t.jquery && !f.isPlainObject(t))
            f.each(t, (function () {
                o(this.name, this.value)
            }
            ));
        else
            for (n in t)
                Qe(n, t[n], e, o);
        return i.join("&").replace(We, "+")
    }
        ,
        f.fn.extend({
            serialize: function () {
                return f.param(this.serializeArray())
            },
            serializeArray: function () {
                return this.map((function () {
                    var t = f.prop(this, "elements");
                    return t ? f.makeArray(t) : this
                }
                )).filter((function () {
                    var t = this.type;
                    return this.name && !f(this).is(":disabled") && Ve.test(this.nodeName) && !Xe.test(t) && (this.checked || !J.test(t))
                }
                )).map((function (t, e) {
                    var n = f(this).val();
                    return null == n ? null : f.isArray(n) ? f.map(n, (function (t) {
                        return {
                            name: e.name,
                            value: t.replace(Ue, "\r\n")
                        }
                    }
                    )) : {
                        name: e.name,
                        value: n.replace(Ue, "\r\n")
                    }
                }
                )).get()
            }
        }),
        f.ajaxSettings.xhr = void 0 !== t.ActiveXObject ? function () {
            return this.isLocal ? Ze() : i.documentMode > 8 ? Ke() : /^(get|post|head|put|delete|options)$/i.test(this.type) && Ke() || Ze()
        }
            : Ke;
    var Je = 0
        , Ye = {}
        , Ge = f.ajaxSettings.xhr();
    function Ke() {
        try {
            return new t.XMLHttpRequest
        } catch (e) { }
    }
    function Ze() {
        try {
            return new t.ActiveXObject("Microsoft.XMLHTTP")
        } catch (e) { }
    }
    t.attachEvent && t.attachEvent("onunload", (function () {
        for (var t in Ye)
            Ye[t](void 0, !0)
    }
    )),
        d.cors = !!Ge && "withCredentials" in Ge,
        (Ge = d.ajax = !!Ge) && f.ajaxTransport((function (e) {
            var n;
            if (!e.crossDomain || d.cors)
                return {
                    send: function (i, o) {
                        var r, s = e.xhr(), a = ++Je;
                        if (s.open(e.type, e.url, e.async, e.username, e.password),
                            e.xhrFields)
                            for (r in e.xhrFields)
                                s[r] = e.xhrFields[r];
                        for (r in e.mimeType && s.overrideMimeType && s.overrideMimeType(e.mimeType),
                            e.crossDomain || i["X-Requested-With"] || (i["X-Requested-With"] = "XMLHttpRequest"),
                            i)
                            void 0 !== i[r] && s.setRequestHeader(r, i[r] + "");
                        s.send(e.hasContent && e.data || null),
                            n = function (t, i) {
                                var r, l, u;
                                if (n && (i || 4 === s.readyState))
                                    if (delete Ye[a],
                                        n = void 0,
                                        s.onreadystatechange = f.noop,
                                        i)
                                        4 !== s.readyState && s.abort();
                                    else {
                                        u = {},
                                            r = s.status,
                                            "string" == typeof s.responseText && (u.text = s.responseText);
                                        try {
                                            l = s.statusText
                                        } catch (c) {
                                            l = ""
                                        }
                                        r || !e.isLocal || e.crossDomain ? 1223 === r && (r = 204) : r = u.text ? 200 : 404
                                    }
                                u && o(r, l, u, s.getAllResponseHeaders())
                            }
                            ,
                            e.async ? 4 === s.readyState ? t.setTimeout(n) : s.onreadystatechange = Ye[a] = n : n()
                    },
                    abort: function () {
                        n && n(void 0, !0)
                    }
                }
        }
        )),
        f.ajaxSetup({
            accepts: {
                script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
            },
            contents: {
                script: /\b(?:java|ecma)script\b/
            },
            converters: {
                "text script": function (t) {
                    return f.globalEval(t),
                        t
                }
            }
        }),
        f.ajaxPrefilter("script", (function (t) {
            void 0 === t.cache && (t.cache = !1),
                t.crossDomain && (t.type = "GET",
                    t.global = !1)
        }
        )),
        f.ajaxTransport("script", (function (t) {
            if (t.crossDomain) {
                var e, n = i.head || f("head")[0] || i.documentElement;
                return {
                    send: function (o, r) {
                        (e = i.createElement("script")).async = !0,
                            t.scriptCharset && (e.charset = t.scriptCharset),
                            e.src = t.url,
                            e.onload = e.onreadystatechange = function (t, n) {
                                (n || !e.readyState || /loaded|complete/.test(e.readyState)) && (e.onload = e.onreadystatechange = null,
                                    e.parentNode && e.parentNode.removeChild(e),
                                    e = null,
                                    n || r(200, "success"))
                            }
                            ,
                            n.insertBefore(e, n.firstChild)
                    },
                    abort: function () {
                        e && e.onload(void 0, !0)
                    }
                }
            }
        }
        ));
    var tn = []
        , en = /(=)\?(?=&|$)|\?\?/;
    f.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function () {
            var t = tn.pop() || f.expando + "_" + Se++;
            return this[t] = !0,
                t
        }
    }),
        f.ajaxPrefilter("json jsonp", (function (e, n, i) {
            var o, r, s, a = !1 !== e.jsonp && (en.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && en.test(e.data) && "data");
            return a || "jsonp" === e.dataTypes[0] ? (o = e.jsonpCallback = f.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback,
                a ? e[a] = e[a].replace(en, "$1" + o) : !1 !== e.jsonp && (e.url += (ke.test(e.url) ? "&" : "?") + e.jsonp + "=" + o),
                e.converters["script json"] = function () {
                    return s || f.error(o + " was not called"),
                        s[0]
                }
                ,
                e.dataTypes[0] = "json",
                r = t[o],
                t[o] = function () {
                    s = arguments
                }
                ,
                i.always((function () {
                    void 0 === r ? f(t).removeProp(o) : t[o] = r,
                        e[o] && (e.jsonpCallback = n.jsonpCallback,
                            tn.push(o)),
                        s && f.isFunction(r) && r(s[0]),
                        s = r = void 0
                }
                )),
                "script") : void 0
        }
        )),
        f.parseHTML = function (t, e, n) {
            if (!t || "string" != typeof t)
                return null;
            "boolean" == typeof e && (n = e,
                e = !1),
                e = e || i;
            var o = C.exec(t)
                , r = !n && [];
            return o ? [e.createElement(o[1])] : (o = at([t], e, r),
                r && r.length && f(r).remove(),
                f.merge([], o.childNodes))
        }
        ;
    var nn = f.fn.load;
    function on(t) {
        return f.isWindow(t) ? t : 9 === t.nodeType && (t.defaultView || t.parentWindow)
    }
    f.fn.load = function (t, e, n) {
        if ("string" != typeof t && nn)
            return nn.apply(this, arguments);
        var i, o, r, s = this, a = t.indexOf(" ");
        return a > -1 && (i = f.trim(t.slice(a, t.length)),
            t = t.slice(0, a)),
            f.isFunction(e) ? (n = e,
                e = void 0) : e && "object" == typeof e && (o = "POST"),
            s.length > 0 && f.ajax({
                url: t,
                type: o || "GET",
                dataType: "html",
                data: e
            }).done((function (t) {
                r = arguments,
                    s.html(i ? f("<div>").append(f.parseHTML(t)).find(i) : t)
            }
            )).always(n && function (t, e) {
                s.each((function () {
                    n.apply(this, r || [t.responseText, e, t])
                }
                ))
            }
            ),
            this
    }
        ,
        f.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function (t, e) {
            f.fn[e] = function (t) {
                return this.on(e, t)
            }
        }
        )),
        f.expr.filters.animated = function (t) {
            return f.grep(f.timers, (function (e) {
                return t === e.elem
            }
            )).length
        }
        ,
        f.offset = {
            setOffset: function (t, e, n) {
                var i, o, r, s, a, l, u = f.css(t, "position"), c = f(t), d = {};
                "static" === u && (t.style.position = "relative"),
                    a = c.offset(),
                    r = f.css(t, "top"),
                    l = f.css(t, "left"),
                    ("absolute" === u || "fixed" === u) && f.inArray("auto", [r, l]) > -1 ? (s = (i = c.position()).top,
                        o = i.left) : (s = parseFloat(r) || 0,
                            o = parseFloat(l) || 0),
                    f.isFunction(e) && (e = e.call(t, n, f.extend({}, a))),
                    null != e.top && (d.top = e.top - a.top + s),
                    null != e.left && (d.left = e.left - a.left + o),
                    "using" in e ? e.using.call(t, d) : c.css(d)
            }
        },
        f.fn.extend({
            offset: function (t) {
                if (arguments.length)
                    return void 0 === t ? this : this.each((function (e) {
                        f.offset.setOffset(this, t, e)
                    }
                    ));
                var e, n, i = {
                    top: 0,
                    left: 0
                }, o = this[0], r = o && o.ownerDocument;
                return r ? f.contains(e = r.documentElement, o) ? (void 0 !== o.getBoundingClientRect && (i = o.getBoundingClientRect()),
                    n = on(r),
                {
                    top: i.top + (n.pageYOffset || e.scrollTop) - (e.clientTop || 0),
                    left: i.left + (n.pageXOffset || e.scrollLeft) - (e.clientLeft || 0)
                }) : i : void 0
            },
            position: function () {
                if (this[0]) {
                    var t, e, n = {
                        top: 0,
                        left: 0
                    }, i = this[0];
                    return "fixed" === f.css(i, "position") ? e = i.getBoundingClientRect() : (t = this.offsetParent(),
                        e = this.offset(),
                        f.nodeName(t[0], "html") || (n = t.offset()),
                        n.top += f.css(t[0], "borderTopWidth", !0),
                        n.left += f.css(t[0], "borderLeftWidth", !0)),
                    {
                        top: e.top - n.top - f.css(i, "marginTop", !0),
                        left: e.left - n.left - f.css(i, "marginLeft", !0)
                    }
                }
            },
            offsetParent: function () {
                return this.map((function () {
                    for (var t = this.offsetParent; t && !f.nodeName(t, "html") && "static" === f.css(t, "position");)
                        t = t.offsetParent;
                    return t || _t
                }
                ))
            }
        }),
        f.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        }, (function (t, e) {
            var n = /Y/.test(e);
            f.fn[t] = function (i) {
                return Q(this, (function (t, i, o) {
                    var r = on(t);
                    return void 0 === o ? r ? e in r ? r[e] : r.document.documentElement[i] : t[i] : void (r ? r.scrollTo(n ? f(r).scrollLeft() : o, n ? o : f(r).scrollTop()) : t[i] = o)
                }
                ), t, i, arguments.length, null)
            }
        }
        )),
        f.each(["top", "left"], (function (t, e) {
            f.cssHooks[e] = Wt(d.pixelPosition, (function (t, n) {
                return n ? (n = Mt(t, e),
                    qt.test(n) ? f(t).position()[e] + "px" : n) : void 0
            }
            ))
        }
        )),
        f.each({
            Height: "height",
            Width: "width"
        }, (function (t, e) {
            f.each({
                padding: "inner" + t,
                content: e,
                "": "outer" + t
            }, (function (n, i) {
                f.fn[i] = function (i, o) {
                    var r = arguments.length && (n || "boolean" != typeof i)
                        , s = n || (!0 === i || !0 === o ? "margin" : "border");
                    return Q(this, (function (e, n, i) {
                        var o;
                        return f.isWindow(e) ? e.document.documentElement["client" + t] : 9 === e.nodeType ? (o = e.documentElement,
                            Math.max(e.body["scroll" + t], o["scroll" + t], e.body["offset" + t], o["offset" + t], o["client" + t])) : void 0 === i ? f.css(e, n, s) : f.style(e, n, i, s)
                    }
                    ), e, r ? i : void 0, r, null)
                }
            }
            ))
        }
        )),
        f.fn.extend({
            bind: function (t, e, n) {
                return this.on(t, null, e, n)
            },
            unbind: function (t, e) {
                return this.off(t, null, e)
            },
            delegate: function (t, e, n, i) {
                return this.on(e, t, n, i)
            },
            undelegate: function (t, e, n) {
                return 1 === arguments.length ? this.off(t, "**") : this.off(e, t || "**", n)
            }
        }),
        f.fn.size = function () {
            return this.length
        }
        ,
        f.fn.andSelf = f.fn.addBack,
        "function" == typeof define && define.amd && define("jquery", [], (function () {
            return f
        }
        ));
    var rn = t.jQuery
        , sn = t.$;
    return f.noConflict = function (e) {
        return t.$ === f && (t.$ = sn),
            e && t.jQuery === f && (t.jQuery = rn),
            f
    }
        ,
        e || (t.jQuery = t.$ = f),
        f
}
)),
    "undefined" == typeof jQuery)
    throw new Error("Bootstrap's JavaScript requires jQuery");
!function (t) {
    "use strict";
    var e = jQuery.fn.jquery.split(" ")[0].split(".");
    if (e[0] < 2 && e[1] < 9 || 1 == e[0] && 9 == e[1] && e[2] < 1 || 3 < e[0])
        throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 4")
}(),
    function (t) {
        "use strict";
        t.fn.emulateTransitionEnd = function (e) {
            var n = !1
                , i = this;
            return t(this).one("bsTransitionEnd", (function () {
                n = !0
            }
            )),
                setTimeout((function () {
                    n || t(i).trigger(t.support.transition.end)
                }
                ), e),
                this
        }
            ,
            t((function () {
                t.support.transition = function () {
                    var t = document.createElement("bootstrap")
                        , e = {
                            WebkitTransition: "webkitTransitionEnd",
                            MozTransition: "transitionend",
                            OTransition: "oTransitionEnd otransitionend",
                            transition: "transitionend"
                        };
                    for (var n in e)
                        if (void 0 !== t.style[n])
                            return {
                                end: e[n]
                            };
                    return !1
                }(),
                    t.support.transition && (t.event.special.bsTransitionEnd = {
                        bindType: t.support.transition.end,
                        delegateType: t.support.transition.end,
                        handle: function (e) {
                            if (t(e.target).is(this))
                                return e.handleObj.handler.apply(this, arguments)
                        }
                    })
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = '[data-dismiss="alert"]'
            , n = function (n) {
                t(n).on("click", e, this.close)
            };
        n.VERSION = "3.4.1",
            n.TRANSITION_DURATION = 150,
            n.prototype.close = function (e) {
                var i = t(this)
                    , o = i.attr("data-target");
                o || (o = (o = i.attr("href")) && o.replace(/.*(?=#[^\s]*$)/, "")),
                    o = "#" === o ? [] : o;
                var r = t(document).find(o);
                function s() {
                    r.detach().trigger("closed.bs.alert").remove()
                }
                e && e.preventDefault(),
                    r.length || (r = i.closest(".alert")),
                    r.trigger(e = t.Event("close.bs.alert")),
                    e.isDefaultPrevented() || (r.removeClass("in"),
                        t.support.transition && r.hasClass("fade") ? r.one("bsTransitionEnd", s).emulateTransitionEnd(n.TRANSITION_DURATION) : s())
            }
            ;
        var i = t.fn.alert;
        t.fn.alert = function (e) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.alert");
                o || i.data("bs.alert", o = new n(this)),
                    "string" == typeof e && o[e].call(i)
            }
            ))
        }
            ,
            t.fn.alert.Constructor = n,
            t.fn.alert.noConflict = function () {
                return t.fn.alert = i,
                    this
            }
            ,
            t(document).on("click.bs.alert.data-api", e, n.prototype.close)
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (n, i) {
            this.$element = t(n),
                this.options = t.extend({}, e.DEFAULTS, i),
                this.isLoading = !1
        };
        function n(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.button");
                o || i.data("bs.button", o = new e(this, "object" == typeof n && n)),
                    "toggle" == n ? o.toggle() : n && o.setState(n)
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.DEFAULTS = {
                loadingText: "loading..."
            },
            e.prototype.setState = function (e) {
                var n = "disabled"
                    , i = this.$element
                    , o = i.is("input") ? "val" : "html"
                    , r = i.data();
                e += "Text",
                    null == r.resetText && i.data("resetText", i[o]()),
                    setTimeout(t.proxy((function () {
                        i[o](null == r[e] ? this.options[e] : r[e]),
                            "loadingText" == e ? (this.isLoading = !0,
                                i.addClass(n).attr(n, n).prop(n, !0)) : this.isLoading && (this.isLoading = !1,
                                    i.removeClass(n).removeAttr(n).prop(n, !1))
                    }
                    ), this), 0)
            }
            ,
            e.prototype.toggle = function () {
                var t = !0
                    , e = this.$element.closest('[data-toggle="buttons"]');
                if (e.length) {
                    var n = this.$element.find("input");
                    "radio" == n.prop("type") ? (n.prop("checked") && (t = !1),
                        e.find(".active").removeClass("active"),
                        this.$element.addClass("active")) : "checkbox" == n.prop("type") && (n.prop("checked") !== this.$element.hasClass("active") && (t = !1),
                            this.$element.toggleClass("active")),
                        n.prop("checked", this.$element.hasClass("active")),
                        t && n.trigger("change")
                } else
                    this.$element.attr("aria-pressed", !this.$element.hasClass("active")),
                        this.$element.toggleClass("active")
            }
            ;
        var i = t.fn.button;
        t.fn.button = n,
            t.fn.button.Constructor = e,
            t.fn.button.noConflict = function () {
                return t.fn.button = i,
                    this
            }
            ,
            t(document).on("click.bs.button.data-api", '[data-toggle^="button"]', (function (e) {
                var i = t(e.target).closest(".btn");
                n.call(i, "toggle"),
                    t(e.target).is('input[type="radio"], input[type="checkbox"]') || (e.preventDefault(),
                        i.is("input,button") ? i.trigger("focus") : i.find("input:visible,button:visible").first().trigger("focus"))
            }
            )).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', (function (e) {
                t(e.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(e.type))
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (e, n) {
            this.$element = t(e),
                this.$indicators = this.$element.find(".carousel-indicators"),
                this.options = n,
                this.paused = null,
                this.sliding = null,
                this.interval = null,
                this.$active = null,
                this.$items = null,
                this.options.keyboard && this.$element.on("keydown.bs.carousel", t.proxy(this.keydown, this)),
                "hover" == this.options.pause && !("ontouchstart" in document.documentElement) && this.$element.on("mouseenter.bs.carousel", t.proxy(this.pause, this)).on("mouseleave.bs.carousel", t.proxy(this.cycle, this))
        };
        function n(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.carousel")
                    , r = t.extend({}, e.DEFAULTS, i.data(), "object" == typeof n && n)
                    , s = "string" == typeof n ? n : r.slide;
                o || i.data("bs.carousel", o = new e(this, r)),
                    "number" == typeof n ? o.to(n) : s ? o[s]() : r.interval && o.pause().cycle()
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.TRANSITION_DURATION = 600,
            e.DEFAULTS = {
                interval: 5e3,
                pause: "hover",
                wrap: !0,
                keyboard: !0
            },
            e.prototype.keydown = function (t) {
                if (!/input|textarea/i.test(t.target.tagName)) {
                    switch (t.which) {
                        case 37:
                            this.prev();
                            break;
                        case 39:
                            this.next();
                            break;
                        default:
                            return
                    }
                    t.preventDefault()
                }
            }
            ,
            e.prototype.cycle = function (e) {
                return e || (this.paused = !1),
                    this.interval && clearInterval(this.interval),
                    this.options.interval && !this.paused && (this.interval = setInterval(t.proxy(this.next, this), this.options.interval)),
                    this
            }
            ,
            e.prototype.getItemIndex = function (t) {
                return this.$items = t.parent().children(".item"),
                    this.$items.index(t || this.$active)
            }
            ,
            e.prototype.getItemForDirection = function (t, e) {
                var n = this.getItemIndex(e);
                return ("prev" == t && 0 === n || "next" == t && n == this.$items.length - 1) && !this.options.wrap ? e : this.$items.eq((n + ("prev" == t ? -1 : 1)) % this.$items.length)
            }
            ,
            e.prototype.to = function (t) {
                var e = this
                    , n = this.getItemIndex(this.$active = this.$element.find(".item.active"));
                if (!(t > this.$items.length - 1 || t < 0))
                    return this.sliding ? this.$element.one("slid.bs.carousel", (function () {
                        e.to(t)
                    }
                    )) : n == t ? this.pause().cycle() : this.slide(n < t ? "next" : "prev", this.$items.eq(t))
            }
            ,
            e.prototype.pause = function (e) {
                return e || (this.paused = !0),
                    this.$element.find(".next, .prev").length && t.support.transition && (this.$element.trigger(t.support.transition.end),
                        this.cycle(!0)),
                    this.interval = clearInterval(this.interval),
                    this
            }
            ,
            e.prototype.next = function () {
                if (!this.sliding)
                    return this.slide("next")
            }
            ,
            e.prototype.prev = function () {
                if (!this.sliding)
                    return this.slide("prev")
            }
            ,
            e.prototype.slide = function (n, i) {
                var o = this.$element.find(".item.active")
                    , r = i || this.getItemForDirection(n, o)
                    , s = this.interval
                    , a = "next" == n ? "left" : "right"
                    , l = this;
                if (r.hasClass("active"))
                    return this.sliding = !1;
                var u = r[0]
                    , c = t.Event("slide.bs.carousel", {
                        relatedTarget: u,
                        direction: a
                    });
                if (this.$element.trigger(c),
                    !c.isDefaultPrevented()) {
                    if (this.sliding = !0,
                        s && this.pause(),
                        this.$indicators.length) {
                        this.$indicators.find(".active").removeClass("active");
                        var d = t(this.$indicators.children()[this.getItemIndex(r)]);
                        d && d.addClass("active")
                    }
                    var p = t.Event("slid.bs.carousel", {
                        relatedTarget: u,
                        direction: a
                    });
                    return t.support.transition && this.$element.hasClass("slide") ? (r.addClass(n),
                        o.addClass(a),
                        r.addClass(a),
                        o.one("bsTransitionEnd", (function () {
                            r.removeClass([n, a].join(" ")).addClass("active"),
                                o.removeClass(["active", a].join(" ")),
                                l.sliding = !1,
                                setTimeout((function () {
                                    l.$element.trigger(p)
                                }
                                ), 0)
                        }
                        )).emulateTransitionEnd(e.TRANSITION_DURATION)) : (o.removeClass("active"),
                            r.addClass("active"),
                            this.sliding = !1,
                            this.$element.trigger(p)),
                        s && this.cycle(),
                        this
                }
            }
            ;
        var i = t.fn.carousel;
        t.fn.carousel = n,
            t.fn.carousel.Constructor = e,
            t.fn.carousel.noConflict = function () {
                return t.fn.carousel = i,
                    this
            }
            ;
        var o = function (e) {
            var i = t(this)
                , o = i.attr("href");
            o && (o = o.replace(/.*(?=#[^\s]+$)/, ""));
            var r = i.attr("data-target") || o
                , s = t(document).find(r);
            if (s.hasClass("carousel")) {
                var a = t.extend({}, s.data(), i.data())
                    , l = i.attr("data-slide-to");
                l && (a.interval = !1),
                    n.call(s, a),
                    l && s.data("bs.carousel").to(l),
                    e.preventDefault()
            }
        };
        t(document).on("click.bs.carousel.data-api", "[data-slide]", o).on("click.bs.carousel.data-api", "[data-slide-to]", o),
            t(window).on("load", (function () {
                t('[data-ride="carousel"]').each((function () {
                    var e = t(this);
                    n.call(e, e.data())
                }
                ))
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (n, i) {
            this.$element = t(n),
                this.options = t.extend({}, e.DEFAULTS, i),
                this.$trigger = t('[data-toggle="collapse"][href="#' + n.id + '"],[data-toggle="collapse"][data-target="#' + n.id + '"]'),
                this.transitioning = null,
                this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger),
                this.options.toggle && this.toggle()
        };
        function n(e) {
            var n, i = e.attr("data-target") || (n = e.attr("href")) && n.replace(/.*(?=#[^\s]+$)/, "");
            return t(document).find(i)
        }
        function i(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.collapse")
                    , r = t.extend({}, e.DEFAULTS, i.data(), "object" == typeof n && n);
                !o && r.toggle && /show|hide/.test(n) && (r.toggle = !1),
                    o || i.data("bs.collapse", o = new e(this, r)),
                    "string" == typeof n && o[n]()
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.TRANSITION_DURATION = 350,
            e.DEFAULTS = {
                toggle: !0
            },
            e.prototype.dimension = function () {
                return this.$element.hasClass("width") ? "width" : "height"
            }
            ,
            e.prototype.show = function () {
                if (!this.transitioning && !this.$element.hasClass("in")) {
                    var n, o = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
                    if (!(o && o.length && (n = o.data("bs.collapse")) && n.transitioning)) {
                        var r = t.Event("show.bs.collapse");
                        if (this.$element.trigger(r),
                            !r.isDefaultPrevented()) {
                            o && o.length && (i.call(o, "hide"),
                                n || o.data("bs.collapse", null));
                            var s = this.dimension();
                            this.$element.removeClass("collapse").addClass("collapsing")[s](0).attr("aria-expanded", !0),
                                this.$trigger.removeClass("collapsed").attr("aria-expanded", !0),
                                this.transitioning = 1;
                            var a = function () {
                                this.$element.removeClass("collapsing").addClass("collapse in")[s](""),
                                    this.transitioning = 0,
                                    this.$element.trigger("shown.bs.collapse")
                            };
                            if (!t.support.transition)
                                return a.call(this);
                            var l = t.camelCase(["scroll", s].join("-"));
                            this.$element.one("bsTransitionEnd", t.proxy(a, this)).emulateTransitionEnd(e.TRANSITION_DURATION)[s](this.$element[0][l])
                        }
                    }
                }
            }
            ,
            e.prototype.hide = function () {
                if (!this.transitioning && this.$element.hasClass("in")) {
                    var n = t.Event("hide.bs.collapse");
                    if (this.$element.trigger(n),
                        !n.isDefaultPrevented()) {
                        var i = this.dimension();
                        this.$element[i](this.$element[i]()),
                            this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1),
                            this.$trigger.addClass("collapsed").attr("aria-expanded", !1),
                            this.transitioning = 1;
                        var o = function () {
                            this.transitioning = 0,
                                this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                        };
                        if (!t.support.transition)
                            return o.call(this);
                        this.$element[i](0).one("bsTransitionEnd", t.proxy(o, this)).emulateTransitionEnd(e.TRANSITION_DURATION)
                    }
                }
            }
            ,
            e.prototype.toggle = function () {
                this[this.$element.hasClass("in") ? "hide" : "show"]()
            }
            ,
            e.prototype.getParent = function () {
                return t(document).find(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(t.proxy((function (e, i) {
                    var o = t(i);
                    this.addAriaAndCollapsedClass(n(o), o)
                }
                ), this)).end()
            }
            ,
            e.prototype.addAriaAndCollapsedClass = function (t, e) {
                var n = t.hasClass("in");
                t.attr("aria-expanded", n),
                    e.toggleClass("collapsed", !n).attr("aria-expanded", n)
            }
            ;
        var o = t.fn.collapse;
        t.fn.collapse = i,
            t.fn.collapse.Constructor = e,
            t.fn.collapse.noConflict = function () {
                return t.fn.collapse = o,
                    this
            }
            ,
            t(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', (function (e) {
                var o = t(this);
                o.attr("data-target") || e.preventDefault();
                var r = n(o)
                    , s = r.data("bs.collapse") ? "toggle" : o.data();
                i.call(r, s)
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = '[data-toggle="dropdown"]'
            , n = function (e) {
                t(e).on("click.bs.dropdown", this.toggle)
            };
        function i(e) {
            var n = e.attr("data-target");
            n || (n = (n = e.attr("href")) && /#[A-Za-z]/.test(n) && n.replace(/.*(?=#[^\s]*$)/, ""));
            var i = "#" !== n ? t(document).find(n) : null;
            return i && i.length ? i : e.parent()
        }
        function o(n) {
            n && 3 === n.which || (t(".dropdown-backdrop").remove(),
                t(e).each((function () {
                    var e = t(this)
                        , o = i(e)
                        , r = {
                            relatedTarget: this
                        };
                    o.hasClass("open") && (n && "click" == n.type && /input|textarea/i.test(n.target.tagName) && t.contains(o[0], n.target) || (o.trigger(n = t.Event("hide.bs.dropdown", r)),
                        n.isDefaultPrevented() || (e.attr("aria-expanded", "false"),
                            o.removeClass("open").trigger(t.Event("hidden.bs.dropdown", r)))))
                }
                )))
        }
        n.VERSION = "3.4.1",
            n.prototype.toggle = function (e) {
                var n = t(this);
                if (!n.is(".disabled, :disabled")) {
                    var r = i(n)
                        , s = r.hasClass("open");
                    if (o(),
                        !s) {
                        "ontouchstart" in document.documentElement && !r.closest(".navbar-nav").length && t(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(t(this)).on("click", o);
                        var a = {
                            relatedTarget: this
                        };
                        if (r.trigger(e = t.Event("show.bs.dropdown", a)),
                            e.isDefaultPrevented())
                            return;
                        n.trigger("focus").attr("aria-expanded", "true"),
                            r.toggleClass("open").trigger(t.Event("shown.bs.dropdown", a))
                    }
                    return !1
                }
            }
            ,
            n.prototype.keydown = function (n) {
                if (/(38|40|27|32)/.test(n.which) && !/input|textarea/i.test(n.target.tagName)) {
                    var o = t(this);
                    if (n.preventDefault(),
                        n.stopPropagation(),
                        !o.is(".disabled, :disabled")) {
                        var r = i(o)
                            , s = r.hasClass("open");
                        if (!s && 27 != n.which || s && 27 == n.which)
                            return 27 == n.which && r.find(e).trigger("focus"),
                                o.trigger("click");
                        var a = r.find(".dropdown-menu li:not(.disabled):visible a");
                        if (a.length) {
                            var l = a.index(n.target);
                            38 == n.which && 0 < l && l--,
                                40 == n.which && l < a.length - 1 && l++,
                                ~l || (l = 0),
                                a.eq(l).trigger("focus")
                        }
                    }
                }
            }
            ;
        var r = t.fn.dropdown;
        t.fn.dropdown = function (e) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.dropdown");
                o || i.data("bs.dropdown", o = new n(this)),
                    "string" == typeof e && o[e].call(i)
            }
            ))
        }
            ,
            t.fn.dropdown.Constructor = n,
            t.fn.dropdown.noConflict = function () {
                return t.fn.dropdown = r,
                    this
            }
            ,
            t(document).on("click.bs.dropdown.data-api", o).on("click.bs.dropdown.data-api", ".dropdown form", (function (t) {
                t.stopPropagation()
            }
            )).on("click.bs.dropdown.data-api", e, n.prototype.toggle).on("keydown.bs.dropdown.data-api", e, n.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", n.prototype.keydown)
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (e, n) {
            this.options = n,
                this.$body = t(document.body),
                this.$element = t(e),
                this.$dialog = this.$element.find(".modal-dialog"),
                this.$backdrop = null,
                this.isShown = null,
                this.originalBodyPad = null,
                this.scrollbarWidth = 0,
                this.ignoreBackdropClick = !1,
                this.fixedContent = ".navbar-fixed-top, .navbar-fixed-bottom",
                this.options.remote && this.$element.find(".modal-content").load(this.options.remote, t.proxy((function () {
                    this.$element.trigger("loaded.bs.modal")
                }
                ), this))
        };
        function n(n, i) {
            return this.each((function () {
                var o = t(this)
                    , r = o.data("bs.modal")
                    , s = t.extend({}, e.DEFAULTS, o.data(), "object" == typeof n && n);
                r || o.data("bs.modal", r = new e(this, s)),
                    "string" == typeof n ? r[n](i) : s.show && r.show(i)
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.TRANSITION_DURATION = 300,
            e.BACKDROP_TRANSITION_DURATION = 150,
            e.DEFAULTS = {
                backdrop: !0,
                keyboard: !0,
                show: !0
            },
            e.prototype.toggle = function (t) {
                return this.isShown ? this.hide() : this.show(t)
            }
            ,
            e.prototype.show = function (n) {
                var i = this
                    , o = t.Event("show.bs.modal", {
                        relatedTarget: n
                    });
                this.$element.trigger(o),
                    this.isShown || o.isDefaultPrevented() || (this.isShown = !0,
                        this.checkScrollbar(),
                        this.setScrollbar(),
                        this.$body.addClass("modal-open"),
                        this.escape(),
                        this.resize(),
                        this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', t.proxy(this.hide, this)),
                        this.$dialog.on("mousedown.dismiss.bs.modal", (function () {
                            i.$element.one("mouseup.dismiss.bs.modal", (function (e) {
                                t(e.target).is(i.$element) && (i.ignoreBackdropClick = !0)
                            }
                            ))
                        }
                        )),
                        this.backdrop((function () {
                            var o = t.support.transition && i.$element.hasClass("fade");
                            i.$element.parent().length || i.$element.appendTo(i.$body),
                                i.$element.show().scrollTop(0),
                                i.adjustDialog(),
                                i.$element.addClass("in"),
                                i.enforceFocus();
                            var r = t.Event("shown.bs.modal", {
                                relatedTarget: n
                            });
                            o ? i.$dialog.one("bsTransitionEnd", (function () {
                                i.$element.trigger("focus").trigger(r)
                            }
                            )).emulateTransitionEnd(e.TRANSITION_DURATION) : i.$element.trigger("focus").trigger(r)
                        }
                        )))
            }
            ,
            e.prototype.hide = function (n) {
                n && n.preventDefault(),
                    n = t.Event("hide.bs.modal"),
                    this.$element.trigger(n),
                    this.isShown && !n.isDefaultPrevented() && (this.isShown = !1,
                        this.escape(),
                        this.resize(),
                        t(document).off("focusin.bs.modal"),
                        this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),
                        this.$dialog.off("mousedown.dismiss.bs.modal"),
                        t.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", t.proxy(this.hideModal, this)).emulateTransitionEnd(e.TRANSITION_DURATION) : this.hideModal())
            }
            ,
            e.prototype.enforceFocus = function () {
                t(document).off("focusin.bs.modal").on("focusin.bs.modal", t.proxy((function (t) {
                    document === t.target || this.$element[0] === t.target || this.$element.has(t.target).length || this.$element.trigger("focus")
                }
                ), this))
            }
            ,
            e.prototype.escape = function () {
                this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", t.proxy((function (t) {
                    27 == t.which && this.hide()
                }
                ), this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
            }
            ,
            e.prototype.resize = function () {
                this.isShown ? t(window).on("resize.bs.modal", t.proxy(this.handleUpdate, this)) : t(window).off("resize.bs.modal")
            }
            ,
            e.prototype.hideModal = function () {
                var t = this;
                this.$element.hide(),
                    this.backdrop((function () {
                        t.$body.removeClass("modal-open"),
                            t.resetAdjustments(),
                            t.resetScrollbar(),
                            t.$element.trigger("hidden.bs.modal")
                    }
                    ))
            }
            ,
            e.prototype.removeBackdrop = function () {
                this.$backdrop && this.$backdrop.remove(),
                    this.$backdrop = null
            }
            ,
            e.prototype.backdrop = function (n) {
                var i = this
                    , o = this.$element.hasClass("fade") ? "fade" : "";
                if (this.isShown && this.options.backdrop) {
                    var r = t.support.transition && o;
                    if (this.$backdrop = t(document.createElement("div")).addClass("modal-backdrop " + o).appendTo(this.$body),
                        this.$element.on("click.dismiss.bs.modal", t.proxy((function (t) {
                            this.ignoreBackdropClick ? this.ignoreBackdropClick = !1 : t.target === t.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide())
                        }
                        ), this)),
                        this.$backdrop.addClass("in"),
                        !n)
                        return;
                    r ? this.$backdrop.one("bsTransitionEnd", n).emulateTransitionEnd(e.BACKDROP_TRANSITION_DURATION) : n()
                } else if (!this.isShown && this.$backdrop) {
                    this.$backdrop.removeClass("in");
                    var s = function () {
                        i.removeBackdrop(),
                            n && n()
                    };
                    t.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", s).emulateTransitionEnd(e.BACKDROP_TRANSITION_DURATION) : s()
                } else
                    n && n()
            }
            ,
            e.prototype.handleUpdate = function () {
                this.adjustDialog()
            }
            ,
            e.prototype.adjustDialog = function () {
                var t = this.$element[0].scrollHeight > document.documentElement.clientHeight;
                this.$element.css({
                    paddingLeft: !this.bodyIsOverflowing && t ? this.scrollbarWidth : "",
                    paddingRight: this.bodyIsOverflowing && !t ? this.scrollbarWidth : ""
                })
            }
            ,
            e.prototype.resetAdjustments = function () {
                this.$element.css({
                    paddingLeft: "",
                    paddingRight: ""
                })
            }
            ,
            e.prototype.checkScrollbar = function () {
                var t = window.innerWidth;
                if (!t) {
                    var e = document.documentElement.getBoundingClientRect();
                    t = e.right - Math.abs(e.left)
                }
                this.bodyIsOverflowing = document.body.clientWidth < t,
                    this.scrollbarWidth = this.measureScrollbar()
            }
            ,
            e.prototype.setScrollbar = function () {
                var e = parseInt(this.$body.css("padding-right") || 0, 10);
                this.originalBodyPad = document.body.style.paddingRight || "";
                var n = this.scrollbarWidth;
                this.bodyIsOverflowing && (this.$body.css("padding-right", e + n),
                    t(this.fixedContent).each((function (e, i) {
                        var o = i.style.paddingRight
                            , r = t(i).css("padding-right");
                        t(i).data("padding-right", o).css("padding-right", parseFloat(r) + n + "px")
                    }
                    )))
            }
            ,
            e.prototype.resetScrollbar = function () {
                this.$body.css("padding-right", this.originalBodyPad),
                    t(this.fixedContent).each((function (e, n) {
                        var i = t(n).data("padding-right");
                        t(n).removeData("padding-right"),
                            n.style.paddingRight = i || ""
                    }
                    ))
            }
            ,
            e.prototype.measureScrollbar = function () {
                var t = document.createElement("div");
                t.className = "modal-scrollbar-measure",
                    this.$body.append(t);
                var e = t.offsetWidth - t.clientWidth;
                return this.$body[0].removeChild(t),
                    e
            }
            ;
        var i = t.fn.modal;
        t.fn.modal = n,
            t.fn.modal.Constructor = e,
            t.fn.modal.noConflict = function () {
                return t.fn.modal = i,
                    this
            }
            ,
            t(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', (function (e) {
                var i = t(this)
                    , o = i.attr("href")
                    , r = i.attr("data-target") || o && o.replace(/.*(?=#[^\s]+$)/, "")
                    , s = t(document).find(r)
                    , a = s.data("bs.modal") ? "toggle" : t.extend({
                        remote: !/#/.test(o) && o
                    }, s.data(), i.data());
                i.is("a") && e.preventDefault(),
                    s.one("show.bs.modal", (function (t) {
                        t.isDefaultPrevented() || s.one("hidden.bs.modal", (function () {
                            i.is(":visible") && i.trigger("focus")
                        }
                        ))
                    }
                    )),
                    n.call(s, a, this)
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = ["sanitize", "whiteList", "sanitizeFn"]
            , n = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]
            , i = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi
            , o = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;
        function r(e, r) {
            var s = e.nodeName.toLowerCase();
            if (-1 !== t.inArray(s, r))
                return -1 === t.inArray(s, n) || Boolean(e.nodeValue.match(i) || e.nodeValue.match(o));
            for (var a = t(r).filter((function (t, e) {
                return e instanceof RegExp
            }
            )), l = 0, u = a.length; l < u; l++)
                if (s.match(a[l]))
                    return !0;
            return !1
        }
        function s(e, n, i) {
            if (0 === e.length)
                return e;
            if (i && "function" == typeof i)
                return i(e);
            if (!document.implementation || !document.implementation.createHTMLDocument)
                return e;
            var o = document.implementation.createHTMLDocument("sanitization");
            o.body.innerHTML = e;
            for (var s = t.map(n, (function (t, e) {
                return e
            }
            )), a = t(o.body).find("*"), l = 0, u = a.length; l < u; l++) {
                var c = a[l]
                    , d = c.nodeName.toLowerCase();
                if (-1 !== t.inArray(d, s))
                    for (var p = t.map(c.attributes, (function (t) {
                        return t
                    }
                    )), f = [].concat(n["*"] || [], n[d] || []), h = 0, g = p.length; h < g; h++)
                        r(p[h], f) || c.removeAttribute(p[h].nodeName);
                else
                    c.parentNode.removeChild(c)
            }
            return o.body.innerHTML
        }
        var a = function (t, e) {
            this.type = null,
                this.options = null,
                this.enabled = null,
                this.timeout = null,
                this.hoverState = null,
                this.$element = null,
                this.inState = null,
                this.init("tooltip", t, e)
        };
        a.VERSION = "3.4.1",
            a.TRANSITION_DURATION = 150,
            a.DEFAULTS = {
                animation: !0,
                placement: "top",
                selector: !1,
                template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
                trigger: "hover focus",
                title: "",
                delay: 0,
                html: !1,
                container: !1,
                viewport: {
                    selector: "body",
                    padding: 0
                },
                sanitize: !0,
                sanitizeFn: null,
                whiteList: {
                    "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
                    a: ["target", "href", "title", "rel"],
                    area: [],
                    b: [],
                    br: [],
                    col: [],
                    code: [],
                    div: [],
                    em: [],
                    hr: [],
                    h1: [],
                    h2: [],
                    h3: [],
                    h4: [],
                    h5: [],
                    h6: [],
                    i: [],
                    img: ["src", "alt", "title", "width", "height"],
                    li: [],
                    ol: [],
                    p: [],
                    pre: [],
                    s: [],
                    small: [],
                    span: [],
                    sub: [],
                    sup: [],
                    strong: [],
                    u: [],
                    ul: []
                }
            },
            a.prototype.init = function (e, n, i) {
                if (this.enabled = !0,
                    this.type = e,
                    this.$element = t(n),
                    this.options = this.getOptions(i),
                    this.$viewport = this.options.viewport && t(document).find(t.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : this.options.viewport.selector || this.options.viewport),
                    this.inState = {
                        click: !1,
                        hover: !1,
                        focus: !1
                    },
                    this.$element[0] instanceof document.constructor && !this.options.selector)
                    throw new Error("`selector` option must be specified when initializing " + this.type + " on the window.document object!");
                for (var o = this.options.trigger.split(" "), r = o.length; r--;) {
                    var s = o[r];
                    if ("click" == s)
                        this.$element.on("click." + this.type, this.options.selector, t.proxy(this.toggle, this));
                    else if ("manual" != s) {
                        var a = "hover" == s ? "mouseleave" : "focusout";
                        this.$element.on(("hover" == s ? "mouseenter" : "focusin") + "." + this.type, this.options.selector, t.proxy(this.enter, this)),
                            this.$element.on(a + "." + this.type, this.options.selector, t.proxy(this.leave, this))
                    }
                }
                this.options.selector ? this._options = t.extend({}, this.options, {
                    trigger: "manual",
                    selector: ""
                }) : this.fixTitle()
            }
            ,
            a.prototype.getDefaults = function () {
                return a.DEFAULTS
            }
            ,
            a.prototype.getOptions = function (n) {
                var i = this.$element.data();
                for (var o in i)
                    i.hasOwnProperty(o) && -1 !== t.inArray(o, e) && delete i[o];
                return (n = t.extend({}, this.getDefaults(), i, n)).delay && "number" == typeof n.delay && (n.delay = {
                    show: n.delay,
                    hide: n.delay
                }),
                    n.sanitize && (n.template = s(n.template, n.whiteList, n.sanitizeFn)),
                    n
            }
            ,
            a.prototype.getDelegateOptions = function () {
                var e = {}
                    , n = this.getDefaults();
                return this._options && t.each(this._options, (function (t, i) {
                    n[t] != i && (e[t] = i)
                }
                )),
                    e
            }
            ,
            a.prototype.enter = function (e) {
                var n = e instanceof this.constructor ? e : t(e.currentTarget).data("bs." + this.type);
                if (n || (n = new this.constructor(e.currentTarget, this.getDelegateOptions()),
                    t(e.currentTarget).data("bs." + this.type, n)),
                    e instanceof t.Event && (n.inState["focusin" == e.type ? "focus" : "hover"] = !0),
                    n.tip().hasClass("in") || "in" == n.hoverState)
                    n.hoverState = "in";
                else {
                    if (clearTimeout(n.timeout),
                        n.hoverState = "in",
                        !n.options.delay || !n.options.delay.show)
                        return n.show();
                    n.timeout = setTimeout((function () {
                        "in" == n.hoverState && n.show()
                    }
                    ), n.options.delay.show)
                }
            }
            ,
            a.prototype.isInStateTrue = function () {
                for (var t in this.inState)
                    if (this.inState[t])
                        return !0;
                return !1
            }
            ,
            a.prototype.leave = function (e) {
                var n = e instanceof this.constructor ? e : t(e.currentTarget).data("bs." + this.type);
                if (n || (n = new this.constructor(e.currentTarget, this.getDelegateOptions()),
                    t(e.currentTarget).data("bs." + this.type, n)),
                    e instanceof t.Event && (n.inState["focusout" == e.type ? "focus" : "hover"] = !1),
                    !n.isInStateTrue()) {
                    if (clearTimeout(n.timeout),
                        n.hoverState = "out",
                        !n.options.delay || !n.options.delay.hide)
                        return n.hide();
                    n.timeout = setTimeout((function () {
                        "out" == n.hoverState && n.hide()
                    }
                    ), n.options.delay.hide)
                }
            }
            ,
            a.prototype.show = function () {
                var e = t.Event("show.bs." + this.type);
                if (this.hasContent() && this.enabled) {
                    this.$element.trigger(e);
                    var n = t.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]);
                    if (e.isDefaultPrevented() || !n)
                        return;
                    var i = this
                        , o = this.tip()
                        , r = this.getUID(this.type);
                    this.setContent(),
                        o.attr("id", r),
                        this.$element.attr("aria-describedby", r),
                        this.options.animation && o.addClass("fade");
                    var s = "function" == typeof this.options.placement ? this.options.placement.call(this, o[0], this.$element[0]) : this.options.placement
                        , l = /\s?auto?\s?/i
                        , u = l.test(s);
                    u && (s = s.replace(l, "") || "top"),
                        o.detach().css({
                            top: 0,
                            left: 0,
                            display: "block"
                        }).addClass(s).data("bs." + this.type, this),
                        this.options.container ? o.appendTo(t(document).find(this.options.container)) : o.insertAfter(this.$element),
                        this.$element.trigger("inserted.bs." + this.type);
                    var c = this.getPosition()
                        , d = o[0].offsetWidth
                        , p = o[0].offsetHeight;
                    if (u) {
                        var f = s
                            , h = this.getPosition(this.$viewport);
                        s = "bottom" == s && c.bottom + p > h.bottom ? "top" : "top" == s && c.top - p < h.top ? "bottom" : "right" == s && c.right + d > h.width ? "left" : "left" == s && c.left - d < h.left ? "right" : s,
                            o.removeClass(f).addClass(s)
                    }
                    var g = this.getCalculatedOffset(s, c, d, p);
                    this.applyPlacement(g, s);
                    var m = function () {
                        var t = i.hoverState;
                        i.$element.trigger("shown.bs." + i.type),
                            i.hoverState = null,
                            "out" == t && i.leave(i)
                    };
                    t.support.transition && this.$tip.hasClass("fade") ? o.one("bsTransitionEnd", m).emulateTransitionEnd(a.TRANSITION_DURATION) : m()
                }
            }
            ,
            a.prototype.applyPlacement = function (e, n) {
                var i = this.tip()
                    , o = i[0].offsetWidth
                    , r = i[0].offsetHeight
                    , s = parseInt(i.css("margin-top"), 10)
                    , a = parseInt(i.css("margin-left"), 10);
                isNaN(s) && (s = 0),
                    isNaN(a) && (a = 0),
                    e.top += s,
                    e.left += a,
                    t.offset.setOffset(i[0], t.extend({
                        using: function (t) {
                            i.css({
                                top: Math.round(t.top),
                                left: Math.round(t.left)
                            })
                        }
                    }, e), 0),
                    i.addClass("in");
                var l = i[0].offsetWidth
                    , u = i[0].offsetHeight;
                "top" == n && u != r && (e.top = e.top + r - u);
                var c = this.getViewportAdjustedDelta(n, e, l, u);
                c.left ? e.left += c.left : e.top += c.top;
                var d = /top|bottom/.test(n)
                    , p = d ? 2 * c.left - o + l : 2 * c.top - r + u
                    , f = d ? "offsetWidth" : "offsetHeight";
                i.offset(e),
                    this.replaceArrow(p, i[0][f], d)
            }
            ,
            a.prototype.replaceArrow = function (t, e, n) {
                this.arrow().css(n ? "left" : "top", 50 * (1 - t / e) + "%").css(n ? "top" : "left", "")
            }
            ,
            a.prototype.setContent = function () {
                var t = this.tip()
                    , e = this.getTitle();
                this.options.html ? (this.options.sanitize && (e = s(e, this.options.whiteList, this.options.sanitizeFn)),
                    t.find(".tooltip-inner").html(e)) : t.find(".tooltip-inner").text(e),
                    t.removeClass("fade in top bottom left right")
            }
            ,
            a.prototype.hide = function (e) {
                var n = this
                    , i = t(this.$tip)
                    , o = t.Event("hide.bs." + this.type);
                function r() {
                    "in" != n.hoverState && i.detach(),
                        n.$element && n.$element.removeAttr("aria-describedby").trigger("hidden.bs." + n.type),
                        e && e()
                }
                if (this.$element.trigger(o),
                    !o.isDefaultPrevented())
                    return i.removeClass("in"),
                        t.support.transition && i.hasClass("fade") ? i.one("bsTransitionEnd", r).emulateTransitionEnd(a.TRANSITION_DURATION) : r(),
                        this.hoverState = null,
                        this
            }
            ,
            a.prototype.fixTitle = function () {
                var t = this.$element;
                (t.attr("title") || "string" != typeof t.attr("data-original-title")) && t.attr("data-original-title", t.attr("title") || "").attr("title", "")
            }
            ,
            a.prototype.hasContent = function () {
                return this.getTitle()
            }
            ,
            a.prototype.getPosition = function (e) {
                var n = (e = e || this.$element)[0]
                    , i = "BODY" == n.tagName
                    , o = n.getBoundingClientRect();
                null == o.width && (o = t.extend({}, o, {
                    width: o.right - o.left,
                    height: o.bottom - o.top
                }));
                var r = window.SVGElement && n instanceof window.SVGElement
                    , s = i ? {
                        top: 0,
                        left: 0
                    } : r ? null : e.offset()
                    , a = {
                        scroll: i ? document.documentElement.scrollTop || document.body.scrollTop : e.scrollTop()
                    }
                    , l = i ? {
                        width: t(window).width(),
                        height: t(window).height()
                    } : null;
                return t.extend({}, o, a, l, s)
            }
            ,
            a.prototype.getCalculatedOffset = function (t, e, n, i) {
                return "bottom" == t ? {
                    top: e.top + e.height,
                    left: e.left + e.width / 2 - n / 2
                } : "top" == t ? {
                    top: e.top - i,
                    left: e.left + e.width / 2 - n / 2
                } : "left" == t ? {
                    top: e.top + e.height / 2 - i / 2,
                    left: e.left - n
                } : {
                    top: e.top + e.height / 2 - i / 2,
                    left: e.left + e.width
                }
            }
            ,
            a.prototype.getViewportAdjustedDelta = function (t, e, n, i) {
                var o = {
                    top: 0,
                    left: 0
                };
                if (!this.$viewport)
                    return o;
                var r = this.options.viewport && this.options.viewport.padding || 0
                    , s = this.getPosition(this.$viewport);
                if (/right|left/.test(t)) {
                    var a = e.top - r - s.scroll
                        , l = e.top + r - s.scroll + i;
                    a < s.top ? o.top = s.top - a : l > s.top + s.height && (o.top = s.top + s.height - l)
                } else {
                    var u = e.left - r
                        , c = e.left + r + n;
                    u < s.left ? o.left = s.left - u : c > s.right && (o.left = s.left + s.width - c)
                }
                return o
            }
            ,
            a.prototype.getTitle = function () {
                var t = this.$element
                    , e = this.options;
                return t.attr("data-original-title") || ("function" == typeof e.title ? e.title.call(t[0]) : e.title)
            }
            ,
            a.prototype.getUID = function (t) {
                for (; t += ~~(1e6 * Math.random()),
                    document.getElementById(t);)
                    ;
                return t
            }
            ,
            a.prototype.tip = function () {
                if (!this.$tip && (this.$tip = t(this.options.template),
                    1 != this.$tip.length))
                    throw new Error(this.type + " `template` option must consist of exactly 1 top-level element!");
                return this.$tip
            }
            ,
            a.prototype.arrow = function () {
                return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
            }
            ,
            a.prototype.enable = function () {
                this.enabled = !0
            }
            ,
            a.prototype.disable = function () {
                this.enabled = !1
            }
            ,
            a.prototype.toggleEnabled = function () {
                this.enabled = !this.enabled
            }
            ,
            a.prototype.toggle = function (e) {
                var n = this;
                e && ((n = t(e.currentTarget).data("bs." + this.type)) || (n = new this.constructor(e.currentTarget, this.getDelegateOptions()),
                    t(e.currentTarget).data("bs." + this.type, n))),
                    e ? (n.inState.click = !n.inState.click,
                        n.isInStateTrue() ? n.enter(n) : n.leave(n)) : n.tip().hasClass("in") ? n.leave(n) : n.enter(n)
            }
            ,
            a.prototype.destroy = function () {
                var t = this;
                clearTimeout(this.timeout),
                    this.hide((function () {
                        t.$element.off("." + t.type).removeData("bs." + t.type),
                            t.$tip && t.$tip.detach(),
                            t.$tip = null,
                            t.$arrow = null,
                            t.$viewport = null,
                            t.$element = null
                    }
                    ))
            }
            ,
            a.prototype.sanitizeHtml = function (t) {
                return s(t, this.options.whiteList, this.options.sanitizeFn)
            }
            ;
        var l = t.fn.tooltip;
        t.fn.tooltip = function (e) {
            return this.each((function () {
                var n = t(this)
                    , i = n.data("bs.tooltip")
                    , o = "object" == typeof e && e;
                !i && /destroy|hide/.test(e) || (i || n.data("bs.tooltip", i = new a(this, o)),
                    "string" == typeof e && i[e]())
            }
            ))
        }
            ,
            t.fn.tooltip.Constructor = a,
            t.fn.tooltip.noConflict = function () {
                return t.fn.tooltip = l,
                    this
            }
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (t, e) {
            this.init("popover", t, e)
        };
        if (!t.fn.tooltip)
            throw new Error("Popover requires tooltip.js");
        e.VERSION = "3.4.1",
            e.DEFAULTS = t.extend({}, t.fn.tooltip.Constructor.DEFAULTS, {
                placement: "right",
                trigger: "click",
                content: "",
                template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
            }),
            ((e.prototype = t.extend({}, t.fn.tooltip.Constructor.prototype)).constructor = e).prototype.getDefaults = function () {
                return e.DEFAULTS
            }
            ,
            e.prototype.setContent = function () {
                var t = this.tip()
                    , e = this.getTitle()
                    , n = this.getContent();
                if (this.options.html) {
                    var i = typeof n;
                    this.options.sanitize && (e = this.sanitizeHtml(e),
                        "string" === i && (n = this.sanitizeHtml(n))),
                        t.find(".popover-title").html(e),
                        t.find(".popover-content").children().detach().end()["string" === i ? "html" : "append"](n)
                } else
                    t.find(".popover-title").text(e),
                        t.find(".popover-content").children().detach().end().text(n);
                t.removeClass("fade top bottom left right in"),
                    t.find(".popover-title").html() || t.find(".popover-title").hide()
            }
            ,
            e.prototype.hasContent = function () {
                return this.getTitle() || this.getContent()
            }
            ,
            e.prototype.getContent = function () {
                var t = this.$element
                    , e = this.options;
                return t.attr("data-content") || ("function" == typeof e.content ? e.content.call(t[0]) : e.content)
            }
            ,
            e.prototype.arrow = function () {
                return this.$arrow = this.$arrow || this.tip().find(".arrow")
            }
            ;
        var n = t.fn.popover;
        t.fn.popover = function (n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.popover")
                    , r = "object" == typeof n && n;
                !o && /destroy|hide/.test(n) || (o || i.data("bs.popover", o = new e(this, r)),
                    "string" == typeof n && o[n]())
            }
            ))
        }
            ,
            t.fn.popover.Constructor = e,
            t.fn.popover.noConflict = function () {
                return t.fn.popover = n,
                    this
            }
    }(jQuery),
    function (t) {
        "use strict";
        function e(n, i) {
            this.$body = t(document.body),
                this.$scrollElement = t(n).is(document.body) ? t(window) : t(n),
                this.options = t.extend({}, e.DEFAULTS, i),
                this.selector = (this.options.target || "") + " .nav li > a",
                this.offsets = [],
                this.targets = [],
                this.activeTarget = null,
                this.scrollHeight = 0,
                this.$scrollElement.on("scroll.bs.scrollspy", t.proxy(this.process, this)),
                this.refresh(),
                this.process()
        }
        function n(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.scrollspy");
                o || i.data("bs.scrollspy", o = new e(this, "object" == typeof n && n)),
                    "string" == typeof n && o[n]()
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.DEFAULTS = {
                offset: 10
            },
            e.prototype.getScrollHeight = function () {
                return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
            }
            ,
            e.prototype.refresh = function () {
                var e = this
                    , n = "offset"
                    , i = 0;
                this.offsets = [],
                    this.targets = [],
                    this.scrollHeight = this.getScrollHeight(),
                    t.isWindow(this.$scrollElement[0]) || (n = "position",
                        i = this.$scrollElement.scrollTop()),
                    this.$body.find(this.selector).map((function () {
                        var e = t(this)
                            , o = e.data("target") || e.attr("href")
                            , r = /^#./.test(o) && t(o);
                        return r && r.length && r.is(":visible") && [[r[n]().top + i, o]] || null
                    }
                    )).sort((function (t, e) {
                        return t[0] - e[0]
                    }
                    )).each((function () {
                        e.offsets.push(this[0]),
                            e.targets.push(this[1])
                    }
                    ))
            }
            ,
            e.prototype.process = function () {
                var t, e = this.$scrollElement.scrollTop() + this.options.offset, n = this.getScrollHeight(), i = this.options.offset + n - this.$scrollElement.height(), o = this.offsets, r = this.targets, s = this.activeTarget;
                if (this.scrollHeight != n && this.refresh(),
                    i <= e)
                    return s != (t = r[r.length - 1]) && this.activate(t);
                if (s && e < o[0])
                    return this.activeTarget = null,
                        this.clear();
                for (t = o.length; t--;)
                    s != r[t] && e >= o[t] && (void 0 === o[t + 1] || e < o[t + 1]) && this.activate(r[t])
            }
            ,
            e.prototype.activate = function (e) {
                this.activeTarget = e,
                    this.clear();
                var n = t(this.selector + '[data-target="' + e + '"],' + this.selector + '[href="' + e + '"]').parents("li").addClass("active");
                n.parent(".dropdown-menu").length && (n = n.closest("li.dropdown").addClass("active")),
                    n.trigger("activate.bs.scrollspy")
            }
            ,
            e.prototype.clear = function () {
                t(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
            }
            ;
        var i = t.fn.scrollspy;
        t.fn.scrollspy = n,
            t.fn.scrollspy.Constructor = e,
            t.fn.scrollspy.noConflict = function () {
                return t.fn.scrollspy = i,
                    this
            }
            ,
            t(window).on("load.bs.scrollspy.data-api", (function () {
                t('[data-spy="scroll"]').each((function () {
                    var e = t(this);
                    n.call(e, e.data())
                }
                ))
            }
            ))
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (e) {
            this.element = t(e)
        };
        function n(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.tab");
                o || i.data("bs.tab", o = new e(this)),
                    "string" == typeof n && o[n]()
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.TRANSITION_DURATION = 150,
            e.prototype.show = function () {
                var e = this.element
                    , n = e.closest("ul:not(.dropdown-menu)")
                    , i = e.data("target");
                if (i || (i = (i = e.attr("href")) && i.replace(/.*(?=#[^\s]*$)/, "")),
                    !e.parent("li").hasClass("active")) {
                    var o = n.find(".active:last a")
                        , r = t.Event("hide.bs.tab", {
                            relatedTarget: e[0]
                        })
                        , s = t.Event("show.bs.tab", {
                            relatedTarget: o[0]
                        });
                    if (o.trigger(r),
                        e.trigger(s),
                        !s.isDefaultPrevented() && !r.isDefaultPrevented()) {
                        var a = t(document).find(i);
                        this.activate(e.closest("li"), n),
                            this.activate(a, a.parent(), (function () {
                                o.trigger({
                                    type: "hidden.bs.tab",
                                    relatedTarget: e[0]
                                }),
                                    e.trigger({
                                        type: "shown.bs.tab",
                                        relatedTarget: o[0]
                                    })
                            }
                            ))
                    }
                }
            }
            ,
            e.prototype.activate = function (n, i, o) {
                var r = i.find("> .active")
                    , s = o && t.support.transition && (r.length && r.hasClass("fade") || !!i.find("> .fade").length);
                function a() {
                    r.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1),
                        n.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0),
                        s ? n.addClass("in") : n.removeClass("fade"),
                        n.parent(".dropdown-menu").length && n.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0),
                        o && o()
                }
                r.length && s ? r.one("bsTransitionEnd", a).emulateTransitionEnd(e.TRANSITION_DURATION) : a(),
                    r.removeClass("in")
            }
            ;
        var i = t.fn.tab;
        t.fn.tab = n,
            t.fn.tab.Constructor = e,
            t.fn.tab.noConflict = function () {
                return t.fn.tab = i,
                    this
            }
            ;
        var o = function (e) {
            e.preventDefault(),
                n.call(t(this), "show")
        };
        t(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', o).on("click.bs.tab.data-api", '[data-toggle="pill"]', o)
    }(jQuery),
    function (t) {
        "use strict";
        var e = function (n, i) {
            this.options = t.extend({}, e.DEFAULTS, i);
            var o = this.options.target === e.DEFAULTS.target ? t(this.options.target) : t(document).find(this.options.target);
            this.$target = o.on("scroll.bs.affix.data-api", t.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", t.proxy(this.checkPositionWithEventLoop, this)),
                this.$element = t(n),
                this.affixed = null,
                this.unpin = null,
                this.pinnedOffset = null,
                this.checkPosition()
        };
        function n(n) {
            return this.each((function () {
                var i = t(this)
                    , o = i.data("bs.affix");
                o || i.data("bs.affix", o = new e(this, "object" == typeof n && n)),
                    "string" == typeof n && o[n]()
            }
            ))
        }
        e.VERSION = "3.4.1",
            e.RESET = "affix affix-top affix-bottom",
            e.DEFAULTS = {
                offset: 0,
                target: window
            },
            e.prototype.getState = function (t, e, n, i) {
                var o = this.$target.scrollTop()
                    , r = this.$element.offset()
                    , s = this.$target.height();
                if (null != n && "top" == this.affixed)
                    return o < n && "top";
                if ("bottom" == this.affixed)
                    return null != n ? !(o + this.unpin <= r.top) && "bottom" : !(o + s <= t - i) && "bottom";
                var a = null == this.affixed;
                return null != n && o <= n ? "top" : null != i && t - i <= (a ? o : r.top) + (a ? s : e) && "bottom"
            }
            ,
            e.prototype.getPinnedOffset = function () {
                if (this.pinnedOffset)
                    return this.pinnedOffset;
                this.$element.removeClass(e.RESET).addClass("affix");
                var t = this.$target.scrollTop()
                    , n = this.$element.offset();
                return this.pinnedOffset = n.top - t
            }
            ,
            e.prototype.checkPositionWithEventLoop = function () {
                setTimeout(t.proxy(this.checkPosition, this), 1)
            }
            ,
            e.prototype.checkPosition = function () {
                if (this.$element.is(":visible")) {
                    var n = this.$element.height()
                        , i = this.options.offset
                        , o = i.top
                        , r = i.bottom
                        , s = Math.max(t(document).height(), t(document.body).height());
                    "object" != typeof i && (r = o = i),
                        "function" == typeof o && (o = i.top(this.$element)),
                        "function" == typeof r && (r = i.bottom(this.$element));
                    var a = this.getState(s, n, o, r);
                    if (this.affixed != a) {
                        null != this.unpin && this.$element.css("top", "");
                        var l = "affix" + (a ? "-" + a : "")
                            , u = t.Event(l + ".bs.affix");
                        if (this.$element.trigger(u),
                            u.isDefaultPrevented())
                            return;
                        this.affixed = a,
                            this.unpin = "bottom" == a ? this.getPinnedOffset() : null,
                            this.$element.removeClass(e.RESET).addClass(l).trigger(l.replace("affix", "affixed") + ".bs.affix")
                    }
                    "bottom" == a && this.$element.offset({
                        top: s - n - r
                    })
                }
            }
            ;
        var i = t.fn.affix;
        t.fn.affix = n,
            t.fn.affix.Constructor = e,
            t.fn.affix.noConflict = function () {
                return t.fn.affix = i,
                    this
            }
            ,
            t(window).on("load", (function () {
                t('[data-spy="affix"]').each((function () {
                    var e = t(this)
                        , i = e.data();
                    i.offset = i.offset || {},
                        null != i.offsetBottom && (i.offset.bottom = i.offsetBottom),
                        null != i.offsetTop && (i.offset.top = i.offsetTop),
                        n.call(e, i)
                }
                ))
            }
            ))
    }(jQuery);
