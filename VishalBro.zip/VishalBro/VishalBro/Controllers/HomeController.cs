﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using VishalBro.Models;

namespace VishalBro.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult DashBoard()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Client()
        {
            return View();
        }
        public IActionResult Currentsportdetails()
        {
            return View();
        }
        public IActionResult SportsDetails()
        {
            return View();
        }
        public IActionResult MyLedger()
        {
            return View();
        }
        public IActionResult AgentLedger()
        {
            return View();
        }
        public IActionResult Commissionlenadena()
        {
            return View();
        }
        public IActionResult TotalProfit()
        {
            return View();
        }
        public IActionResult AllClientsReport()
        {
            return View();
        }
        public IActionResult DebitClient()
        {
            return View();
        }
        public IActionResult ChangePassword()
        {
            return View();
        }
        public IActionResult CreateUser()
        {
            return View();
        }
        public IActionResult UpdateLimit()
        {
            return View();
        }
    }
}
