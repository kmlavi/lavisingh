﻿using Microsoft.AspNetCore.Identity;

namespace VishalBro.Models.DataBase
{
    public class AppUser : IdentityUser
    {
        public string Name
        {
            get;
            set;
        }
    }
}
