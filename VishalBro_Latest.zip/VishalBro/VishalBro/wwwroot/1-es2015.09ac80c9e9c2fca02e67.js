﻿(window.webpackJsonp = window.webpackJsonp || []).push([[1], {
    "3Pt+": function (t, e, n) {
        "use strict";
        var r = n("fXoL")
            , i = n("ofXK")
            , o = n("HDdC")
            , s = n("DH7j")
            , a = n("lJxs")
            , l = n("XoHu")
            , c = n("Cfvw");
        function h(t, e) {
            return new o.a(n => {
                const r = t.length;
                if (0 === r)
                    return void n.complete();
                const i = new Array(r);
                let o = 0
                    , s = 0;
                for (let a = 0; a < r; a++) {
                    const l = Object(c.a)(t[a]);
                    let h = !1;
                    n.add(l.subscribe({
                        next: t => {
                            h || (h = !0,
                                s++),
                                i[a] = t
                        }
                        ,
                        error: t => n.error(t),
                        complete: () => {
                            o++,
                                o !== r && h || (s === r && n.next(e ? e.reduce((t, e, n) => (t[e] = i[n],
                                    t), {}) : i),
                                    n.complete())
                        }
                    }))
                }
            }
            )
        }
        n.d(e, "a", (function () {
            return f
        }
        )),
            n.d(e, "b", (function () {
                return Ut
            }
            )),
            n.d(e, "c", (function () {
                return Ht
            }
            )),
            n.d(e, "d", (function () {
                return vt
            }
            )),
            n.d(e, "e", (function () {
                return kt
            }
            )),
            n.d(e, "f", (function () {
                return Yt
            }
            )),
            n.d(e, "g", (function () {
                return Rt
            }
            )),
            n.d(e, "h", (function () {
                return Gt
            }
            )),
            n.d(e, "i", (function () {
                return zt
            }
            )),
            n.d(e, "j", (function () {
                return E
            }
            )),
            n.d(e, "k", (function () {
                return u
            }
            )),
            n.d(e, "l", (function () {
                return w
            }
            )),
            n.d(e, "m", (function () {
                return O
            }
            )),
            n.d(e, "n", (function () {
                return wt
            }
            )),
            n.d(e, "o", (function () {
                return Dt
            }
            )),
            n.d(e, "p", (function () {
                return z
            }
            )),
            n.d(e, "q", (function () {
                return F
            }
            )),
            n.d(e, "r", (function () {
                return G
            }
            )),
            n.d(e, "s", (function () {
                return Jt
            }
            )),
            n.d(e, "t", (function () {
                return qt
            }
            )),
            n.d(e, "u", (function () {
                return H
            }
            )),
            n.d(e, "v", (function () {
                return j
            }
            )),
            n.d(e, "w", (function () {
                return K
            }
            )),
            n.d(e, "x", (function () {
                return Pt
            }
            ));
        const u = new r.InjectionToken("NgValueAccessor")
            , d = {
                provide: u,
                useExisting: Object(r.forwardRef)(() => p),
                multi: !0
            };
        let p = (() => {
            class t {
                constructor(t, e) {
                    this._renderer = t,
                        this._elementRef = e,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                }
                writeValue(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "checked", t)
                }
                registerOnChange(t) {
                    this.onChange = t
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["input", "type", "checkbox", "formControlName", ""], ["input", "type", "checkbox", "formControl", ""], ["input", "type", "checkbox", "ngModel", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("change", (function (t) {
                            return e.onChange(t.target.checked)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([d])]
                }),
                t
        }
        )();
        const g = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => f),
            multi: !0
        }
            , m = new r.InjectionToken("CompositionEventMode");
        let f = (() => {
            class t {
                constructor(t, e, n) {
                    this._renderer = t,
                        this._elementRef = e,
                        this._compositionMode = n,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                        ,
                        this._composing = !1,
                        null == this._compositionMode && (this._compositionMode = !function () {
                            const t = Object(i.y)() ? Object(i.y)().getUserAgent() : "";
                            return /android (\d+)/.test(t.toLowerCase())
                        }())
                }
                writeValue(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "value", null == t ? "" : t)
                }
                registerOnChange(t) {
                    this.onChange = t
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
                _handleInput(t) {
                    (!this._compositionMode || this._compositionMode && !this._composing) && this.onChange(t)
                }
                _compositionStart() {
                    this._composing = !0
                }
                _compositionEnd(t) {
                    this._composing = !1,
                        this._compositionMode && this.onChange(t)
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef), r["\u0275\u0275directiveInject"](m, 8))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["input", "formControlName", "", 3, "type", "checkbox"], ["textarea", "formControlName", ""], ["input", "formControl", "", 3, "type", "checkbox"], ["textarea", "formControl", ""], ["input", "ngModel", "", 3, "type", "checkbox"], ["textarea", "ngModel", ""], ["", "ngDefaultControl", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("input", (function (t) {
                            return e._handleInput(t.target.value)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))("compositionstart", (function () {
                            return e._compositionStart()
                        }
                        ))("compositionend", (function (t) {
                            return e._compositionEnd(t.target.value)
                        }
                        ))
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([g])]
                }),
                t
        }
        )()
            , _ = (() => {
                class t {
                    get value() {
                        return this.control ? this.control.value : null
                    }
                    get valid() {
                        return this.control ? this.control.valid : null
                    }
                    get invalid() {
                        return this.control ? this.control.invalid : null
                    }
                    get pending() {
                        return this.control ? this.control.pending : null
                    }
                    get disabled() {
                        return this.control ? this.control.disabled : null
                    }
                    get enabled() {
                        return this.control ? this.control.enabled : null
                    }
                    get errors() {
                        return this.control ? this.control.errors : null
                    }
                    get pristine() {
                        return this.control ? this.control.pristine : null
                    }
                    get dirty() {
                        return this.control ? this.control.dirty : null
                    }
                    get touched() {
                        return this.control ? this.control.touched : null
                    }
                    get status() {
                        return this.control ? this.control.status : null
                    }
                    get untouched() {
                        return this.control ? this.control.untouched : null
                    }
                    get statusChanges() {
                        return this.control ? this.control.statusChanges : null
                    }
                    get valueChanges() {
                        return this.control ? this.control.valueChanges : null
                    }
                    get path() {
                        return null
                    }
                    reset(t) {
                        this.control && this.control.reset(t)
                    }
                    hasError(t, e) {
                        return !!this.control && this.control.hasError(t, e)
                    }
                    getError(t, e) {
                        return this.control ? this.control.getError(t, e) : null
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t
                    }),
                    t
            }
            )()
            , v = (() => {
                class t extends _ {
                    get formDirective() {
                        return null
                    }
                    get path() {
                        return null
                    }
                }
                return t.\u0275fac = function (e) {
                    return C(e || t)
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        features: [r["\u0275\u0275InheritDefinitionFeature"]]
                    }),
                    t
            }
            )();
        const C = r["\u0275\u0275getInheritedFactory"](v);
        function y() {
            throw new Error("unimplemented")
        }
        class A extends _ {
            constructor() {
                super(...arguments),
                    this._parent = null,
                    this.name = null,
                    this.valueAccessor = null,
                    this._rawValidators = [],
                    this._rawAsyncValidators = []
            }
            get validator() {
                return y()
            }
            get asyncValidator() {
                return y()
            }
        }
        class b {
            constructor(t) {
                this._cd = t
            }
            get ngClassUntouched() {
                return !!this._cd.control && this._cd.control.untouched
            }
            get ngClassTouched() {
                return !!this._cd.control && this._cd.control.touched
            }
            get ngClassPristine() {
                return !!this._cd.control && this._cd.control.pristine
            }
            get ngClassDirty() {
                return !!this._cd.control && this._cd.control.dirty
            }
            get ngClassValid() {
                return !!this._cd.control && this._cd.control.valid
            }
            get ngClassInvalid() {
                return !!this._cd.control && this._cd.control.invalid
            }
            get ngClassPending() {
                return !!this._cd.control && this._cd.control.pending
            }
        }
        let w = (() => {
            class t extends b {
                constructor(t) {
                    super(t)
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](A, 2))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formControlName", ""], ["", "ngModel", ""], ["", "formControl", ""]],
                    hostVars: 14,
                    hostBindings: function (t, e) {
                        2 & t && r["\u0275\u0275classProp"]("ng-untouched", e.ngClassUntouched)("ng-touched", e.ngClassTouched)("ng-pristine", e.ngClassPristine)("ng-dirty", e.ngClassDirty)("ng-valid", e.ngClassValid)("ng-invalid", e.ngClassInvalid)("ng-pending", e.ngClassPending)
                    },
                    features: [r["\u0275\u0275InheritDefinitionFeature"]]
                }),
                t
        }
        )()
            , O = (() => {
                class t extends b {
                    constructor(t) {
                        super(t)
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)(r["\u0275\u0275directiveInject"](v, 2))
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        selectors: [["", "formGroupName", ""], ["", "formArrayName", ""], ["", "ngModelGroup", ""], ["", "formGroup", ""], ["form", 3, "ngNoForm", ""], ["", "ngForm", ""]],
                        hostVars: 14,
                        hostBindings: function (t, e) {
                            2 & t && r["\u0275\u0275classProp"]("ng-untouched", e.ngClassUntouched)("ng-touched", e.ngClassTouched)("ng-pristine", e.ngClassPristine)("ng-dirty", e.ngClassDirty)("ng-valid", e.ngClassValid)("ng-invalid", e.ngClassInvalid)("ng-pending", e.ngClassPending)
                        },
                        features: [r["\u0275\u0275InheritDefinitionFeature"]]
                    }),
                    t
            }
            )();
        function V(t) {
            return null == t || 0 === t.length
        }
        const E = new r.InjectionToken("NgValidators")
            , x = new r.InjectionToken("NgAsyncValidators")
            , M = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        class j {
            static min(t) {
                return e => {
                    if (V(e.value) || V(t))
                        return null;
                    const n = parseFloat(e.value);
                    return !isNaN(n) && n < t ? {
                        min: {
                            min: t,
                            actual: e.value
                        }
                    } : null
                }
            }
            static max(t) {
                return e => {
                    if (V(e.value) || V(t))
                        return null;
                    const n = parseFloat(e.value);
                    return !isNaN(n) && n > t ? {
                        max: {
                            max: t,
                            actual: e.value
                        }
                    } : null
                }
            }
            static required(t) {
                return V(t.value) ? {
                    required: !0
                } : null
            }
            static requiredTrue(t) {
                return !0 === t.value ? null : {
                    required: !0
                }
            }
            static email(t) {
                return V(t.value) ? null : M.test(t.value) ? null : {
                    email: !0
                }
            }
            static minLength(t) {
                return e => {
                    if (V(e.value))
                        return null;
                    const n = e.value ? e.value.length : 0;
                    return n < t ? {
                        minlength: {
                            requiredLength: t,
                            actualLength: n
                        }
                    } : null
                }
            }
            static maxLength(t) {
                return e => {
                    const n = e.value ? e.value.length : 0;
                    return n > t ? {
                        maxlength: {
                            requiredLength: t,
                            actualLength: n
                        }
                    } : null
                }
            }
            static pattern(t) {
                if (!t)
                    return j.nullValidator;
                let e, n;
                return "string" == typeof t ? (n = "",
                    "^" !== t.charAt(0) && (n += "^"),
                    n += t,
                    "$" !== t.charAt(t.length - 1) && (n += "$"),
                    e = new RegExp(n)) : (n = t.toString(),
                        e = t),
                    t => {
                        if (V(t.value))
                            return null;
                        const r = t.value;
                        return e.test(r) ? null : {
                            pattern: {
                                requiredPattern: n,
                                actualValue: r
                            }
                        }
                    }
            }
            static nullValidator(t) {
                return null
            }
            static compose(t) {
                if (!t)
                    return null;
                const e = t.filter(I);
                return 0 == e.length ? null : function (t) {
                    return P(function (t, e) {
                        return e.map(e => e(t))
                    }(t, e))
                }
            }
            static composeAsync(t) {
                if (!t)
                    return null;
                const e = t.filter(I);
                return 0 == e.length ? null : function (t) {
                    return function (...t) {
                        if (1 === t.length) {
                            const e = t[0];
                            if (Object(s.a)(e))
                                return h(e, null);
                            if (Object(l.a)(e) && Object.getPrototypeOf(e) === Object.prototype) {
                                const t = Object.keys(e);
                                return h(t.map(t => e[t]), t)
                            }
                        }
                        if ("function" == typeof t[t.length - 1]) {
                            const e = t.pop();
                            return h(t = 1 === t.length && Object(s.a)(t[0]) ? t[0] : t, null).pipe(Object(a.a)(t => e(...t)))
                        }
                        return h(t, null)
                    }(function (t, e) {
                        return e.map(e => e(t))
                    }(t, e).map(D)).pipe(Object(a.a)(P))
                }
            }
        }
        function I(t) {
            return null != t
        }
        function D(t) {
            const e = Object(r["\u0275isPromise"])(t) ? Object(c.a)(t) : t;
            if (!Object(r["\u0275isObservable"])(e))
                throw new Error("Expected validator to return Promise or Observable.");
            return e
        }
        function P(t) {
            let e = {};
            return t.forEach(t => {
                e = null != t ? Object.assign(Object.assign({}, e), t) : e
            }
            ),
                0 === Object.keys(e).length ? null : e
        }
        function S(t) {
            return t.validate ? e => t.validate(e) : t
        }
        function T(t) {
            return t.validate ? e => t.validate(e) : t
        }
        const k = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => F),
            multi: !0
        };
        let F = (() => {
            class t {
                constructor(t, e) {
                    this._renderer = t,
                        this._elementRef = e,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                }
                writeValue(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "value", null == t ? "" : t)
                }
                registerOnChange(t) {
                    this.onChange = e => {
                        t("" == e ? null : parseFloat(e))
                    }
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["input", "type", "number", "formControlName", ""], ["input", "type", "number", "formControl", ""], ["input", "type", "number", "ngModel", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("change", (function (t) {
                            return e.onChange(t.target.value)
                        }
                        ))("input", (function (t) {
                            return e.onChange(t.target.value)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([k])]
                }),
                t
        }
        )();
        const R = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => G),
            multi: !0
        };
        let N = (() => {
            class t {
                constructor() {
                    this._accessors = []
                }
                add(t, e) {
                    this._accessors.push([t, e])
                }
                remove(t) {
                    for (let e = this._accessors.length - 1; e >= 0; --e)
                        if (this._accessors[e][1] === t)
                            return void this._accessors.splice(e, 1)
                }
                select(t) {
                    this._accessors.forEach(e => {
                        this._isSameGroup(e, t) && e[1] !== t && e[1].fireUncheck(t.value)
                    }
                    )
                }
                _isSameGroup(t, e) {
                    return !!t[0].control && t[0]._parent === e._control._parent && t[1].name === e.name
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)
            }
                ,
                t.\u0275prov = r["\u0275\u0275defineInjectable"]({
                    token: t,
                    factory: t.\u0275fac
                }),
                t
        }
        )()
            , G = (() => {
                class t {
                    constructor(t, e, n, r) {
                        this._renderer = t,
                            this._elementRef = e,
                            this._registry = n,
                            this._injector = r,
                            this.onChange = () => { }
                            ,
                            this.onTouched = () => { }
                    }
                    ngOnInit() {
                        this._control = this._injector.get(A),
                            this._checkName(),
                            this._registry.add(this._control, this)
                    }
                    ngOnDestroy() {
                        this._registry.remove(this)
                    }
                    writeValue(t) {
                        this._state = t === this.value,
                            this._renderer.setProperty(this._elementRef.nativeElement, "checked", this._state)
                    }
                    registerOnChange(t) {
                        this._fn = t,
                            this.onChange = () => {
                                t(this.value),
                                    this._registry.select(this)
                            }
                    }
                    fireUncheck(t) {
                        this.writeValue(t)
                    }
                    registerOnTouched(t) {
                        this.onTouched = t
                    }
                    setDisabledState(t) {
                        this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                    }
                    _checkName() {
                        this.name && this.formControlName && this.name !== this.formControlName && this._throwNameError(),
                            !this.name && this.formControlName && (this.name = this.formControlName)
                    }
                    _throwNameError() {
                        throw new Error('\n      If you define both a name and a formControlName attribute on your radio button, their values\n      must match. Ex: <input type="radio" formControlName="food" name="food">\n    ')
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef), r["\u0275\u0275directiveInject"](N), r["\u0275\u0275directiveInject"](r.Injector))
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        selectors: [["input", "type", "radio", "formControlName", ""], ["input", "type", "radio", "formControl", ""], ["input", "type", "radio", "ngModel", ""]],
                        hostBindings: function (t, e) {
                            1 & t && r["\u0275\u0275listener"]("change", (function () {
                                return e.onChange()
                            }
                            ))("blur", (function () {
                                return e.onTouched()
                            }
                            ))
                        },
                        inputs: {
                            name: "name",
                            formControlName: "formControlName",
                            value: "value"
                        },
                        features: [r["\u0275\u0275ProvidersFeature"]([R])]
                    }),
                    t
            }
            )();
        const B = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => U),
            multi: !0
        };
        let U = (() => {
            class t {
                constructor(t, e) {
                    this._renderer = t,
                        this._elementRef = e,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                }
                writeValue(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "value", parseFloat(t))
                }
                registerOnChange(t) {
                    this.onChange = e => {
                        t("" == e ? null : parseFloat(e))
                    }
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["input", "type", "range", "formControlName", ""], ["input", "type", "range", "formControl", ""], ["input", "type", "range", "ngModel", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("change", (function (t) {
                            return e.onChange(t.target.value)
                        }
                        ))("input", (function (t) {
                            return e.onChange(t.target.value)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([B])]
                }),
                t
        }
        )();
        const W = '\n    <div [formGroup]="myGroup">\n      <input formControlName="firstName">\n    </div>\n\n    In your class:\n\n    this.myGroup = new FormGroup({\n       firstName: new FormControl()\n    });'
            , L = '\n    <div [formGroup]="myGroup">\n       <div formGroupName="person">\n          <input formControlName="firstName">\n       </div>\n    </div>\n\n    In your class:\n\n    this.myGroup = new FormGroup({\n       person: new FormGroup({ firstName: new FormControl() })\n    });'
            , Y = '\n    <form>\n       <div ngModelGroup="person">\n          <input [(ngModel)]="person.name" name="firstName">\n       </div>\n    </form>';
        class Q {
            static controlParentException() {
                throw new Error(`formControlName must be used with a parent formGroup directive.  You'll want to add a formGroup\n       directive and pass it an existing FormGroup instance (you can create one in your class).\n\n      Example:\n\n      ${W}`)
            }
            static ngModelGroupException() {
                throw new Error(`formControlName cannot be used with an ngModelGroup parent. It is only compatible with parents\n       that also have a "form" prefix: formGroupName, formArrayName, or formGroup.\n\n       Option 1:  Update the parent to be formGroupName (reactive form strategy)\n\n        ${L}\n\n        Option 2: Use ngModel instead of formControlName (template-driven strategy)\n\n        ${Y}`)
            }
            static missingFormException() {
                throw new Error(`formGroup expects a FormGroup instance. Please pass one in.\n\n       Example:\n\n       ${W}`)
            }
            static groupParentException() {
                throw new Error(`formGroupName must be used with a parent formGroup directive.  You'll want to add a formGroup\n      directive and pass it an existing FormGroup instance (you can create one in your class).\n\n      Example:\n\n      ${L}`)
            }
            static arrayParentException() {
                throw new Error('formArrayName must be used with a parent formGroup directive.  You\'ll want to add a formGroup\n       directive and pass it an existing FormGroup instance (you can create one in your class).\n\n        Example:\n\n        \n    <div [formGroup]="myGroup">\n      <div formArrayName="cities">\n        <div *ngFor="let city of cityArray.controls; index as i">\n          <input [formControlName]="i">\n        </div>\n      </div>\n    </div>\n\n    In your class:\n\n    this.cityArray = new FormArray([new FormControl(\'SF\')]);\n    this.myGroup = new FormGroup({\n      cities: this.cityArray\n    });')
            }
            static disabledAttrWarning() {
                console.warn("\n      It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true\n      when you set up this control in your component class, the disabled attribute will actually be set in the DOM for\n      you. We recommend using this approach to avoid 'changed after checked' errors.\n       \n      Example: \n      form = new FormGroup({\n        first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),\n        last: new FormControl('Drew', Validators.required)\n      });\n    ")
            }
            static ngModelWarning(t) {
                console.warn(`\n    It looks like you're using ngModel on the same form field as ${t}. \n    Support for using the ngModel input property and ngModelChange event with \n    reactive form directives has been deprecated in Angular v6 and will be removed \n    in Angular v7.\n    \n    For more information on this, see our API docs here:\n    https://angular.io/api/forms/${"formControl" === t ? "FormControlDirective" : "FormControlName"}#use-with-ngmodel\n    `)
            }
        }
        const q = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => H),
            multi: !0
        };
        function Z(t, e) {
            return null == t ? `${e}` : (e && "object" == typeof e && (e = "Object"),
                `${t}: ${e}`.slice(0, 50))
        }
        let H = (() => {
            class t {
                constructor(t, e) {
                    this._renderer = t,
                        this._elementRef = e,
                        this._optionMap = new Map,
                        this._idCounter = 0,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                        ,
                        this._compareWith = r["\u0275looseIdentical"]
                }
                set compareWith(t) {
                    if ("function" != typeof t)
                        throw new Error(`compareWith must be a function, but received ${JSON.stringify(t)}`);
                    this._compareWith = t
                }
                writeValue(t) {
                    this.value = t;
                    const e = this._getOptionId(t);
                    null == e && this._renderer.setProperty(this._elementRef.nativeElement, "selectedIndex", -1);
                    const n = Z(e, t);
                    this._renderer.setProperty(this._elementRef.nativeElement, "value", n)
                }
                registerOnChange(t) {
                    this.onChange = e => {
                        this.value = this._getOptionValue(e),
                            t(this.value)
                    }
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
                _registerOption() {
                    return (this._idCounter++).toString()
                }
                _getOptionId(t) {
                    for (const e of Array.from(this._optionMap.keys()))
                        if (this._compareWith(this._optionMap.get(e), t))
                            return e;
                    return null
                }
                _getOptionValue(t) {
                    const e = function (t) {
                        return t.split(":")[0]
                    }(t);
                    return this._optionMap.has(e) ? this._optionMap.get(e) : t
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["select", "formControlName", "", 3, "multiple", ""], ["select", "formControl", "", 3, "multiple", ""], ["select", "ngModel", "", 3, "multiple", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("change", (function (t) {
                            return e.onChange(t.target.value)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))
                    },
                    inputs: {
                        compareWith: "compareWith"
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([q])]
                }),
                t
        }
        )()
            , z = (() => {
                class t {
                    constructor(t, e, n) {
                        this._element = t,
                            this._renderer = e,
                            this._select = n,
                            this._select && (this.id = this._select._registerOption())
                    }
                    set ngValue(t) {
                        null != this._select && (this._select._optionMap.set(this.id, t),
                            this._setElementValue(Z(this.id, t)),
                            this._select.writeValue(this._select.value))
                    }
                    set value(t) {
                        this._setElementValue(t),
                            this._select && this._select.writeValue(this._select.value)
                    }
                    _setElementValue(t) {
                        this._renderer.setProperty(this._element.nativeElement, "value", t)
                    }
                    ngOnDestroy() {
                        this._select && (this._select._optionMap.delete(this.id),
                            this._select.writeValue(this._select.value))
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)(r["\u0275\u0275directiveInject"](r.ElementRef), r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](H, 9))
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        selectors: [["option"]],
                        inputs: {
                            ngValue: "ngValue",
                            value: "value"
                        }
                    }),
                    t
            }
            )();
        const J = {
            provide: u,
            useExisting: Object(r.forwardRef)(() => $),
            multi: !0
        };
        function X(t, e) {
            return null == t ? `${e}` : ("string" == typeof e && (e = `'${e}'`),
                e && "object" == typeof e && (e = "Object"),
                `${t}: ${e}`.slice(0, 50))
        }
        let $ = (() => {
            class t {
                constructor(t, e) {
                    this._renderer = t,
                        this._elementRef = e,
                        this._optionMap = new Map,
                        this._idCounter = 0,
                        this.onChange = t => { }
                        ,
                        this.onTouched = () => { }
                        ,
                        this._compareWith = r["\u0275looseIdentical"]
                }
                set compareWith(t) {
                    if ("function" != typeof t)
                        throw new Error(`compareWith must be a function, but received ${JSON.stringify(t)}`);
                    this._compareWith = t
                }
                writeValue(t) {
                    let e;
                    if (this.value = t,
                        Array.isArray(t)) {
                        const n = t.map(t => this._getOptionId(t));
                        e = (t, e) => {
                            t._setSelected(n.indexOf(e.toString()) > -1)
                        }
                    } else
                        e = (t, e) => {
                            t._setSelected(!1)
                        }
                            ;
                    this._optionMap.forEach(e)
                }
                registerOnChange(t) {
                    this.onChange = e => {
                        const n = [];
                        if (e.hasOwnProperty("selectedOptions")) {
                            const t = e.selectedOptions;
                            for (let e = 0; e < t.length; e++) {
                                const r = t.item(e)
                                    , i = this._getOptionValue(r.value);
                                n.push(i)
                            }
                        } else {
                            const t = e.options;
                            for (let e = 0; e < t.length; e++) {
                                const r = t.item(e);
                                if (r.selected) {
                                    const t = this._getOptionValue(r.value);
                                    n.push(t)
                                }
                            }
                        }
                        this.value = n,
                            t(n)
                    }
                }
                registerOnTouched(t) {
                    this.onTouched = t
                }
                setDisabledState(t) {
                    this._renderer.setProperty(this._elementRef.nativeElement, "disabled", t)
                }
                _registerOption(t) {
                    const e = (this._idCounter++).toString();
                    return this._optionMap.set(e, t),
                        e
                }
                _getOptionId(t) {
                    for (const e of Array.from(this._optionMap.keys()))
                        if (this._compareWith(this._optionMap.get(e)._value, t))
                            return e;
                    return null
                }
                _getOptionValue(t) {
                    const e = function (t) {
                        return t.split(":")[0]
                    }(t);
                    return this._optionMap.has(e) ? this._optionMap.get(e)._value : t
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"](r.ElementRef))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["select", "multiple", "", "formControlName", ""], ["select", "multiple", "", "formControl", ""], ["select", "multiple", "", "ngModel", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("change", (function (t) {
                            return e.onChange(t.target)
                        }
                        ))("blur", (function () {
                            return e.onTouched()
                        }
                        ))
                    },
                    inputs: {
                        compareWith: "compareWith"
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([J])]
                }),
                t
        }
        )()
            , K = (() => {
                class t {
                    constructor(t, e, n) {
                        this._element = t,
                            this._renderer = e,
                            this._select = n,
                            this._select && (this.id = this._select._registerOption(this))
                    }
                    set ngValue(t) {
                        null != this._select && (this._value = t,
                            this._setElementValue(X(this.id, t)),
                            this._select.writeValue(this._select.value))
                    }
                    set value(t) {
                        this._select ? (this._value = t,
                            this._setElementValue(X(this.id, t)),
                            this._select.writeValue(this._select.value)) : this._setElementValue(t)
                    }
                    _setElementValue(t) {
                        this._renderer.setProperty(this._element.nativeElement, "value", t)
                    }
                    _setSelected(t) {
                        this._renderer.setProperty(this._element.nativeElement, "selected", t)
                    }
                    ngOnDestroy() {
                        this._select && (this._select._optionMap.delete(this.id),
                            this._select.writeValue(this._select.value))
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)(r["\u0275\u0275directiveInject"](r.ElementRef), r["\u0275\u0275directiveInject"](r.Renderer2), r["\u0275\u0275directiveInject"]($, 9))
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        selectors: [["option"]],
                        inputs: {
                            ngValue: "ngValue",
                            value: "value"
                        }
                    }),
                    t
            }
            )();
        function tt(t, e) {
            return [...e.path, t]
        }
        function et(t, e) {
            t || ot(e, "Cannot find control with"),
                e.valueAccessor || ot(e, "No value accessor for form control with"),
                t.validator = j.compose([t.validator, e.validator]),
                t.asyncValidator = j.composeAsync([t.asyncValidator, e.asyncValidator]),
                e.valueAccessor.writeValue(t.value),
                function (t, e) {
                    e.valueAccessor.registerOnChange(n => {
                        t._pendingValue = n,
                            t._pendingChange = !0,
                            t._pendingDirty = !0,
                            "change" === t.updateOn && nt(t, e)
                    }
                    )
                }(t, e),
                function (t, e) {
                    t.registerOnChange((t, n) => {
                        e.valueAccessor.writeValue(t),
                            n && e.viewToModelUpdate(t)
                    }
                    )
                }(t, e),
                function (t, e) {
                    e.valueAccessor.registerOnTouched(() => {
                        t._pendingTouched = !0,
                            "blur" === t.updateOn && t._pendingChange && nt(t, e),
                            "submit" !== t.updateOn && t.markAsTouched()
                    }
                    )
                }(t, e),
                e.valueAccessor.setDisabledState && t.registerOnDisabledChange(t => {
                    e.valueAccessor.setDisabledState(t)
                }
                ),
                e._rawValidators.forEach(e => {
                    e.registerOnValidatorChange && e.registerOnValidatorChange(() => t.updateValueAndValidity())
                }
                ),
                e._rawAsyncValidators.forEach(e => {
                    e.registerOnValidatorChange && e.registerOnValidatorChange(() => t.updateValueAndValidity())
                }
                )
        }
        function nt(t, e) {
            t._pendingDirty && t.markAsDirty(),
                t.setValue(t._pendingValue, {
                    emitModelToViewChange: !1
                }),
                e.viewToModelUpdate(t._pendingValue),
                t._pendingChange = !1
        }
        function rt(t, e) {
            null == t && ot(e, "Cannot find control with"),
                t.validator = j.compose([t.validator, e.validator]),
                t.asyncValidator = j.composeAsync([t.asyncValidator, e.asyncValidator])
        }
        function it(t) {
            return ot(t, "There is no FormControl instance attached to form control element with")
        }
        function ot(t, e) {
            let n;
            throw n = t.path.length > 1 ? `path: '${t.path.join(" -> ")}'` : t.path[0] ? `name: '${t.path}'` : "unspecified name attribute",
            new Error(`${e} ${n}`)
        }
        function st(t) {
            return null != t ? j.compose(t.map(S)) : null
        }
        function at(t) {
            return null != t ? j.composeAsync(t.map(T)) : null
        }
        function lt(t, e) {
            if (!t.hasOwnProperty("model"))
                return !1;
            const n = t.model;
            return !!n.isFirstChange() || !Object(r["\u0275looseIdentical"])(e, n.currentValue)
        }
        const ct = [p, U, F, H, $, G];
        function ht(t, e) {
            t._syncPendingControls(),
                e.forEach(t => {
                    const e = t.control;
                    "submit" === e.updateOn && e._pendingChange && (t.viewToModelUpdate(e._pendingValue),
                        e._pendingChange = !1)
                }
                )
        }
        function ut(t, e) {
            if (!e)
                return null;
            Array.isArray(e) || ot(t, "Value accessor was not provided as an array for form control with");
            let n = void 0
                , r = void 0
                , i = void 0;
            return e.forEach(e => {
                var o;
                e.constructor === f ? n = e : (o = e,
                    ct.some(t => o.constructor === t) ? (r && ot(t, "More than one built-in value accessor matches form control with"),
                        r = e) : (i && ot(t, "More than one custom value accessor matches form control with"),
                            i = e))
            }
            ),
                i || r || n || (ot(t, "No valid value accessor for form control with"),
                    null)
        }
        function dt(t, e) {
            const n = t.indexOf(e);
            n > -1 && t.splice(n, 1)
        }
        function pt(t, e, n, i) {
            Object(r.isDevMode)() && "never" !== i && ((null !== i && "once" !== i || e._ngModelWarningSentOnce) && ("always" !== i || n._ngModelWarningSent) || (Q.ngModelWarning(t),
                e._ngModelWarningSentOnce = !0,
                n._ngModelWarningSent = !0))
        }
        function gt(t) {
            const e = ft(t) ? t.validators : t;
            return Array.isArray(e) ? st(e) : e || null
        }
        function mt(t, e) {
            const n = ft(e) ? e.asyncValidators : t;
            return Array.isArray(n) ? at(n) : n || null
        }
        function ft(t) {
            return null != t && !Array.isArray(t) && "object" == typeof t
        }
        class _t {
            constructor(t, e) {
                this.validator = t,
                    this.asyncValidator = e,
                    this._onCollectionChange = () => { }
                    ,
                    this.pristine = !0,
                    this.touched = !1,
                    this._onDisabledChange = []
            }
            get parent() {
                return this._parent
            }
            get valid() {
                return "VALID" === this.status
            }
            get invalid() {
                return "INVALID" === this.status
            }
            get pending() {
                return "PENDING" == this.status
            }
            get disabled() {
                return "DISABLED" === this.status
            }
            get enabled() {
                return "DISABLED" !== this.status
            }
            get dirty() {
                return !this.pristine
            }
            get untouched() {
                return !this.touched
            }
            get updateOn() {
                return this._updateOn ? this._updateOn : this.parent ? this.parent.updateOn : "change"
            }
            setValidators(t) {
                this.validator = gt(t)
            }
            setAsyncValidators(t) {
                this.asyncValidator = mt(t)
            }
            clearValidators() {
                this.validator = null
            }
            clearAsyncValidators() {
                this.asyncValidator = null
            }
            markAsTouched(t = {}) {
                this.touched = !0,
                    this._parent && !t.onlySelf && this._parent.markAsTouched(t)
            }
            markAllAsTouched() {
                this.markAsTouched({
                    onlySelf: !0
                }),
                    this._forEachChild(t => t.markAllAsTouched())
            }
            markAsUntouched(t = {}) {
                this.touched = !1,
                    this._pendingTouched = !1,
                    this._forEachChild(t => {
                        t.markAsUntouched({
                            onlySelf: !0
                        })
                    }
                    ),
                    this._parent && !t.onlySelf && this._parent._updateTouched(t)
            }
            markAsDirty(t = {}) {
                this.pristine = !1,
                    this._parent && !t.onlySelf && this._parent.markAsDirty(t)
            }
            markAsPristine(t = {}) {
                this.pristine = !0,
                    this._pendingDirty = !1,
                    this._forEachChild(t => {
                        t.markAsPristine({
                            onlySelf: !0
                        })
                    }
                    ),
                    this._parent && !t.onlySelf && this._parent._updatePristine(t)
            }
            markAsPending(t = {}) {
                this.status = "PENDING",
                    !1 !== t.emitEvent && this.statusChanges.emit(this.status),
                    this._parent && !t.onlySelf && this._parent.markAsPending(t)
            }
            disable(t = {}) {
                const e = this._parentMarkedDirty(t.onlySelf);
                this.status = "DISABLED",
                    this.errors = null,
                    this._forEachChild(e => {
                        e.disable(Object.assign(Object.assign({}, t), {
                            onlySelf: !0
                        }))
                    }
                    ),
                    this._updateValue(),
                    !1 !== t.emitEvent && (this.valueChanges.emit(this.value),
                        this.statusChanges.emit(this.status)),
                    this._updateAncestors(Object.assign(Object.assign({}, t), {
                        skipPristineCheck: e
                    })),
                    this._onDisabledChange.forEach(t => t(!0))
            }
            enable(t = {}) {
                const e = this._parentMarkedDirty(t.onlySelf);
                this.status = "VALID",
                    this._forEachChild(e => {
                        e.enable(Object.assign(Object.assign({}, t), {
                            onlySelf: !0
                        }))
                    }
                    ),
                    this.updateValueAndValidity({
                        onlySelf: !0,
                        emitEvent: t.emitEvent
                    }),
                    this._updateAncestors(Object.assign(Object.assign({}, t), {
                        skipPristineCheck: e
                    })),
                    this._onDisabledChange.forEach(t => t(!1))
            }
            _updateAncestors(t) {
                this._parent && !t.onlySelf && (this._parent.updateValueAndValidity(t),
                    t.skipPristineCheck || this._parent._updatePristine(),
                    this._parent._updateTouched())
            }
            setParent(t) {
                this._parent = t
            }
            updateValueAndValidity(t = {}) {
                this._setInitialStatus(),
                    this._updateValue(),
                    this.enabled && (this._cancelExistingSubscription(),
                        this.errors = this._runValidator(),
                        this.status = this._calculateStatus(),
                        "VALID" !== this.status && "PENDING" !== this.status || this._runAsyncValidator(t.emitEvent)),
                    !1 !== t.emitEvent && (this.valueChanges.emit(this.value),
                        this.statusChanges.emit(this.status)),
                    this._parent && !t.onlySelf && this._parent.updateValueAndValidity(t)
            }
            _updateTreeValidity(t = {
                emitEvent: !0
            }) {
                this._forEachChild(e => e._updateTreeValidity(t)),
                    this.updateValueAndValidity({
                        onlySelf: !0,
                        emitEvent: t.emitEvent
                    })
            }
            _setInitialStatus() {
                this.status = this._allControlsDisabled() ? "DISABLED" : "VALID"
            }
            _runValidator() {
                return this.validator ? this.validator(this) : null
            }
            _runAsyncValidator(t) {
                if (this.asyncValidator) {
                    this.status = "PENDING";
                    const e = D(this.asyncValidator(this));
                    this._asyncValidationSubscription = e.subscribe(e => this.setErrors(e, {
                        emitEvent: t
                    }))
                }
            }
            _cancelExistingSubscription() {
                this._asyncValidationSubscription && this._asyncValidationSubscription.unsubscribe()
            }
            setErrors(t, e = {}) {
                this.errors = t,
                    this._updateControlsErrors(!1 !== e.emitEvent)
            }
            get(t) {
                return function (t, e, n) {
                    if (null == e)
                        return null;
                    if (Array.isArray(e) || (e = e.split(".")),
                        Array.isArray(e) && 0 === e.length)
                        return null;
                    let r = t;
                    return e.forEach(t => {
                        r = r instanceof Ct ? r.controls.hasOwnProperty(t) ? r.controls[t] : null : r instanceof yt && r.at(t) || null
                    }
                    ),
                        r
                }(this, t)
            }
            getError(t, e) {
                const n = e ? this.get(e) : this;
                return n && n.errors ? n.errors[t] : null
            }
            hasError(t, e) {
                return !!this.getError(t, e)
            }
            get root() {
                let t = this;
                for (; t._parent;)
                    t = t._parent;
                return t
            }
            _updateControlsErrors(t) {
                this.status = this._calculateStatus(),
                    t && this.statusChanges.emit(this.status),
                    this._parent && this._parent._updateControlsErrors(t)
            }
            _initObservables() {
                this.valueChanges = new r.EventEmitter,
                    this.statusChanges = new r.EventEmitter
            }
            _calculateStatus() {
                return this._allControlsDisabled() ? "DISABLED" : this.errors ? "INVALID" : this._anyControlsHaveStatus("PENDING") ? "PENDING" : this._anyControlsHaveStatus("INVALID") ? "INVALID" : "VALID"
            }
            _anyControlsHaveStatus(t) {
                return this._anyControls(e => e.status === t)
            }
            _anyControlsDirty() {
                return this._anyControls(t => t.dirty)
            }
            _anyControlsTouched() {
                return this._anyControls(t => t.touched)
            }
            _updatePristine(t = {}) {
                this.pristine = !this._anyControlsDirty(),
                    this._parent && !t.onlySelf && this._parent._updatePristine(t)
            }
            _updateTouched(t = {}) {
                this.touched = this._anyControlsTouched(),
                    this._parent && !t.onlySelf && this._parent._updateTouched(t)
            }
            _isBoxedValue(t) {
                return "object" == typeof t && null !== t && 2 === Object.keys(t).length && "value" in t && "disabled" in t
            }
            _registerOnCollectionChange(t) {
                this._onCollectionChange = t
            }
            _setUpdateStrategy(t) {
                ft(t) && null != t.updateOn && (this._updateOn = t.updateOn)
            }
            _parentMarkedDirty(t) {
                return !t && this._parent && this._parent.dirty && !this._parent._anyControlsDirty()
            }
        }
        class vt extends _t {
            constructor(t = null, e, n) {
                super(gt(e), mt(n, e)),
                    this._onChange = [],
                    this._applyFormState(t),
                    this._setUpdateStrategy(e),
                    this.updateValueAndValidity({
                        onlySelf: !0,
                        emitEvent: !1
                    }),
                    this._initObservables()
            }
            setValue(t, e = {}) {
                this.value = this._pendingValue = t,
                    this._onChange.length && !1 !== e.emitModelToViewChange && this._onChange.forEach(t => t(this.value, !1 !== e.emitViewToModelChange)),
                    this.updateValueAndValidity(e)
            }
            patchValue(t, e = {}) {
                this.setValue(t, e)
            }
            reset(t = null, e = {}) {
                this._applyFormState(t),
                    this.markAsPristine(e),
                    this.markAsUntouched(e),
                    this.setValue(this.value, e),
                    this._pendingChange = !1
            }
            _updateValue() { }
            _anyControls(t) {
                return !1
            }
            _allControlsDisabled() {
                return this.disabled
            }
            registerOnChange(t) {
                this._onChange.push(t)
            }
            _clearChangeFns() {
                this._onChange = [],
                    this._onDisabledChange = [],
                    this._onCollectionChange = () => { }
            }
            registerOnDisabledChange(t) {
                this._onDisabledChange.push(t)
            }
            _forEachChild(t) { }
            _syncPendingControls() {
                return !("submit" !== this.updateOn || (this._pendingDirty && this.markAsDirty(),
                    this._pendingTouched && this.markAsTouched(),
                    !this._pendingChange) || (this.setValue(this._pendingValue, {
                        onlySelf: !0,
                        emitModelToViewChange: !1
                    }),
                        0))
            }
            _applyFormState(t) {
                this._isBoxedValue(t) ? (this.value = this._pendingValue = t.value,
                    t.disabled ? this.disable({
                        onlySelf: !0,
                        emitEvent: !1
                    }) : this.enable({
                        onlySelf: !0,
                        emitEvent: !1
                    })) : this.value = this._pendingValue = t
            }
        }
        class Ct extends _t {
            constructor(t, e, n) {
                super(gt(e), mt(n, e)),
                    this.controls = t,
                    this._initObservables(),
                    this._setUpdateStrategy(e),
                    this._setUpControls(),
                    this.updateValueAndValidity({
                        onlySelf: !0,
                        emitEvent: !1
                    })
            }
            registerControl(t, e) {
                return this.controls[t] ? this.controls[t] : (this.controls[t] = e,
                    e.setParent(this),
                    e._registerOnCollectionChange(this._onCollectionChange),
                    e)
            }
            addControl(t, e) {
                this.registerControl(t, e),
                    this.updateValueAndValidity(),
                    this._onCollectionChange()
            }
            removeControl(t) {
                this.controls[t] && this.controls[t]._registerOnCollectionChange(() => { }
                ),
                    delete this.controls[t],
                    this.updateValueAndValidity(),
                    this._onCollectionChange()
            }
            setControl(t, e) {
                this.controls[t] && this.controls[t]._registerOnCollectionChange(() => { }
                ),
                    delete this.controls[t],
                    e && this.registerControl(t, e),
                    this.updateValueAndValidity(),
                    this._onCollectionChange()
            }
            contains(t) {
                return this.controls.hasOwnProperty(t) && this.controls[t].enabled
            }
            setValue(t, e = {}) {
                this._checkAllValuesPresent(t),
                    Object.keys(t).forEach(n => {
                        this._throwIfControlMissing(n),
                            this.controls[n].setValue(t[n], {
                                onlySelf: !0,
                                emitEvent: e.emitEvent
                            })
                    }
                    ),
                    this.updateValueAndValidity(e)
            }
            patchValue(t, e = {}) {
                Object.keys(t).forEach(n => {
                    this.controls[n] && this.controls[n].patchValue(t[n], {
                        onlySelf: !0,
                        emitEvent: e.emitEvent
                    })
                }
                ),
                    this.updateValueAndValidity(e)
            }
            reset(t = {}, e = {}) {
                this._forEachChild((n, r) => {
                    n.reset(t[r], {
                        onlySelf: !0,
                        emitEvent: e.emitEvent
                    })
                }
                ),
                    this._updatePristine(e),
                    this._updateTouched(e),
                    this.updateValueAndValidity(e)
            }
            getRawValue() {
                return this._reduceChildren({}, (t, e, n) => (t[n] = e instanceof vt ? e.value : e.getRawValue(),
                    t))
            }
            _syncPendingControls() {
                let t = this._reduceChildren(!1, (t, e) => !!e._syncPendingControls() || t);
                return t && this.updateValueAndValidity({
                    onlySelf: !0
                }),
                    t
            }
            _throwIfControlMissing(t) {
                if (!Object.keys(this.controls).length)
                    throw new Error("\n        There are no form controls registered with this group yet.  If you're using ngModel,\n        you may want to check next tick (e.g. use setTimeout).\n      ");
                if (!this.controls[t])
                    throw new Error(`Cannot find form control with name: ${t}.`)
            }
            _forEachChild(t) {
                Object.keys(this.controls).forEach(e => t(this.controls[e], e))
            }
            _setUpControls() {
                this._forEachChild(t => {
                    t.setParent(this),
                        t._registerOnCollectionChange(this._onCollectionChange)
                }
                )
            }
            _updateValue() {
                this.value = this._reduceValue()
            }
            _anyControls(t) {
                let e = !1;
                return this._forEachChild((n, r) => {
                    e = e || this.contains(r) && t(n)
                }
                ),
                    e
            }
            _reduceValue() {
                return this._reduceChildren({}, (t, e, n) => ((e.enabled || this.disabled) && (t[n] = e.value),
                    t))
            }
            _reduceChildren(t, e) {
                let n = t;
                return this._forEachChild((t, r) => {
                    n = e(n, t, r)
                }
                ),
                    n
            }
            _allControlsDisabled() {
                for (const t of Object.keys(this.controls))
                    if (this.controls[t].enabled)
                        return !1;
                return Object.keys(this.controls).length > 0 || this.disabled
            }
            _checkAllValuesPresent(t) {
                this._forEachChild((e, n) => {
                    if (void 0 === t[n])
                        throw new Error(`Must supply a value for form control with name: '${n}'.`)
                }
                )
            }
        }
        class yt extends _t {
            constructor(t, e, n) {
                super(gt(e), mt(n, e)),
                    this.controls = t,
                    this._initObservables(),
                    this._setUpdateStrategy(e),
                    this._setUpControls(),
                    this.updateValueAndValidity({
                        onlySelf: !0,
                        emitEvent: !1
                    })
            }
            at(t) {
                return this.controls[t]
            }
            push(t) {
                this.controls.push(t),
                    this._registerControl(t),
                    this.updateValueAndValidity(),
                    this._onCollectionChange()
            }
            insert(t, e) {
                this.controls.splice(t, 0, e),
                    this._registerControl(e),
                    this.updateValueAndValidity()
            }
            removeAt(t) {
                this.controls[t] && this.controls[t]._registerOnCollectionChange(() => { }
                ),
                    this.controls.splice(t, 1),
                    this.updateValueAndValidity()
            }
            setControl(t, e) {
                this.controls[t] && this.controls[t]._registerOnCollectionChange(() => { }
                ),
                    this.controls.splice(t, 1),
                    e && (this.controls.splice(t, 0, e),
                        this._registerControl(e)),
                    this.updateValueAndValidity(),
                    this._onCollectionChange()
            }
            get length() {
                return this.controls.length
            }
            setValue(t, e = {}) {
                this._checkAllValuesPresent(t),
                    t.forEach((t, n) => {
                        this._throwIfControlMissing(n),
                            this.at(n).setValue(t, {
                                onlySelf: !0,
                                emitEvent: e.emitEvent
                            })
                    }
                    ),
                    this.updateValueAndValidity(e)
            }
            patchValue(t, e = {}) {
                t.forEach((t, n) => {
                    this.at(n) && this.at(n).patchValue(t, {
                        onlySelf: !0,
                        emitEvent: e.emitEvent
                    })
                }
                ),
                    this.updateValueAndValidity(e)
            }
            reset(t = [], e = {}) {
                this._forEachChild((n, r) => {
                    n.reset(t[r], {
                        onlySelf: !0,
                        emitEvent: e.emitEvent
                    })
                }
                ),
                    this._updatePristine(e),
                    this._updateTouched(e),
                    this.updateValueAndValidity(e)
            }
            getRawValue() {
                return this.controls.map(t => t instanceof vt ? t.value : t.getRawValue())
            }
            clear() {
                this.controls.length < 1 || (this._forEachChild(t => t._registerOnCollectionChange(() => { }
                )),
                    this.controls.splice(0),
                    this.updateValueAndValidity())
            }
            _syncPendingControls() {
                let t = this.controls.reduce((t, e) => !!e._syncPendingControls() || t, !1);
                return t && this.updateValueAndValidity({
                    onlySelf: !0
                }),
                    t
            }
            _throwIfControlMissing(t) {
                if (!this.controls.length)
                    throw new Error("\n        There are no form controls registered with this array yet.  If you're using ngModel,\n        you may want to check next tick (e.g. use setTimeout).\n      ");
                if (!this.at(t))
                    throw new Error(`Cannot find form control at index ${t}`)
            }
            _forEachChild(t) {
                this.controls.forEach((e, n) => {
                    t(e, n)
                }
                )
            }
            _updateValue() {
                this.value = this.controls.filter(t => t.enabled || this.disabled).map(t => t.value)
            }
            _anyControls(t) {
                return this.controls.some(e => e.enabled && t(e))
            }
            _setUpControls() {
                this._forEachChild(t => this._registerControl(t))
            }
            _checkAllValuesPresent(t) {
                this._forEachChild((e, n) => {
                    if (void 0 === t[n])
                        throw new Error(`Must supply a value for form control at index: ${n}.`)
                }
                )
            }
            _allControlsDisabled() {
                for (const t of this.controls)
                    if (t.enabled)
                        return !1;
                return this.controls.length > 0 || this.disabled
            }
            _registerControl(t) {
                t.setParent(this),
                    t._registerOnCollectionChange(this._onCollectionChange)
            }
        }
        const At = {
            provide: v,
            useExisting: Object(r.forwardRef)(() => wt)
        }
            , bt = (() => Promise.resolve(null))();
        let wt = (() => {
            class t extends v {
                constructor(t, e) {
                    super(),
                        this.submitted = !1,
                        this._directives = [],
                        this.ngSubmit = new r.EventEmitter,
                        this.form = new Ct({}, st(t), at(e))
                }
                ngAfterViewInit() {
                    this._setUpdateStrategy()
                }
                get formDirective() {
                    return this
                }
                get control() {
                    return this.form
                }
                get path() {
                    return []
                }
                get controls() {
                    return this.form.controls
                }
                addControl(t) {
                    bt.then(() => {
                        const e = this._findContainer(t.path);
                        t.control = e.registerControl(t.name, t.control),
                            et(t.control, t),
                            t.control.updateValueAndValidity({
                                emitEvent: !1
                            }),
                            this._directives.push(t)
                    }
                    )
                }
                getControl(t) {
                    return this.form.get(t.path)
                }
                removeControl(t) {
                    bt.then(() => {
                        const e = this._findContainer(t.path);
                        e && e.removeControl(t.name),
                            dt(this._directives, t)
                    }
                    )
                }
                addFormGroup(t) {
                    bt.then(() => {
                        const e = this._findContainer(t.path)
                            , n = new Ct({});
                        rt(n, t),
                            e.registerControl(t.name, n),
                            n.updateValueAndValidity({
                                emitEvent: !1
                            })
                    }
                    )
                }
                removeFormGroup(t) {
                    bt.then(() => {
                        const e = this._findContainer(t.path);
                        e && e.removeControl(t.name)
                    }
                    )
                }
                getFormGroup(t) {
                    return this.form.get(t.path)
                }
                updateModel(t, e) {
                    bt.then(() => {
                        this.form.get(t.path).setValue(e)
                    }
                    )
                }
                setValue(t) {
                    this.control.setValue(t)
                }
                onSubmit(t) {
                    return this.submitted = !0,
                        ht(this.form, this._directives),
                        this.ngSubmit.emit(t),
                        !1
                }
                onReset() {
                    this.resetForm()
                }
                resetForm(t) {
                    this.form.reset(t),
                        this.submitted = !1
                }
                _setUpdateStrategy() {
                    this.options && null != this.options.updateOn && (this.form._updateOn = this.options.updateOn)
                }
                _findContainer(t) {
                    return t.pop(),
                        t.length ? this.form.get(t) : this.form
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["form", 3, "ngNoForm", "", 3, "formGroup", ""], ["ng-form"], ["", "ngForm", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("submit", (function (t) {
                            return e.onSubmit(t)
                        }
                        ))("reset", (function () {
                            return e.onReset()
                        }
                        ))
                    },
                    inputs: {
                        options: ["ngFormOptions", "options"]
                    },
                    outputs: {
                        ngSubmit: "ngSubmit"
                    },
                    exportAs: ["ngForm"],
                    features: [r["\u0275\u0275ProvidersFeature"]([At]), r["\u0275\u0275InheritDefinitionFeature"]]
                }),
                t
        }
        )()
            , Ot = (() => {
                class t extends v {
                    ngOnInit() {
                        this._checkParentType(),
                            this.formDirective.addFormGroup(this)
                    }
                    ngOnDestroy() {
                        this.formDirective && this.formDirective.removeFormGroup(this)
                    }
                    get control() {
                        return this.formDirective.getFormGroup(this)
                    }
                    get path() {
                        return tt(null == this.name ? this.name : this.name.toString(), this._parent)
                    }
                    get formDirective() {
                        return this._parent ? this._parent.formDirective : null
                    }
                    get validator() {
                        return st(this._validators)
                    }
                    get asyncValidator() {
                        return at(this._asyncValidators)
                    }
                    _checkParentType() { }
                }
                return t.\u0275fac = function (e) {
                    return Vt(e || t)
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        features: [r["\u0275\u0275InheritDefinitionFeature"]]
                    }),
                    t
            }
            )();
        const Vt = r["\u0275\u0275getInheritedFactory"](Ot);
        class Et {
            static modelParentException() {
                throw new Error(`\n      ngModel cannot be used to register form controls with a parent formGroup directive.  Try using\n      formGroup's partner directive "formControlName" instead.  Example:\n\n      ${W}\n\n      Or, if you'd like to avoid registering this form control, indicate that it's standalone in ngModelOptions:\n\n      Example:\n\n      \n    <div [formGroup]="myGroup">\n       <input formControlName="firstName">\n       <input [(ngModel)]="showMoreControls" [ngModelOptions]="{standalone: true}">\n    </div>\n  `)
            }
            static formGroupNameException() {
                throw new Error(`\n      ngModel cannot be used to register form controls with a parent formGroupName or formArrayName directive.\n\n      Option 1: Use formControlName instead of ngModel (reactive strategy):\n\n      ${L}\n\n      Option 2:  Update ngModel's parent be ngModelGroup (template-driven strategy):\n\n      ${Y}`)
            }
            static missingNameException() {
                throw new Error('If ngModel is used within a form tag, either the name attribute must be set or the form\n      control must be defined as \'standalone\' in ngModelOptions.\n\n      Example 1: <input [(ngModel)]="person.firstName" name="first">\n      Example 2: <input [(ngModel)]="person.firstName" [ngModelOptions]="{standalone: true}">')
            }
            static modelGroupParentException() {
                throw new Error(`\n      ngModelGroup cannot be used with a parent formGroup directive.\n\n      Option 1: Use formGroupName instead of ngModelGroup (reactive strategy):\n\n      ${L}\n\n      Option 2:  Use a regular form tag instead of the formGroup directive (template-driven strategy):\n\n      ${Y}`)
            }
        }
        const xt = {
            provide: v,
            useExisting: Object(r.forwardRef)(() => Mt)
        };
        let Mt = (() => {
            class t extends Ot {
                constructor(t, e, n) {
                    super(),
                        this._parent = t,
                        this._validators = e,
                        this._asyncValidators = n
                }
                _checkParentType() {
                    this._parent instanceof t || this._parent instanceof wt || Et.modelGroupParentException()
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](v, 5), r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "ngModelGroup", ""]],
                    inputs: {
                        name: ["ngModelGroup", "name"]
                    },
                    exportAs: ["ngModelGroup"],
                    features: [r["\u0275\u0275ProvidersFeature"]([xt]), r["\u0275\u0275InheritDefinitionFeature"]]
                }),
                t
        }
        )();
        const jt = {
            provide: A,
            useExisting: Object(r.forwardRef)(() => Dt)
        }
            , It = (() => Promise.resolve(null))();
        let Dt = (() => {
            class t extends A {
                constructor(t, e, n, i) {
                    super(),
                        this.control = new vt,
                        this._registered = !1,
                        this.update = new r.EventEmitter,
                        this._parent = t,
                        this._rawValidators = e || [],
                        this._rawAsyncValidators = n || [],
                        this.valueAccessor = ut(this, i)
                }
                ngOnChanges(t) {
                    this._checkForErrors(),
                        this._registered || this._setUpControl(),
                        "isDisabled" in t && this._updateDisabled(t),
                        lt(t, this.viewModel) && (this._updateValue(this.model),
                            this.viewModel = this.model)
                }
                ngOnDestroy() {
                    this.formDirective && this.formDirective.removeControl(this)
                }
                get path() {
                    return this._parent ? tt(this.name, this._parent) : [this.name]
                }
                get formDirective() {
                    return this._parent ? this._parent.formDirective : null
                }
                get validator() {
                    return st(this._rawValidators)
                }
                get asyncValidator() {
                    return at(this._rawAsyncValidators)
                }
                viewToModelUpdate(t) {
                    this.viewModel = t,
                        this.update.emit(t)
                }
                _setUpControl() {
                    this._setUpdateStrategy(),
                        this._isStandalone() ? this._setUpStandalone() : this.formDirective.addControl(this),
                        this._registered = !0
                }
                _setUpdateStrategy() {
                    this.options && null != this.options.updateOn && (this.control._updateOn = this.options.updateOn)
                }
                _isStandalone() {
                    return !this._parent || !(!this.options || !this.options.standalone)
                }
                _setUpStandalone() {
                    et(this.control, this),
                        this.control.updateValueAndValidity({
                            emitEvent: !1
                        })
                }
                _checkForErrors() {
                    this._isStandalone() || this._checkParentType(),
                        this._checkName()
                }
                _checkParentType() {
                    !(this._parent instanceof Mt) && this._parent instanceof Ot ? Et.formGroupNameException() : this._parent instanceof Mt || this._parent instanceof wt || Et.modelParentException()
                }
                _checkName() {
                    this.options && this.options.name && (this.name = this.options.name),
                        this._isStandalone() || this.name || Et.missingNameException()
                }
                _updateValue(t) {
                    It.then(() => {
                        this.control.setValue(t, {
                            emitViewToModelChange: !1
                        })
                    }
                    )
                }
                _updateDisabled(t) {
                    const e = t.isDisabled.currentValue
                        , n = "" === e || e && "false" !== e;
                    It.then(() => {
                        n && !this.control.disabled ? this.control.disable() : !n && this.control.disabled && this.control.enable()
                    }
                    )
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](v, 9), r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10), r["\u0275\u0275directiveInject"](u, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "ngModel", "", 3, "formControlName", "", 3, "formControl", ""]],
                    inputs: {
                        name: "name",
                        isDisabled: ["disabled", "isDisabled"],
                        model: ["ngModel", "model"],
                        options: ["ngModelOptions", "options"]
                    },
                    outputs: {
                        update: "ngModelChange"
                    },
                    exportAs: ["ngModel"],
                    features: [r["\u0275\u0275ProvidersFeature"]([jt]), r["\u0275\u0275InheritDefinitionFeature"], r["\u0275\u0275NgOnChangesFeature"]]
                }),
                t
        }
        )()
            , Pt = (() => {
                class t {
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)
                }
                    ,
                    t.\u0275dir = r["\u0275\u0275defineDirective"]({
                        type: t,
                        selectors: [["form", 3, "ngNoForm", "", 3, "ngNativeValidate", ""]],
                        hostAttrs: ["novalidate", ""]
                    }),
                    t
            }
            )();
        const St = new r.InjectionToken("NgModelWithFormControlWarning")
            , Tt = {
                provide: A,
                useExisting: Object(r.forwardRef)(() => kt)
            };
        let kt = (() => {
            class t extends A {
                constructor(t, e, n, i) {
                    super(),
                        this._ngModelWarningConfig = i,
                        this.update = new r.EventEmitter,
                        this._ngModelWarningSent = !1,
                        this._rawValidators = t || [],
                        this._rawAsyncValidators = e || [],
                        this.valueAccessor = ut(this, n)
                }
                set isDisabled(t) {
                    Q.disabledAttrWarning()
                }
                ngOnChanges(e) {
                    this._isControlChanged(e) && (et(this.form, this),
                        this.control.disabled && this.valueAccessor.setDisabledState && this.valueAccessor.setDisabledState(!0),
                        this.form.updateValueAndValidity({
                            emitEvent: !1
                        })),
                        lt(e, this.viewModel) && (pt("formControl", t, this, this._ngModelWarningConfig),
                            this.form.setValue(this.model),
                            this.viewModel = this.model)
                }
                get path() {
                    return []
                }
                get validator() {
                    return st(this._rawValidators)
                }
                get asyncValidator() {
                    return at(this._rawAsyncValidators)
                }
                get control() {
                    return this.form
                }
                viewToModelUpdate(t) {
                    this.viewModel = t,
                        this.update.emit(t)
                }
                _isControlChanged(t) {
                    return t.hasOwnProperty("form")
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10), r["\u0275\u0275directiveInject"](u, 10), r["\u0275\u0275directiveInject"](St, 8))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formControl", ""]],
                    inputs: {
                        isDisabled: ["disabled", "isDisabled"],
                        form: ["formControl", "form"],
                        model: ["ngModel", "model"]
                    },
                    outputs: {
                        update: "ngModelChange"
                    },
                    exportAs: ["ngForm"],
                    features: [r["\u0275\u0275ProvidersFeature"]([Tt]), r["\u0275\u0275InheritDefinitionFeature"], r["\u0275\u0275NgOnChangesFeature"]]
                }),
                t._ngModelWarningSentOnce = !1,
                t
        }
        )();
        const Ft = {
            provide: v,
            useExisting: Object(r.forwardRef)(() => Rt)
        };
        let Rt = (() => {
            class t extends v {
                constructor(t, e) {
                    super(),
                        this._validators = t,
                        this._asyncValidators = e,
                        this.submitted = !1,
                        this.directives = [],
                        this.form = null,
                        this.ngSubmit = new r.EventEmitter
                }
                ngOnChanges(t) {
                    this._checkFormPresent(),
                        t.hasOwnProperty("form") && (this._updateValidators(),
                            this._updateDomValue(),
                            this._updateRegistrations())
                }
                get formDirective() {
                    return this
                }
                get control() {
                    return this.form
                }
                get path() {
                    return []
                }
                addControl(t) {
                    const e = this.form.get(t.path);
                    return et(e, t),
                        e.updateValueAndValidity({
                            emitEvent: !1
                        }),
                        this.directives.push(t),
                        e
                }
                getControl(t) {
                    return this.form.get(t.path)
                }
                removeControl(t) {
                    dt(this.directives, t)
                }
                addFormGroup(t) {
                    const e = this.form.get(t.path);
                    rt(e, t),
                        e.updateValueAndValidity({
                            emitEvent: !1
                        })
                }
                removeFormGroup(t) { }
                getFormGroup(t) {
                    return this.form.get(t.path)
                }
                addFormArray(t) {
                    const e = this.form.get(t.path);
                    rt(e, t),
                        e.updateValueAndValidity({
                            emitEvent: !1
                        })
                }
                removeFormArray(t) { }
                getFormArray(t) {
                    return this.form.get(t.path)
                }
                updateModel(t, e) {
                    this.form.get(t.path).setValue(e)
                }
                onSubmit(t) {
                    return this.submitted = !0,
                        ht(this.form, this.directives),
                        this.ngSubmit.emit(t),
                        !1
                }
                onReset() {
                    this.resetForm()
                }
                resetForm(t) {
                    this.form.reset(t),
                        this.submitted = !1
                }
                _updateDomValue() {
                    this.directives.forEach(t => {
                        const e = this.form.get(t.path);
                        t.control !== e && (function (t, e) {
                            e.valueAccessor.registerOnChange(() => it(e)),
                                e.valueAccessor.registerOnTouched(() => it(e)),
                                e._rawValidators.forEach(t => {
                                    t.registerOnValidatorChange && t.registerOnValidatorChange(null)
                                }
                                ),
                                e._rawAsyncValidators.forEach(t => {
                                    t.registerOnValidatorChange && t.registerOnValidatorChange(null)
                                }
                                ),
                                t && t._clearChangeFns()
                        }(t.control, t),
                            e && et(e, t),
                            t.control = e)
                    }
                    ),
                        this.form._updateTreeValidity({
                            emitEvent: !1
                        })
                }
                _updateRegistrations() {
                    this.form._registerOnCollectionChange(() => this._updateDomValue()),
                        this._oldForm && this._oldForm._registerOnCollectionChange(() => { }
                        ),
                        this._oldForm = this.form
                }
                _updateValidators() {
                    const t = st(this._validators);
                    this.form.validator = j.compose([this.form.validator, t]);
                    const e = at(this._asyncValidators);
                    this.form.asyncValidator = j.composeAsync([this.form.asyncValidator, e])
                }
                _checkFormPresent() {
                    this.form || Q.missingFormException()
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formGroup", ""]],
                    hostBindings: function (t, e) {
                        1 & t && r["\u0275\u0275listener"]("submit", (function (t) {
                            return e.onSubmit(t)
                        }
                        ))("reset", (function () {
                            return e.onReset()
                        }
                        ))
                    },
                    inputs: {
                        form: ["formGroup", "form"]
                    },
                    outputs: {
                        ngSubmit: "ngSubmit"
                    },
                    exportAs: ["ngForm"],
                    features: [r["\u0275\u0275ProvidersFeature"]([Ft]), r["\u0275\u0275InheritDefinitionFeature"], r["\u0275\u0275NgOnChangesFeature"]]
                }),
                t
        }
        )();
        const Nt = {
            provide: v,
            useExisting: Object(r.forwardRef)(() => Gt)
        };
        let Gt = (() => {
            class t extends Ot {
                constructor(t, e, n) {
                    super(),
                        this._parent = t,
                        this._validators = e,
                        this._asyncValidators = n
                }
                _checkParentType() {
                    Wt(this._parent) && Q.groupParentException()
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](v, 13), r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formGroupName", ""]],
                    inputs: {
                        name: ["formGroupName", "name"]
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([Nt]), r["\u0275\u0275InheritDefinitionFeature"]]
                }),
                t
        }
        )();
        const Bt = {
            provide: v,
            useExisting: Object(r.forwardRef)(() => Ut)
        };
        let Ut = (() => {
            class t extends v {
                constructor(t, e, n) {
                    super(),
                        this._parent = t,
                        this._validators = e,
                        this._asyncValidators = n
                }
                ngOnInit() {
                    this._checkParentType(),
                        this.formDirective.addFormArray(this)
                }
                ngOnDestroy() {
                    this.formDirective && this.formDirective.removeFormArray(this)
                }
                get control() {
                    return this.formDirective.getFormArray(this)
                }
                get formDirective() {
                    return this._parent ? this._parent.formDirective : null
                }
                get path() {
                    return tt(null == this.name ? this.name : this.name.toString(), this._parent)
                }
                get validator() {
                    return st(this._validators)
                }
                get asyncValidator() {
                    return at(this._asyncValidators)
                }
                _checkParentType() {
                    Wt(this._parent) && Q.arrayParentException()
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](v, 13), r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formArrayName", ""]],
                    inputs: {
                        name: ["formArrayName", "name"]
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([Bt]), r["\u0275\u0275InheritDefinitionFeature"]]
                }),
                t
        }
        )();
        function Wt(t) {
            return !(t instanceof Gt || t instanceof Rt || t instanceof Ut)
        }
        const Lt = {
            provide: A,
            useExisting: Object(r.forwardRef)(() => Yt)
        };
        let Yt = (() => {
            class t extends A {
                constructor(t, e, n, i, o) {
                    super(),
                        this._ngModelWarningConfig = o,
                        this._added = !1,
                        this.update = new r.EventEmitter,
                        this._ngModelWarningSent = !1,
                        this._parent = t,
                        this._rawValidators = e || [],
                        this._rawAsyncValidators = n || [],
                        this.valueAccessor = ut(this, i)
                }
                set isDisabled(t) {
                    Q.disabledAttrWarning()
                }
                ngOnChanges(e) {
                    this._added || this._setUpControl(),
                        lt(e, this.viewModel) && (pt("formControlName", t, this, this._ngModelWarningConfig),
                            this.viewModel = this.model,
                            this.formDirective.updateModel(this, this.model))
                }
                ngOnDestroy() {
                    this.formDirective && this.formDirective.removeControl(this)
                }
                viewToModelUpdate(t) {
                    this.viewModel = t,
                        this.update.emit(t)
                }
                get path() {
                    return tt(null == this.name ? this.name : this.name.toString(), this._parent)
                }
                get formDirective() {
                    return this._parent ? this._parent.formDirective : null
                }
                get validator() {
                    return st(this._rawValidators)
                }
                get asyncValidator() {
                    return at(this._rawAsyncValidators)
                }
                _checkParentType() {
                    !(this._parent instanceof Gt) && this._parent instanceof Ot ? Q.ngModelGroupException() : this._parent instanceof Gt || this._parent instanceof Rt || this._parent instanceof Ut || Q.controlParentException()
                }
                _setUpControl() {
                    this._checkParentType(),
                        this.control = this.formDirective.addControl(this),
                        this.control.disabled && this.valueAccessor.setDisabledState && this.valueAccessor.setDisabledState(!0),
                        this._added = !0
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](v, 13), r["\u0275\u0275directiveInject"](E, 10), r["\u0275\u0275directiveInject"](x, 10), r["\u0275\u0275directiveInject"](u, 10), r["\u0275\u0275directiveInject"](St, 8))
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "formControlName", ""]],
                    inputs: {
                        isDisabled: ["disabled", "isDisabled"],
                        name: ["formControlName", "name"],
                        model: ["ngModel", "model"]
                    },
                    outputs: {
                        update: "ngModelChange"
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([Lt]), r["\u0275\u0275InheritDefinitionFeature"], r["\u0275\u0275NgOnChangesFeature"]]
                }),
                t._ngModelWarningSentOnce = !1,
                t
        }
        )();
        const Qt = {
            provide: E,
            useExisting: Object(r.forwardRef)(() => qt),
            multi: !0
        };
        let qt = (() => {
            class t {
                get required() {
                    return this._required
                }
                set required(t) {
                    this._required = null != t && !1 !== t && "false" !== `${t}`,
                        this._onChange && this._onChange()
                }
                validate(t) {
                    return this.required ? j.required(t) : null
                }
                registerOnValidatorChange(t) {
                    this._onChange = t
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)
            }
                ,
                t.\u0275dir = r["\u0275\u0275defineDirective"]({
                    type: t,
                    selectors: [["", "required", "", "formControlName", "", 3, "type", "checkbox"], ["", "required", "", "formControl", "", 3, "type", "checkbox"], ["", "required", "", "ngModel", "", 3, "type", "checkbox"]],
                    hostVars: 1,
                    hostBindings: function (t, e) {
                        2 & t && r["\u0275\u0275attribute"]("required", e.required ? "" : null)
                    },
                    inputs: {
                        required: "required"
                    },
                    features: [r["\u0275\u0275ProvidersFeature"]([Qt])]
                }),
                t
        }
        )()
            , Zt = (() => {
                class t {
                }
                return t.\u0275mod = r["\u0275\u0275defineNgModule"]({
                    type: t
                }),
                    t.\u0275inj = r["\u0275\u0275defineInjector"]({
                        factory: function (e) {
                            return new (e || t)
                        }
                    }),
                    t
            }
            )()
            , Ht = (() => {
                class t {
                    group(t, e = null) {
                        const n = this._reduceControls(t);
                        let r = null
                            , i = null
                            , o = void 0;
                        return null != e && (function (t) {
                            return void 0 !== t.asyncValidators || void 0 !== t.validators || void 0 !== t.updateOn
                        }(e) ? (r = null != e.validators ? e.validators : null,
                            i = null != e.asyncValidators ? e.asyncValidators : null,
                            o = null != e.updateOn ? e.updateOn : void 0) : (r = null != e.validator ? e.validator : null,
                                i = null != e.asyncValidator ? e.asyncValidator : null)),
                            new Ct(n, {
                                asyncValidators: i,
                                updateOn: o,
                                validators: r
                            })
                    }
                    control(t, e, n) {
                        return new vt(t, e, n)
                    }
                    array(t, e, n) {
                        const r = t.map(t => this._createControl(t));
                        return new yt(r, e, n)
                    }
                    _reduceControls(t) {
                        const e = {};
                        return Object.keys(t).forEach(n => {
                            e[n] = this._createControl(t[n])
                        }
                        ),
                            e
                    }
                    _createControl(t) {
                        return t instanceof vt || t instanceof Ct || t instanceof yt ? t : Array.isArray(t) ? this.control(t[0], t.length > 1 ? t[1] : null, t.length > 2 ? t[2] : null) : this.control(t)
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)
                }
                    ,
                    t.\u0275prov = r["\u0275\u0275defineInjectable"]({
                        token: t,
                        factory: t.\u0275fac
                    }),
                    t
            }
            )()
            , zt = (() => {
                class t {
                }
                return t.\u0275mod = r["\u0275\u0275defineNgModule"]({
                    type: t
                }),
                    t.\u0275inj = r["\u0275\u0275defineInjector"]({
                        factory: function (e) {
                            return new (e || t)
                        },
                        providers: [N],
                        imports: [Zt]
                    }),
                    t
            }
            )()
            , Jt = (() => {
                class t {
                    static withConfig(e) {
                        return {
                            ngModule: t,
                            providers: [{
                                provide: St,
                                useValue: e.warnOnNgModelWithFormControl
                            }]
                        }
                    }
                }
                return t.\u0275mod = r["\u0275\u0275defineNgModule"]({
                    type: t
                }),
                    t.\u0275inj = r["\u0275\u0275defineInjector"]({
                        factory: function (e) {
                            return new (e || t)
                        },
                        providers: [Ht, N],
                        imports: [Zt]
                    }),
                    t
            }
            )()
    },
    Kmm4: function (t, e, n) {
        "use strict";
        n.d(e, "b", (function () {
            return v
        }
        )),
            n.d(e, "a", (function () {
                return _
            }
            ));
        var r = n("fXoL")
            , i = n("R0Ic")
            , o = n("XNiG")
            , s = n("ofXK")
            , a = n("jhN1");
        function l(t, e) {
            if (1 & t) {
                const t = r["\u0275\u0275getCurrentView"]();
                r["\u0275\u0275elementStart"](0, "div", 9),
                    r["\u0275\u0275listener"]("click", (function () {
                        r["\u0275\u0275restoreView"](t);
                        const e = r["\u0275\u0275nextContext"]().$implicit;
                        return r["\u0275\u0275nextContext"]().removeToastr(e)
                    }
                    )),
                    r["\u0275\u0275text"](1, "\xd7 "),
                    r["\u0275\u0275elementEnd"]()
            }
        }
        function c(t, e) {
            if (1 & t && (r["\u0275\u0275elementStart"](0, "div"),
                r["\u0275\u0275text"](1),
                r["\u0275\u0275elementEnd"]()),
                2 & t) {
                const t = r["\u0275\u0275nextContext"]().$implicit
                    , e = r["\u0275\u0275nextContext"]();
                r["\u0275\u0275classMapInterpolate1"]("to-title ", t.config.titleClass || e.titleClass, ""),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275textInterpolate"](t.title)
            }
        }
        function h(t, e) {
            if (1 & t && r["\u0275\u0275element"](0, "span", 10),
                2 & t) {
                const t = r["\u0275\u0275nextContext"]().$implicit
                    , e = r["\u0275\u0275nextContext"]();
                r["\u0275\u0275classMapInterpolate1"]("to-message ", t.config.messageClass || e.messageClass, ""),
                    r["\u0275\u0275property"]("innerHTML", e.sanitizer.bypassSecurityTrustHtml(t.message), r["\u0275\u0275sanitizeHtml"])
            }
        }
        function u(t, e) {
            if (1 & t && (r["\u0275\u0275elementStart"](0, "span"),
                r["\u0275\u0275text"](1),
                r["\u0275\u0275elementEnd"]()),
                2 & t) {
                const t = r["\u0275\u0275nextContext"]().$implicit
                    , e = r["\u0275\u0275nextContext"]();
                r["\u0275\u0275classMapInterpolate1"]("to-message ", t.config.messageClass || e.messageClass, ""),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275textInterpolate"](t.message)
            }
        }
        function d(t, e) {
            if (1 & t) {
                const t = r["\u0275\u0275getCurrentView"]();
                r["\u0275\u0275elementStart"](0, "div", 3),
                    r["\u0275\u0275listener"]("@inOut.done", (function (e) {
                        return r["\u0275\u0275restoreView"](t),
                            r["\u0275\u0275nextContext"]().onAnimationEnd(e)
                    }
                    ))("click", (function () {
                        r["\u0275\u0275restoreView"](t);
                        const n = e.$implicit;
                        return r["\u0275\u0275nextContext"]().clicked(n)
                    }
                    )),
                    r["\u0275\u0275template"](1, l, 2, 0, "div", 4),
                    r["\u0275\u0275template"](2, c, 2, 4, "div", 5),
                    r["\u0275\u0275elementStart"](3, "div", 6),
                    r["\u0275\u0275template"](4, h, 1, 4, "span", 7),
                    r["\u0275\u0275template"](5, u, 2, 4, "span", 8),
                    r["\u0275\u0275elementEnd"](),
                    r["\u0275\u0275elementEnd"]()
            }
            if (2 & t) {
                const t = e.$implicit
                    , n = r["\u0275\u0275nextContext"]();
                r["\u0275\u0275classMapInterpolate1"]("toastr toastr-", t.type, ""),
                    r["\u0275\u0275property"]("@inOut", t.config.animate || n.animate),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275property"]("ngIf", t.config.showCloseButton),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275property"]("ngIf", t.title),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275property"]("ngSwitch", t.config.enableHTML),
                    r["\u0275\u0275advance"](1),
                    r["\u0275\u0275property"]("ngSwitchCase", !0)
            }
        }
        let p = (() => {
            class t {
                constructor() {
                    this.position = "top-right",
                        this.maxShown = 5,
                        this.newestOnTop = !1,
                        this.animate = "slideFromLeft",
                        this.toastTimeout = 5e3,
                        this.enableHTML = !1,
                        this.dismiss = "auto",
                        this.messageClass = "toastr-message",
                        this.titleClass = "toastr-title",
                        this.showCloseButton = !1
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)
            }
                ,
                t.\u0275prov = r["\u0275\u0275defineInjectable"]({
                    token: t,
                    factory: t.\u0275fac
                }),
                t
        }
        )();
        class g {
            constructor(t, e, n, r) {
                this.type = t,
                    this.message = e,
                    this.title = n,
                    this.data = r,
                    this.config = {
                        position: "",
                        animate: "slideFromLeft",
                        dismiss: "auto",
                        enableHTML: !1,
                        titleClass: "",
                        messageClass: "",
                        toastTimeout: 3e3,
                        showCloseButton: !1
                    }
            }
            dismiss() {
                this.toastrManager.dismissToastr(this)
            }
        }
        const m = Object(i.j)("inOut", [Object(i.g)("fade", Object(i.h)({
            opacity: 1
        })), Object(i.i)("void => fade", [Object(i.h)({
            opacity: 1
        }), Object(i.e)("0.4s ease-in")]), Object(i.i)("fade => void", [Object(i.e)("0.4s 0.1s ease-out", Object(i.h)({
            opacity: 0
        }))]), Object(i.g)("slideFromLeft", Object(i.h)({
            opacity: 1,
            transform: "translateX(0)"
        })), Object(i.i)("void => slideFromLeft", [Object(i.h)({
            opacity: 0,
            transform: "translateX(-100%)"
        }), Object(i.e)("0.4s ease-in")]), Object(i.i)("slideFromLeft => void", [Object(i.e)("0.4s 0.1s ease-out", Object(i.h)({
            opacity: 0,
            transform: "translateX(100%)"
        }))]), Object(i.g)("slideFromRight", Object(i.h)({
            opacity: 1,
            transform: "translateX(0)"
        })), Object(i.i)("void => slideFromRight", [Object(i.h)({
            opacity: 0,
            transform: "translateX(100%)"
        }), Object(i.e)("0.4s ease-in")]), Object(i.i)("slideFromRight => void", [Object(i.e)("0.4s 0.1s ease-out", Object(i.h)({
            opacity: 0,
            transform: "translateX(-100%)"
        }))]), Object(i.g)("slideFromTop", Object(i.h)({
            opacity: 1,
            transform: "translateY(0)"
        })), Object(i.i)("void => slideFromTop", [Object(i.h)({
            opacity: 0,
            transform: "translateY(-100%)"
        }), Object(i.e)("0.4s ease-in")]), Object(i.i)("slideFromTop => void", [Object(i.e)("0.4s 0.1s ease-out", Object(i.h)({
            opacity: 0,
            transform: "translateY(100%)"
        }))]), Object(i.g)("slideFromBottom", Object(i.h)({
            opacity: 1,
            transform: "translateY(0)"
        })), Object(i.i)("void => slideFromBottom", [Object(i.h)({
            opacity: 0,
            transform: "translateY(100%)"
        }), Object(i.e)("0.4s ease-in")]), Object(i.i)("slideFromBottom => void", [Object(i.e)("0.4s 0.1s ease-out", Object(i.h)({
            opacity: 0,
            transform: "translateY(-100%)"
        }))])]);
        let f = (() => {
            class t {
                constructor(t, e, n, r) {
                    this.sanitizer = t,
                        this.cdr = e,
                        this._zone = n,
                        this.toastrs = [],
                        this._fresh = !0,
                        this._onEnter = new o.a,
                        this._onExit = new o.a,
                        Object.assign(this, r)
                }
                onEnter() {
                    return this._onEnter.asObservable()
                }
                onExit() {
                    return this._onExit.asObservable()
                }
                addToastr(t) {
                    if (this.position.indexOf("top") > 0) {
                        if (this.newestOnTop ? this.toastrs.unshift(t) : this.toastrs.push(t),
                            this.toastrs.length > this.maxShown) {
                            const t = this.toastrs.length - this.maxShown;
                            this.newestOnTop ? this.toastrs.splice(this.maxShown) : this.toastrs.splice(0, t)
                        }
                    } else
                        this.toastrs.unshift(t),
                            this.toastrs.length > this.maxShown && this.toastrs.splice(this.maxShown);
                    null === this.animate && this._fresh && (this._fresh = !1,
                        this._onEnter.next(),
                        this._onEnter.complete()),
                        this.cdr.detectChanges()
                }
                removeToastr(t) {
                    t.timeoutId && (clearTimeout(t.timeoutId),
                        t.timeoutId = null),
                        this.toastrs = this.toastrs.filter(e => e.id !== t.id)
                }
                removeAllToasts() {
                    this.toastrs.forEach(t => {
                        clearTimeout(t.timeoutId),
                            t.timeoutId = null
                    }
                    ),
                        this.toastrs = []
                }
                clicked(t) {
                    this.onToastClicked && this.onToastClicked(t)
                }
                anyToast() {
                    return this.toastrs.length > 0
                }
                findToast(t) {
                    for (let e of this.toastrs)
                        if (e.id === t)
                            return e;
                    return null
                }
                onAnimationEnd(t) {
                    "void" !== t.toState || this.anyToast() ? this._fresh && "void" === t.fromState && (this._fresh = !1,
                        this._zone.run(() => {
                            this._onEnter.next(),
                                this._onEnter.complete()
                        }
                        )) : this._ngExit()
                }
                _ngExit() {
                    this._zone.onMicrotaskEmpty.subscribe(() => {
                        this._onExit.next(),
                            this._onExit.complete()
                    }
                    )
                }
                ngOnDestroy() {
                    this._ngExit()
                }
            }
            return t.\u0275fac = function (e) {
                return new (e || t)(r["\u0275\u0275directiveInject"](a.b), r["\u0275\u0275directiveInject"](r.ChangeDetectorRef), r["\u0275\u0275directiveInject"](r.NgZone), r["\u0275\u0275directiveInject"](p))
            }
                ,
                t.\u0275cmp = r["\u0275\u0275defineComponent"]({
                    type: t,
                    selectors: [["app-toastr"]],
                    decls: 3,
                    vars: 4,
                    consts: [["id", "toastr-container"], ["toastrContainer", ""], [3, "class", "click", 4, "ngFor", "ngForOf"], [3, "click"], ["class", "toastr-close-button", 3, "click", 4, "ngIf"], [3, "class", 4, "ngIf"], [3, "ngSwitch"], [3, "class", "innerHTML", 4, "ngSwitchCase"], [3, "class", 4, "ngSwitchDefault"], [1, "toastr-close-button", 3, "click"], [3, "innerHTML"]],
                    template: function (t, e) {
                        1 & t && (r["\u0275\u0275elementStart"](0, "div", 0, 1),
                            r["\u0275\u0275template"](2, d, 6, 8, "div", 2),
                            r["\u0275\u0275elementEnd"]()),
                            2 & t && (r["\u0275\u0275classMap"](e.position),
                                r["\u0275\u0275advance"](2),
                                r["\u0275\u0275property"]("ngForOf", e.toastrs))
                    },
                    directives: [s.m, s.n, s.p, s.q, s.r],
                    styles: [".to-title[_ngcontent-%COMP%]{font-weight:700;font-size:16px;margin-bottom:8px;color:#fff}.to-message[_ngcontent-%COMP%]{word-wrap:break-word;font-size:14px;line-height:20px;display:block;color:#fff;background-color:transparent}.to-message[_ngcontent-%COMP%]   a[_ngcontent-%COMP%], .to-message[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]{color:#fff}.to-message[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover{color:#ccc;text-decoration:none}.toastr-close-button[_ngcontent-%COMP%]{position:relative;right:-5px;top:-15px;float:right;font-size:25px;color:#fff;-webkit-text-shadow:0 1px 0 #fff;text-shadow:0 1px 0 #fff;opacity:.8}.toastr-close-button[_ngcontent-%COMP%]:focus, .toastr-close-button[_ngcontent-%COMP%]:hover{color:#000;text-decoration:none;cursor:pointer;opacity:.4}button.toastr-close-button[_ngcontent-%COMP%]{padding:0;cursor:pointer;background:0 0;border:0;-webkit-appearance:none}.top-center[_ngcontent-%COMP%]{top:0;right:0;width:100%}.bottom-center[_ngcontent-%COMP%]{bottom:0;right:0;width:100%}.top-full-width[_ngcontent-%COMP%]{top:0;right:0;width:100%}.bottom-full-width[_ngcontent-%COMP%]{bottom:0;right:0;width:100%}.top-left[_ngcontent-%COMP%]{top:12px;left:12px}.top-right[_ngcontent-%COMP%]{top:12px;right:12px}.bottom-right[_ngcontent-%COMP%]{right:12px;bottom:12px}.bottom-left[_ngcontent-%COMP%]{bottom:12px;left:12px}#toastr-container[_ngcontent-%COMP%]{position:fixed;z-index:99999}#toastr-container[_ngcontent-%COMP%]   *[_ngcontent-%COMP%]{box-sizing:border-box}#toastr-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{position:relative;overflow:hidden;margin:10px 0 6px;padding:15px 15px 15px 60px;width:345px;border-radius:3px;background-position:15px;background-repeat:no-repeat;box-shadow:0 0 12px #999;color:#fff;opacity:1}#toastr-container[_ngcontent-%COMP%] > div.toastr-custom[_ngcontent-%COMP%]{padding:15px;color:#030303}#toastr-container[_ngcontent-%COMP%] > div.toastr-custom[_ngcontent-%COMP%]   .toastr-close-button[_ngcontent-%COMP%]{color:#999!important}#toastr-container[_ngcontent-%COMP%] > [_ngcontent-%COMP%]:hover{box-shadow:0 0 12px #000;opacity:1;cursor:pointer}#toastr-container[_ngcontent-%COMP%] > .toastr-info[_ngcontent-%COMP%]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGwSURBVEhLtZa9SgNBEMc9sUxxRcoUKSzSWIhXpFMhhYWFhaBg4yPYiWCXZxBLERsLRS3EQkEfwCKdjWJAwSKCgoKCcudv4O5YLrt7EzgXhiU3/4+b2ckmwVjJSpKkQ6wAi4gwhT+z3wRBcEz0yjSseUTrcRyfsHsXmD0AmbHOC9Ii8VImnuXBPglHpQ5wwSVM7sNnTG7Za4JwDdCjxyAiH3nyA2mtaTJufiDZ5dCaqlItILh1NHatfN5skvjx9Z38m69CgzuXmZgVrPIGE763Jx9qKsRozWYw6xOHdER+nn2KkO+Bb+UV5CBN6WC6QtBgbRVozrahAbmm6HtUsgtPC19tFdxXZYBOfkbmFJ1VaHA1VAHjd0pp70oTZzvR+EVrx2Ygfdsq6eu55BHYR8hlcki+n+kERUFG8BrA0BwjeAv2M8WLQBtcy+SD6fNsmnB3AlBLrgTtVW1c2QN4bVWLATaIS60J2Du5y1TiJgjSBvFVZgTmwCU+dAZFoPxGEEs8nyHC9Bwe2GvEJv2WXZb0vjdyFT4Cxk3e/kIqlOGoVLwwPevpYHT+00T+hWwXDf4AJAOUqWcDhbwAAAAASUVORK5CYII=)!important}#toastr-container[_ngcontent-%COMP%] > .toastr-error[_ngcontent-%COMP%]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHOSURBVEhLrZa/SgNBEMZzh0WKCClSCKaIYOED+AAKeQQLG8HWztLCImBrYadgIdY+gIKNYkBFSwu7CAoqCgkkoGBI/E28PdbLZmeDLgzZzcx83/zZ2SSXC1j9fr+I1Hq93g2yxH4iwM1vkoBWAdxCmpzTxfkN2RcyZNaHFIkSo10+8kgxkXIURV5HGxTmFuc75B2RfQkpxHG8aAgaAFa0tAHqYFfQ7Iwe2yhODk8+J4C7yAoRTWI3w/4klGRgR4lO7Rpn9+gvMyWp+uxFh8+H+ARlgN1nJuJuQAYvNkEnwGFck18Er4q3egEc/oO+mhLdKgRyhdNFiacC0rlOCbhNVz4H9FnAYgDBvU3QIioZlJFLJtsoHYRDfiZoUyIxqCtRpVlANq0EU4dApjrtgezPFad5S19Wgjkc0hNVnuF4HjVA6C7QrSIbylB+oZe3aHgBsqlNqKYH48jXyJKMuAbiyVJ8KzaB3eRc0pg9VwQ4niFryI68qiOi3AbjwdsfnAtk0bCjTLJKr6mrD9g8iq/S/B81hguOMlQTnVyG40wAcjnmgsCNESDrjme7wfftP4P7SP4N3CJZdvzoNyGq2c/HWOXJGsvVg+RA/k2MC/wN6I2YA2Pt8GkAAAAASUVORK5CYII=)!important}#toastr-container[_ngcontent-%COMP%] > .toastr-success[_ngcontent-%COMP%]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADsSURBVEhLY2AYBfQMgf///3P8+/evAIgvA/FsIF+BavYDDWMBGroaSMMBiE8VC7AZDrIFaMFnii3AZTjUgsUUWUDA8OdAH6iQbQEhw4HyGsPEcKBXBIC4ARhex4G4BsjmweU1soIFaGg/WtoFZRIZdEvIMhxkCCjXIVsATV6gFGACs4Rsw0EGgIIH3QJYJgHSARQZDrWAB+jawzgs+Q2UO49D7jnRSRGoEFRILcdmEMWGI0cm0JJ2QpYA1RDvcmzJEWhABhD/pqrL0S0CWuABKgnRki9lLseS7g2AlqwHWQSKH4oKLrILpRGhEQCw2LiRUIa4lwAAAABJRU5ErkJggg==)!important}#toastr-container[_ngcontent-%COMP%] > .toastr-warning[_ngcontent-%COMP%]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGYSURBVEhL5ZSvTsNQFMbXZGICMYGYmJhAQIJAICYQPAACiSDB8AiICQQJT4CqQEwgJvYASAQCiZiYmJhAIBATCARJy+9rTsldd8sKu1M0+dLb057v6/lbq/2rK0mS/TRNj9cWNAKPYIJII7gIxCcQ51cvqID+GIEX8ASG4B1bK5gIZFeQfoJdEXOfgX4QAQg7kH2A65yQ87lyxb27sggkAzAuFhbbg1K2kgCkB1bVwyIR9m2L7PRPIhDUIXgGtyKw575yz3lTNs6X4JXnjV+LKM/m3MydnTbtOKIjtz6VhCBq4vSm3ncdrD2lk0VgUXSVKjVDJXJzijW1RQdsU7F77He8u68koNZTz8Oz5yGa6J3H3lZ0xYgXBK2QymlWWA+RWnYhskLBv2vmE+hBMCtbA7KX5drWyRT/2JsqZ2IvfB9Y4bWDNMFbJRFmC9E74SoS0CqulwjkC0+5bpcV1CZ8NMej4pjy0U+doDQsGyo1hzVJttIjhQ7GnBtRFN1UarUlH8F3xict+HY07rEzoUGPlWcjRFRr4/gChZgc3ZL2d8oAAAAASUVORK5CYII=)!important}#toastr-container.bottom-center[_ngcontent-%COMP%] > div[_ngcontent-%COMP%], #toastr-container.top-center[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{width:300px;margin:10px auto}#toastr-container.bottom-full-width[_ngcontent-%COMP%] > div[_ngcontent-%COMP%], #toastr-container.top-full-width[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{width:96%;margin:10px auto}.toastr[_ngcontent-%COMP%]{background-color:#fff}.toastr-success[_ngcontent-%COMP%]{background-color:#51a351}.toastr-error[_ngcontent-%COMP%]{background-color:#d9534f}.toastr-info[_ngcontent-%COMP%]{background-color:#7460ee}.toastr-warning[_ngcontent-%COMP%]{background-color:#f89406}.toastr-progress[_ngcontent-%COMP%]{position:absolute;left:0;bottom:0;height:4px;background-color:#000;opacity:.4}@media all and (max-width:240px){#toastr-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{padding:8px 8px 8px 50px;width:11em}#toastr-container[_ngcontent-%COMP%]   .toastr-close-button[_ngcontent-%COMP%]{right:-.2em;top:-.2em}}@media all and (min-width:241px) and (max-width:480px){#toastr-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{padding:8px 8px 8px 50px;width:18em}#toastr-container[_ngcontent-%COMP%]   .toastr-close-button[_ngcontent-%COMP%]{right:-.2em;top:-.2em}}@media all and (min-width:481px) and (max-width:768px){#toastr-container[_ngcontent-%COMP%] > div[_ngcontent-%COMP%]{padding:15px 15px 15px 50px;width:25em}}"],
                    data: {
                        animation: [m]
                    }
                }),
                t
        }
        )()
            , _ = (() => {
                class t {
                    constructor(t, e, n, r, i) {
                        this._applicationRef = t,
                            this._componentFactoryResolver = e,
                            this._injector = n,
                            this.ngZone = r,
                            this.options = i,
                            this.toastrContainers = [],
                            this.index = 0,
                            this.toastClicked = new o.a
                    }
                    createToastrComponent(t, e = []) {
                        const n = this._componentFactoryResolver.resolveComponentFactory(t)
                            , i = r.ReflectiveInjector.resolve(e)
                            , o = r.ReflectiveInjector.fromResolvedProviders(i, this._injector);
                        let s = document.createElement("div");
                        s.id = "toastr-node-" + Math.floor(200 * Math.random()),
                            document.querySelector("body").appendChild(s);
                        const a = n.create(o, [], s);
                        return this.attachToApplication(a),
                            a
                    }
                    attachToApplication(t) {
                        this._applicationRef.attachView(t.hostView)
                    }
                    detachFromApplication(t) {
                        this._applicationRef.detachView(t.hostView)
                    }
                    isToastrContainerExist(t) {
                        return this.toastrContainers.length > 0 && this.toastrContainers.findIndex(e => e.position === t) > -1
                    }
                    getToastrComponentRef(t) {
                        if (this.toastrContainers.length > 0) {
                            const e = this.toastrContainers.find(e => e.position === t);
                            return e ? e.ref : null
                        }
                        return null
                    }
                    createTimeout(t) {
                        let e;
                        return this.ngZone.runOutsideAngular(() => {
                            e = setTimeout(() => this.ngZone.run(() => this.clearToast(t)), t.config.toastTimeout)
                        }
                        ),
                            e.toString()
                    }
                    setupToast(t, e) {
                        t.id = ++this.index,
                            e && e.hasOwnProperty("toastTimeout") && (e.dismiss = "auto");
                        const n = Object.assign({}, this.options, e || {});
                        Object.keys(t.config).forEach(e => {
                            n.hasOwnProperty(e) && (t.config[e] = n[e])
                        }
                        ),
                            "auto" === t.config.dismiss && (t.timeoutId = this.createTimeout(t)),
                            t.toastrManager = this;
                        const r = t.config.position;
                        return this.isToastrContainerExist(r) && this.getToastrComponentRef(r).instance.addToastr(t),
                            t
                    }
                    clearToast(t) {
                        const e = t.config.position;
                        this.isToastrContainerExist(e) && this.getToastrComponentRef(e).instance.removeToastr(t)
                    }
                    clearAllToasts() {
                        this.toastrContainers.length > 0 && this.toastrContainers.forEach(t => {
                            console.log(t);
                            const e = t.ref;
                            t.ref.instance.removeAllToasts(),
                                this.dispose(e)
                        }
                        )
                    }
                    dispose(t) {
                        if (t) {
                            const e = this.toastrContainers.findIndex(e => e.position === t.instance.position);
                            e > -1 && this.toastrContainers.splice(e, 1),
                                this.detachFromApplication(t)
                        }
                    }
                    _onToastClicked(t) {
                        this.toastClicked.next(t),
                            "controlled" !== t.config.dismiss && this.clearToast(t)
                    }
                    dismissToastr(t) {
                        this.clearToast(t)
                    }
                    dismissAllToastr() {
                        this.clearAllToasts()
                    }
                    onClickToast() {
                        return this.toastClicked.asObservable()
                    }
                    showToastr(t, e) {
                        const n = Object.assign({}, this.options, e);
                        return new Promise((r, i) => {
                            if (!this.isToastrContainerExist(n.position)) {
                                let t = this.createToastrComponent(f, [{
                                    provide: p,
                                    useValue: n
                                }]);
                                t.instance.onToastClicked = t => {
                                    this._onToastClicked(t)
                                }
                                    ,
                                    t.instance.onExit().subscribe(() => {
                                        this.dispose(t)
                                    }
                                    ),
                                    this.toastrContainers.push({
                                        position: n.position,
                                        ref: t
                                    })
                            }
                            r(this.setupToast(t, e))
                        }
                        )
                    }
                    errorToastr(t, e, n) {
                        const r = new g("error", t, e, n && n.data ? n.data : null);
                        return this.showToastr(r, n),
                            r
                    }
                    infoToastr(t, e, n) {
                        const r = new g("info", t, e, n && n.data ? n.data : null);
                        return this.showToastr(r, n),
                            r
                    }
                    successToastr(t, e, n) {
                        const r = new g("success", t, e, n && n.data ? n.data : null);
                        return this.showToastr(r, n),
                            r
                    }
                    warningToastr(t, e, n) {
                        const r = new g("warning", t, e, n && n.data ? n.data : null);
                        return this.showToastr(r, n),
                            r
                    }
                    customToastr(t, e, n) {
                        const r = new g("custom", t, e, n && n.data ? n.data : null);
                        return this.showToastr(r, n),
                            r
                    }
                }
                return t.\u0275fac = function (e) {
                    return new (e || t)(r["\u0275\u0275inject"](r.ApplicationRef), r["\u0275\u0275inject"](r.ComponentFactoryResolver), r["\u0275\u0275inject"](r.Injector), r["\u0275\u0275inject"](r.NgZone), r["\u0275\u0275inject"](p))
                }
                    ,
                    t.\u0275prov = r["\u0275\u0275defineInjectable"]({
                        token: t,
                        factory: t.\u0275fac
                    }),
                    t
            }
            )()
            , v = (() => {
                class t {
                    static forRoot() {
                        return {
                            ngModule: t,
                            providers: [_, p]
                        }
                    }
                }
                return t.\u0275mod = r["\u0275\u0275defineNgModule"]({
                    type: t
                }),
                    t.\u0275inj = r["\u0275\u0275defineInjector"]({
                        factory: function (e) {
                            return new (e || t)
                        },
                        imports: [[s.c]]
                    }),
                    t
            }
            )()
    }
}]);
